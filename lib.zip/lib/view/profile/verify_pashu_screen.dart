// verified_pashu_screen.dart

import 'dart:convert';
import 'dart:async';
import 'dart:ffi';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:pashu_app/core/shared_pref_helper.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:shimmer/shimmer.dart';

class VerifiedPashuScreen extends StatefulWidget {
  const VerifiedPashuScreen({super.key});

  @override
  State<VerifiedPashuScreen> createState() => _VerifiedPashuScreenState();
}

class _VerifiedPashuScreenState extends State<VerifiedPashuScreen> {
  List<dynamic> pashus = [];
  bool isLoading = false;
  bool isRefreshing = false;
  int carouselIndex = 0;
  double? latitude;
  double? longitude;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    fetchPashuData();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) {
      setState(() => carouselIndex = (carouselIndex + 1) % 2);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> fetchPashuData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    final phone = await SharedPrefHelper.getPhoneNumber();
    latitude = 5.5;
    longitude = 7.5;
    print(latitude);
    print(longitude);
    setState(() => isLoading = true);
    try {
      final response = await http.get(Uri.parse('https://pashuparivar.com/api/allpashu'));
      if (response.statusCode == 200) {
        final all = jsonDecode(response.body);
        final userPashu = all.where((e) => e['usernumber'] == phone).toList();
        setState(() => pashus = userPashu);
      }
    } catch (e) {
      debugPrint('Error fetching data: $e');
    }
    setState(() => isLoading = false);
  }

  double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    const R = 6371;
    double dLat = (lat2 - lat1) * 3.1415926 / 180;
    double dLon = (lon2 - lon1) * 3.1415926 / 180;
    double a =
        (sin(dLat / 2) * sin(dLat / 2)) + cos(lat1 * 3.1415926 / 180) * cos(lat2 * 3.1415926 / 180) * (sin(dLon / 2) * sin(dLon / 2));
    double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    return (R * c);
  }

  Future<void> handleVerification(int id) async {
    setState(() => isLoading = true);
    final profileRes = await http.get(Uri.parse('https://pashuparivar.com/api/getprofileByNumber/${pashus.first['usernumber']}'));
    final profile = jsonDecode(profileRes.body)['result'][0];
    if (profile['walletBalance'] >= 25) {
      await http.put(Uri.parse('https://pashuparivar.com/api/updatepashu/$id/verification pending'));
      await http.post(
        Uri.parse('https://pashuparivar.com/api/payment/deduct-wallet'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'userId': profile['id'], 'amount': 25}),
      );
      await fetchPashuData();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Insufficient balance')));
    }
    setState(() => isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Verify Your Pashu')),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : pashus.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/not-found.png', width: 150),
            const SizedBox(height: 16),
            const Text("Your List is Empty", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text("You haven't added any Pashu yet. Start exploring to Add what you love!",
                textAlign: TextAlign.center)
          ],
        ),
      )
          : RefreshIndicator(
        onRefresh: fetchPashuData,
        child: ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: pashus.length,
          itemBuilder: (context, index) {
            final pashu = pashus[index];
            //final loc = jsonDecode(pashu['location']);
            final dist = calculateDistance(
                latitude!,
                longitude!,
                24.2,
                41.4);
            final imageUrl = 'https://pashuparivar.com/uploads/${carouselIndex == 0 ? pashu['pictureOne'] : pashu['pictureTwo']}';

            if (pashu['status'] == 'Active') {
              return Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Image.network(imageUrl, height: 250, width: double.infinity, fit: BoxFit.cover),
                    Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Type: ${pashu['type'] ?? ''}"),
                          Text("Age: ${pashu['age'] ?? ''}"),
                          Text("Price: ₹${pashu['price'] ?? ''}"),
                          Text("Negotiable: ${pashu['negotiable'] ?? ''}"),
                          Text("Owner: ${pashu['username'] ?? ''} ji"),
                          Text("Distance: ${dist.toStringAsFixed(1)} km"),
                          const SizedBox(height: 8),
                          ElevatedButton(
                            onPressed: () => handleVerification(pashu['id']),
                            child: const Text('Get Verified (₹25)'),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              );
            } else if (pashu['status'] == 'verification pending') {
              return Container(
                margin: const EdgeInsets.only(bottom: 10),
                decoration: BoxDecoration(
                    color: Colors.blue.shade50, borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.blue)),
                child: Column(
                  children: [
                    Stack(
                      children: [
                        Image.network(imageUrl, height: 250, width: double.infinity, fit: BoxFit.cover),
                        Positioned(
                          top: 10,
                          right: 10,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                            decoration: BoxDecoration(
                                color: Colors.blue,
                                borderRadius: const BorderRadius.only(
                                    topRight: Radius.circular(10), bottomLeft: Radius.circular(10))),
                            child: const Text("Verification Pending",
                                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("Verification Under Review",
                              style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold, fontSize: 18)),
                          Text("Type: ${pashu['type'] ?? ''}"),
                          Text("Age: ${pashu['age'] ?? ''}"),
                          Text("Owner: ${pashu['username'] ?? ''} ji"),
                          Text("Distance: ${dist.toStringAsFixed(1)} km"),
                        ],
                      ),
                    )
                  ],
                ),
              );
            } else if (pashu['status'] == 'verified pashu') {
              return Card(
                elevation: 4,
                margin: const EdgeInsets.symmetric(vertical: 10),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                child: Column(
                  children: [
                    Stack(
                      children: [
                        Image.network(imageUrl, height: 250, width: double.infinity, fit: BoxFit.cover),
                        Positioned(
                          top: 10,
                          right: 10,
                          child: Shimmer.fromColors(
                            baseColor: Colors.white,
                            highlightColor: Colors.blue.shade200,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                              decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.8),
                                  borderRadius: BorderRadius.circular(20)),
                              child: const Text("Verified 🛡", style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold)),
                            ),
                          ),
                        )
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Type: ${pashu['type'] ?? ''}"),
                          Text("Age: ${pashu['age'] ?? ''}"),
                          Text("Price: ₹${pashu['price'] ?? ''}"),
                          Text("Negotiable: ${pashu['negotiable'] ?? ''}"),
                          Text("Owner: ${pashu['username'] ?? ''} ji"),
                          Text("Distance: ${dist.toStringAsFixed(1)} km"),
                          const SizedBox(height: 8),
                          ElevatedButton(
                              onPressed: () {}, child: const Text("More Details"))
                        ],
                      ),
                    )
                  ],
                ),
              );
            } else {
              return Padding(
                padding: const EdgeInsets.all(12.0),
                child: Text("💡 Only Active Pashu Can Be Verified",
                    style: TextStyle(color: Colors.grey.shade700, fontWeight: FontWeight.bold)),
              );
            }
          },
        ),
      ),
    );
  }
}
