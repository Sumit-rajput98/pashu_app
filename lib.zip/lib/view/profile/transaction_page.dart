import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:pashu_app/core/shared_pref_helper.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class Transaction {
  final String amount;
  final String createdAt;
  final String razorpayPaymentId;
  final String type;
  final String status;
  final String comment;

  Transaction({
    required this.amount,
    required this.createdAt,
    required this.razorpayPaymentId,
    required this.type,
    required this.status,
    required this.comment,
  });

  factory Transaction.fromJson(Map<String, dynamic> json) {
    return Transaction(
      amount: json['amount'].toString(),
      createdAt: json['created_at'],
      razorpayPaymentId: json['razorpay_payment_id'] ?? '',
      type: json['type'],
      status: json['status'],
      comment: json['comment'] ?? '',
    );
  }
}

class TransactionPage extends StatefulWidget {
  const TransactionPage({super.key});

  @override
  State<TransactionPage> createState() => _TransactionPageState();
}

class _TransactionPageState extends State<TransactionPage> {
  List<Transaction> transactions = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchUserDataAndTransactions();
  }

  Future<void> fetchUserDataAndTransactions() async {
    try {

      final number = await SharedPrefHelper.getPhoneNumber();
      if (number != null) {
        final response = await http.get(Uri.parse(
            'https://pashuparivar.com/api/getprofileByNumber/$number'));

        final data = jsonDecode(response.body);
        final user = data['result'][0];
        final userId = user['id'].toString();

        await fetchTransactions(userId);
      }
    } catch (e) {
      print('Error fetching user or transactions: $e');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> fetchTransactions(String userId) async {
    try {
      final response = await http.get(Uri.parse(
          'https://pashuparivar.com/api/payment/transactions/$userId'));
      final data = jsonDecode(response.body);
      final txList = data['transactions'] ?? [];

      setState(() {
        transactions = txList.map((e) => Transaction.fromJson(e)).toList();
      });
    } catch (e) {
      print("Error fetching transactions: $e");
    }
  }

  Map<String, String> formatDateTime(String datetime) {
    final date = DateTime.parse(datetime);
    return {
      'date': "${date.day}/${date.month}/${date.year}",
      'time': "${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}",
    };
  }

  Widget buildRow(String label, String value,
      {Color? color,
        bool bold = false,
        bool capitalize = false,
        TextStyle? valueStyle}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style: const TextStyle(fontSize: 14, color: Color(0xFF6B7280))),
          SizedBox(
            width: 150,
            child: Text(
              capitalize ? value[0].toUpperCase() + value.substring(1) : value,
              textAlign: TextAlign.right,
              style: valueStyle ??
                  TextStyle(
                    fontSize: bold ? 16 : 14,
                    fontWeight: bold ? FontWeight.bold : FontWeight.w500,
                    color: color ?? const Color(0xFF111827),
                  ),
            ),
          ),
        ],
      ),
    );
  }

  TextStyle getStatusStyle(String status) {
    switch (status) {
      case 'success':
        return const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: Color(0xFF16A34A),
            backgroundColor: Color(0xFFC7F0D6));
      case 'pending':
        return const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: Color(0xFF8A6D3B),
            backgroundColor: Color(0xFFF5EDC6));
      default:
        return const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: Colors.white,
            backgroundColor: Color(0xFFE38888));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F4F6),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(16, 80, 16, 80),
        child: Column(
          children: [
            const Text(
              'Transaction History',
              style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF234B5C)),
            ),
            const SizedBox(height: 16),
            if (isLoading)
              const Center(child: CircularProgressIndicator())
            else if (transactions.isEmpty)
              const Text(
                'No transactions found',
                style: TextStyle(fontSize: 16, color: Color(0xFF6B7280)),
              )
            else
              Expanded(
                child: ListView.builder(
                  itemCount: transactions.length,
                  itemBuilder: (context, index) {
                    final tx = transactions[index];
                    final formatted = formatDateTime(tx.createdAt);
                    return Card(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)),
                      elevation: 3,
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            buildRow('Amount', '₹${tx.amount}',
                                color: tx.type == 'debit'
                                    ? Colors.red
                                    : const Color(0xFF16A34A),
                                bold: true),
                            buildRow('Date', formatted['date']!),
                            buildRow('Time', formatted['time']!),
                            buildRow('Payment Code', tx.razorpayPaymentId),
                            buildRow('Type', tx.type, capitalize: true),
                            buildRow('Status', tx.status,
                                valueStyle: getStatusStyle(tx.status)),
                            if (tx.status == 'success' || tx.status == 'failed')
                              Container(
                                margin: const EdgeInsets.only(top: 8),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 5),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFF5F7FA),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: buildRow(
                                  tx.status == 'success'
                                      ? 'UTR Number:'
                                      : 'Message:',
                                  tx.comment,
                                  valueStyle: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                    color: Color(0xFF111827),
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}
