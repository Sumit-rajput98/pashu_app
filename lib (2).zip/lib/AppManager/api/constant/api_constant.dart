class ApiConstant{
  static String baseUrl = "https://pashuparivar.com/";
}