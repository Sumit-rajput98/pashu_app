import 'package:flutter/material.dart';
import 'package:pashu_app/view/invest/widget/project_faq_widget.dart';
import 'package:pashu_app/view/invest/widget/project_lot_selector_widget.dart';
import 'package:pashu_app/view/invest/widget/project_overview_widget.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../core/shared_pref_helper.dart';
import '../../model/invest/invest_model.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import '../auth/profile_page.dart';
import '../custom_app_bar.dart';
import '../profile/show_lang.dart';

class InvestDetailsPage extends StatefulWidget {
  final InvestModel project;

  const InvestDetailsPage({super.key, required this.project});

  @override
  State<InvestDetailsPage> createState() => _InvestDetailsPageState();
}

class _InvestDetailsPageState extends State<InvestDetailsPage> {
  int selectedLots = 1;
  late Razorpay _razorpay;

  @override
  void initState() {
    super.initState();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void dispose() {
    _razorpay.clear();
    super.dispose();
  }

  void incrementLots() {
    if (selectedLots < widget.project.availableSlots) {
      setState(() {
        selectedLots++;
      });
    }
  }

  void decrementLots() {
    if (selectedLots > 1) {
      setState(() {
        selectedLots--;
      });
    }
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) async {
    final l10n = AppLocalizations.of(context)!;
    final project = widget.project;
    final amount = selectedLots * 1;

    try {
      final verifyRes = await http.post(
        Uri.parse('https://pashuparivar.com/api/payment/verify-investment-payment'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "userId": 1, // replace with actual userId
          "amount": amount,
          "slot": selectedLots,
          "razorpay_order_id": response.orderId,
          "razorpay_payment_id": response.paymentId,
          "razorpay_signature": response.signature,
        }),
      );

      final verifyJson = jsonDecode(verifyRes.body);

      if (verifyJson["success"] == true) {
        await http.post(
          Uri.parse("https://pashuparivar.com/api/investment_record"),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            "user_id": 1, // replace with actual userId
            "investment_id": project.id,
            "slots": selectedLots,
            "price": amount,
          }),
        );

        Fluttertoast.showToast(
          msg: l10n.paymentCompletedSuccessfully,
        );
      } else {
        Fluttertoast.showToast(
          msg: l10n.paymentVerificationFailed,
        );
      }
    } catch (e) {
      Fluttertoast.showToast(
        msg: l10n.errorVerifyingPayment,
      );
    }
  }

  void _initiatePayment() async {
    final l10n = AppLocalizations.of(context)!;
    final amount = selectedLots * 1;

    try {
      final orderRes = await http.post(
        Uri.parse('https://pashuparivar.com/api/payment/create-order'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'amount': amount}),
      );

      final orderJson = jsonDecode(orderRes.body);
      final orderId = orderJson['orderId'];

      var options = {
        'key': 'rzp_live_gm2iOnFy9nUmUx',
        'amount': amount * 100,
        'currency': 'INR',
        'name': 'Pashu Parivar',
        'description': l10n.investIn(widget.project.title),
        'order_id': orderId,
        'image': 'https://pashuparivar.com/uploads/newlogo.png',
        'prefill': {
          'name': 'Demo User', // Replace with actual
          'contact': '9999999999',
          'email': 'demo@pashuparivar.com',
        },
        'theme': {'color': '#A5BE7E'},
      };

      _razorpay.open(options);
    } catch (e) {
      Fluttertoast.showToast(msg: l10n.couldNotInitiatePayment);
    }
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    final l10n = AppLocalizations.of(context)!;
    Fluttertoast.showToast(
      msg: l10n.paymentFailed(response.message ?? ''),
    );
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    final l10n = AppLocalizations.of(context)!;
    Fluttertoast.showToast(
      msg: l10n.externalWalletSelected(response.walletName ?? ''),
    );
  }

  Future<void> openPdfInBrowser(String url) async {
    final uri = Uri.parse(url);
    try {
      final success = await launchUrl(
        uri,
        mode: LaunchMode.externalApplication,
      );
      if (!success) {
        debugPrint("Launch failed for $uri");
      }
    } catch (e) {
      debugPrint("Exception while launching PDF: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final project = widget.project;

    return Scaffold(
      appBar: CustomAppBar(
        onProfileTap: () async {
          String? phoneNum = await SharedPrefHelper.getPhoneNumber();
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ProfilePage(phoneNumber: phoneNum ?? ''),
            ),
          );
        },
        onLanguageTap: () => showLanguageDialog(context),
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Project Image
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                "https://pashuparivar.com/uploads/${project.projectImage}",
                height: 200,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 16),

            // Description & Lots Selection
            ProjectLotSelectorWidget(
              project: widget.project,
              selectedLots: selectedLots,
              onIncrement: incrementLots,
              onDecrement: decrementLots,
              onProceed: _initiatePayment,
            ),

            // Project Overview
            ProjectOverviewWidget(project: widget.project),
            const SizedBox(height: 20),

            // Project Report
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.orange.shade50,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.picture_as_pdf),
                      const SizedBox(width: 8),
                      Text(
                        l10n.projectReport,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(l10n.projectReportDescription),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: () {
                        final pdfUrl = "https://pashuparivar.com/uploads/${project.projectReport}";
                        openPdfInBrowser(pdfUrl);
                      },
                      icon: const Icon(Icons.download),
                      label: Text(l10n.downloadReport),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange.shade700,
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const ProjectFAQWidget(),
          ],
        ),
      ),
    );
  }
}
