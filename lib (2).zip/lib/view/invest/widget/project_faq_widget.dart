import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class ProjectFAQWidget extends StatefulWidget {
  const ProjectFAQWidget({super.key});

  @override
  State<ProjectFAQWidget> createState() => _ProjectFAQWidgetState();
}

class _ProjectFAQWidgetState extends State<ProjectFAQWidget> {
  List<bool> expanded = [];

  @override
  void initState() {
    super.initState();
    expanded = List.generate(8, (index) => false); // 8 FAQ items
  }

  void toggle(int index) {
    setState(() {
      expanded[index] = !expanded[index];
    });
  }

  List<Map<String, String>> getFAQs(AppLocalizations l10n) {
    return [
      {
        "question": l10n.faqQuestion1,
        "answer": l10n.faqAnswer1,
      },
      {
        "question": l10n.faqQuestion2,
        "answer": l10n.faqAnswer2,
      },
      {
        "question": l10n.faqQuestion3,
        "answer": l10n.faqAnswer3,
      },
      {
        "question": l10n.faqQuestion4,
        "answer": l10n.faqAnswer4,
      },
      {
        "question": l10n.faqQuestion5,
        "answer": l10n.faqAnswer5,
      },
      {
        "question": l10n.faqQuestion6,
        "answer": l10n.faqAnswer6,
      },
      {
        "question": l10n.faqQuestion7,
        "answer": l10n.faqAnswer7,
      },
      {
        "question": l10n.faqQuestion8,
        "answer": l10n.faqAnswer8,
      },
    ];
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final faqs = getFAQs(l10n);

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFDEF0C2), Colors.white],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.help_outline),
              const SizedBox(width: 8),
              Text(
                l10n.frequentlyAskedQuestions,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: Color(0xFF1E4A59),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...List.generate(faqs.length, (index) {
            return Column(
              children: [
                InkWell(
                  onTap: () => toggle(index),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Text(
                            faqs[index]['question']!,
                            style: const TextStyle(
                              fontWeight: FontWeight.w600,
                              color: Colors.black87,
                            ),
                          ),
                        ),
                        Icon(expanded[index]
                            ? Icons.keyboard_arrow_up
                            : Icons.keyboard_arrow_down),
                      ],
                    ),
                  ),
                ),
                if (expanded[index])
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Text(
                      faqs[index]['answer']!,
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.black54,
                      ),
                    ),
                  ),
                const Divider(thickness: 0.5),
              ],
            );
          }),
        ],
      ),
    );
  }
}
