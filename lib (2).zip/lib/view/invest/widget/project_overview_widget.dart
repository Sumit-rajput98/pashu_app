import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import '../../../model/invest/invest_model.dart';

class ProjectOverviewWidget extends StatelessWidget {
  final InvestModel project;

  const ProjectOverviewWidget({super.key, required this.project});

  Widget _buildRow(String key, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 140,
            child: Text(
              key,
              style: const TextStyle(
                fontWeight: FontWeight.w500,
                color: Colors.black87,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontWeight: FontWeight.w400,
                color: Colors.black54,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Container(
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: Colors.blue.shade50,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.info_outline),
              const SizedBox(width: 8),
              Text(
                l10n.projectOverview,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ],
          ),
          const SizedBox(height: 16),

          _buildRow(l10n.owner, project.owner),
          _buildRow(l10n.investmentType, project.investmentType),
          _buildRow(l10n.address, project.address),
          _buildRow(l10n.projectValue, "₹${project.projectValue}"),
          _buildRow(l10n.roi, "N/A"),
          _buildRow(l10n.lotPrice, "₹1"),
          _buildRow(l10n.availableLots, "${project.availableSlots}"),
          _buildRow(l10n.startTime, project.projectStartDate.substring(0, 10)),
          _buildRow(l10n.harvestTime, project.expectedHarvest.substring(0, 10)),
          _buildRow(l10n.duration, project.duration),
          _buildRow(l10n.projectManagerContact, project.notes),
        ],
      ),
    );
  }
}
