import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import '../../core/language_helper.dart';
import '../../core/locale_helper.dart';

void showLanguageDialog(BuildContext context) async {
  String? selectedLanguage = await LanguageHelper.getLocale();

  showDialog(
    context: context,
    builder: (context) {
      return Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        backgroundColor: const Color(0xFFE9F0DA),
        child: StatefulBuilder(
          builder: (context, setState) {
            return Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    AppLocalizations.of(context)!.selectLanguage,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    height: 200,
                    child: ListView.builder(
                      itemCount: LanguageHelper.languageOptions.length,
                      itemBuilder: (context, index) {
                        final lang = LanguageHelper.languageOptions[index];
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              selectedLanguage = lang['id'];
                            });
                          },
                          child: Container(
                            height: 48,
                            alignment: Alignment.center,
                            margin: const EdgeInsets.symmetric(vertical: 4),
                            decoration: BoxDecoration(
                              color:
                              selectedLanguage == lang['id']
                                  ? const Color(0xFFB4D5A6)
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              lang['label']!,
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w500,
                                color:
                                selectedLanguage == lang['id']
                                    ? const Color(0xFF1E4A59)
                                    : Colors.black87,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                      selectedLanguage != null
                          ? const Color(0xFF1E4A59)
                          : Colors.grey[400],
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    onPressed:
                    selectedLanguage == null
                        ? null
                        : () async {
                      if (!context.mounted) return;
                      Provider.of<LocaleProvider>(
                        context,
                        listen: false,
                      ).setLocale(selectedLanguage!);
                      Navigator.of(context).pop();
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 32,
                        vertical: 10,
                      ),
                      child: Text(
                        AppLocalizations.of(context)!.ok,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      );
    },
  );
}