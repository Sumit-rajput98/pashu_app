// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get welcome => 'Welcome to Pashu Parivar';

  @override
  String get locationPermissionTitle => 'Location Permission';

  @override
  String get locationPermissionMessage => 'App needs access to your location.';

  @override
  String get permissionDenied => 'Permission Denied';

  @override
  String get permissionRetryMessage =>
      'Location permission is required to use this feature. Would you like to try again?';

  @override
  String get yes => 'Yes';

  @override
  String get no => 'No';

  @override
  String get hi => 'Hi';

  @override
  String get newAnimal => 'New Animal';

  @override
  String get newBuyers => 'New Buyers';

  @override
  String get buyAnimal => 'Buy Animal';

  @override
  String get sellAnimal => 'Sell Animal';

  @override
  String get otherServices => 'Other Services';

  @override
  String get knowMore => 'Know More';

  @override
  String get clicklive => 'View Live';

  @override
  String get insurance => 'Insurance';

  @override
  String get health => 'Health';

  @override
  String get liverace => 'Live Races';

  @override
  String get feed => 'Feed';

  @override
  String get getLocation => 'Get Location';

  @override
  String get getLocationMessage => 'Get Location For Your Pashu 📍';

  @override
  String get comingSoon => 'Coming Soon';

  @override
  String get firstUsers => 'First 10,000 Users will get';

  @override
  String get referralBonusOnly => 'referral bonus – Only';

  @override
  String slotsLeft(Object slot) {
    return '$slot slots are left!';
  }

  @override
  String get applyNow => 'Apply Now';

  @override
  String get pashuLoan => 'Pashu Loan';

  @override
  String get pashuInsurance => 'PASHU INSURANCE';

  @override
  String get investInFarming => 'Invest';

  @override
  String get growWealth => 'Grow your wealth with nature';

  @override
  String get startInvesting => 'Start Investing';

  @override
  String get editProfile => 'Edit Profile';

  @override
  String get animalHistory => 'Animal List History';

  @override
  String get referralCode => 'Referral Code';

  @override
  String get logout => 'Logout';

  @override
  String get yourListedPashu => 'Your Listed Pashu';

  @override
  String get termsPrivacy => 'Terms & Privacy';

  @override
  String get contactUs => 'Contact Us';

  @override
  String get account => 'Account';

  @override
  String get soldOutPashuHistory => 'Sold Out Pashu History';

  @override
  String get walletBalance => 'Wallet Balance';

  @override
  String get addAmountInWallet => 'Add Amount & Get Plans';

  @override
  String get myTransaction => 'My Transaction';

  @override
  String get addMoneyToWallet => 'Add Money to Your Wallet';

  @override
  String get enterAmount => 'Enter Amount';

  @override
  String get enterAmountExample => 'Enter Amount e.g. 500';

  @override
  String get add => 'Add';

  @override
  String get walletTip =>
      'Tip: Your wallet can be used to see the contact details instantly.';

  @override
  String get getVerifiedPashu => 'Get Verified Your Pashu';

  @override
  String get withdrawBalance => 'Withdraw Balance';

  @override
  String get signIn => 'Sign In';

  @override
  String get enterPhoneNumberToContinue =>
      'Enter your phone number to continue';

  @override
  String get phoneNumber => 'Phone Number';

  @override
  String get enterPhoneNumber => 'Enter phone number';

  @override
  String get sendOTP => 'Send OTP';

  @override
  String get or => 'OR';

  @override
  String get dontHaveAccount => 'Don\'t have an account? Register Now';

  @override
  String get phoneNumberRequired => 'Phone number is required';

  @override
  String get enterValidPhoneNumber =>
      'Enter a valid 10-digit Indian phone number';

  @override
  String otpSentTo(Object phoneNumber) {
    return 'OTP sent to +91 $phoneNumber';
  }

  @override
  String get register => 'Register';

  @override
  String get login => 'Login';

  @override
  String get registerNow => 'Register Now';

  @override
  String get enterYourName => 'Enter your name';

  @override
  String get enterReferralCode => 'Enter Referral Code (Optional)';

  @override
  String get getOTP => 'Get OTP';

  @override
  String get alreadyHaveAccount => 'Already have an Account? Sign In';

  @override
  String get optional => 'Optional';

  @override
  String get nameIsRequired => 'Name is required';

  @override
  String get nameMinLength => 'Name must be at least 2 characters long';

  @override
  String get failedToSendOTP => 'Failed to send OTP. Please try again.';

  @override
  String get enterOTP => 'Enter OTP';

  @override
  String otpSentMessage(Object phoneNumber) {
    return 'We have sent a 6-digit OTP to +91 $phoneNumber';
  }

  @override
  String get enterComplete6DigitOTP => 'Please enter complete 6-digit OTP';

  @override
  String get successfulLogin => 'Successful Login';

  @override
  String get didntReceiveOTP => 'Didn\'t receive OTP?';

  @override
  String resendIn(Object seconds) {
    return 'Resend in ${seconds}s';
  }

  @override
  String get resendOTP => 'Resend OTP';

  @override
  String get resending => 'Resending...';

  @override
  String otpResentTo(Object phoneNumber) {
    return 'OTP resent to +91 $phoneNumber';
  }

  @override
  String get failedToResendOTP => 'Failed to resend OTP. Please try again.';

  @override
  String get homeScreen => 'Home';

  @override
  String get welcomeToHomeScreen => 'Welcome to the Home Screen!';

  @override
  String get newBadge => 'NEW';

  @override
  String get logoutConfirmation =>
      'Are you sure you want to logout from your account?';

  @override
  String get cancel => 'Cancel';

  @override
  String get failedToLoadProfile => 'Failed to Load Profile';

  @override
  String get uploadPashuImageOne => 'Upload Your Pashu Image One';

  @override
  String get selectPictureOne => 'SELECT PICTURE ONE';

  @override
  String get uploadPashuImageTwo => 'Upload Your Pashu Image Two';

  @override
  String get selectPictureTwo => 'SELECT PICTURE TWO';

  @override
  String get paymentCompletedSuccessfully => 'Payment completed successfully!';

  @override
  String get paymentVerificationFailed =>
      'Payment verification failed. Please try again.';

  @override
  String get errorVerifyingPayment => 'Error verifying payment';

  @override
  String get insuranceApplication => 'Insurance Application';

  @override
  String get responseReceived => 'Response Received!';

  @override
  String get insuranceThankYouMessage =>
      'Thank you for submitting your pashu insurance application. Our team will get back to you soon with further details.';

  @override
  String get selectLanguage => 'Select Language';

  @override
  String get ok => 'OK';

  @override
  String get appTitle => 'Pashu Parivar';

  @override
  String get languageShort => 'हि/E/ತ';

  @override
  String get wishlist => 'Wishlist';

  @override
  String get loanFormTitle => 'Pashu Loan Form';

  @override
  String get loanApplicationHeader => 'Animal Loan Application';

  @override
  String get loanApplicationSubheader =>
      'Get financial support for your livestock farming needs';

  @override
  String get loanApplicationDetails => 'Loan Application Details';

  @override
  String get applicantInformation => 'Applicant Information';

  @override
  String get applicantName => 'Applicant Name';

  @override
  String get applicantNameRequired => 'Applicant name is required';

  @override
  String get applicantAddress => 'Applicant Address';

  @override
  String get applicantAddressRequired => 'Applicant address is required';

  @override
  String get contactNumber => 'Contact Number';

  @override
  String get contactNumberRequired => 'Contact number is required';

  @override
  String get contactNumberInvalid => 'Please enter a valid contact number';

  @override
  String get emailAddress => 'Email Address';

  @override
  String get emailAddressRequired => 'Email address is required';

  @override
  String get emailAddressInvalid => 'Please enter a valid email address';

  @override
  String get loanInformation => 'Loan Information';

  @override
  String get loanAmount => 'Loan Amount (₹)';

  @override
  String get loanAmountRequired => 'Loan amount is required';

  @override
  String get loanAmountInvalid => 'Please enter a valid loan amount';

  @override
  String get repaymentPeriod => 'Repayment Period';

  @override
  String get repaymentPeriodRequired => 'Repayment period is required';

  @override
  String get incomeSource => 'Income Source';

  @override
  String get incomeSourceRequired => 'Income source is required';

  @override
  String get purposeOfLoan => 'Purpose of Loan';

  @override
  String get purposeOfLoanRequired => 'Purpose of loan is required';

  @override
  String get additionalInformation => 'Additional Information';

  @override
  String get additionalRemarks => 'Additional Remarks';

  @override
  String get additionalRemarksRequired => 'Additional remarks are required';

  @override
  String get submittingForm => 'Submitting Form...';

  @override
  String get submitForm => 'Submit Form';

  @override
  String get loanTermsNote =>
      'By submitting this form, you agree to our loan terms and conditions. Our team will review your application and contact you within 3-5 business days with loan approval status.';

  @override
  String get allFieldsRequired => 'All fields are required';

  @override
  String get animalInformation => 'Animal Information';

  @override
  String get animalAgeInvalid => 'Please enter a valid animal age';

  @override
  String get animalWeightInvalid => 'Please enter a valid animal weight';

  @override
  String get allowLocationAccess => 'Allow Location Access';

  @override
  String get locationDescription =>
      'We need your location to show nearby livestock, events, and personalized content based on your area.';

  @override
  String get locationPrivacyNote =>
      'Your location data is secure and only used to enhance your experience.';

  @override
  String get liveRaces => 'Live Races';

  @override
  String get viewLive => 'View Live';

  @override
  String get animalInsurance => 'Animal Insurance';

  @override
  String get insuranceFormTitle => 'Animal Insurance Form';

  @override
  String get insuranceApplicationHeader => 'Animal Insurance Application';

  @override
  String get insuranceApplicationSubheader =>
      'Get financial support for your animal insurance needs';

  @override
  String get insuranceApplicationDetails => 'Insurance Application Details';

  @override
  String get ownerInformation => 'Owner Information';

  @override
  String get ownerName => 'Owner Name';

  @override
  String get ownerNameRequired => 'Owner name is required';

  @override
  String get ownerAddress => 'Owner Address';

  @override
  String get ownerAddressRequired => 'Owner address is required';

  @override
  String get animalType => 'Animal Type';

  @override
  String get animalTypeRequired => 'Animal type is required';

  @override
  String get animalBreed => 'Animal Breed';

  @override
  String get animalBreedRequired => 'Animal breed is required';

  @override
  String get animalAge => 'Animal Age';

  @override
  String get animalAgeRequired => 'Animal age is required';

  @override
  String get animalColor => 'Animal Color';

  @override
  String get animalColorRequired => 'Animal color is required';

  @override
  String get animalWeight => 'Animal Weight';

  @override
  String get animalWeightRequired => 'Animal weight is required';

  @override
  String get healthStatus => 'Health Status';

  @override
  String get healthStatusRequired => 'Health status is required';

  @override
  String get insuranceTermsNote =>
      'By submitting this form, you agree to our insurance terms and conditions. Our team will review your application and contact you within 3-5 business days with insurance approval status.';

  @override
  String get liveRaceTitle => 'Live Race';

  @override
  String get liveRaceHeader => 'LIVE RACE';

  @override
  String get chooseRaceCategory => 'Choose Your Race Category';

  @override
  String get raceExperienceSubheader =>
      'Experience the thrill of traditional animal racing';

  @override
  String get raceCategoryFallback => 'Race Category';

  @override
  String get raceCategoryDetailFallback =>
      'Join the exciting race and experience the thrill of traditional animal racing';

  @override
  String get liveNow => 'Live Now';

  @override
  String get tapToJoin => 'Tap to Join';

  @override
  String get liveBadge => 'LIVE';

  @override
  String get failedToLoadCategories => 'Failed to Load Categories';

  @override
  String get somethingWentWrong => 'Something went wrong';

  @override
  String get retry => 'Retry';

  @override
  String get noLiveRacesAvailable => 'No Live Races Available';

  @override
  String get checkBackLater =>
      'Check back later for exciting live racing events';

  @override
  String get raceCategory => 'Race Category';

  @override
  String get traditionalRacingExperience => 'Traditional Racing Experience';

  @override
  String get raceInformation => 'Race Information';

  @override
  String get category => 'Category';

  @override
  String get status => 'Status';

  @override
  String get participants => 'Participants';

  @override
  String get multipleEntries => 'Multiple Entries';

  @override
  String get duration => 'Duration';

  @override
  String get ongoing => 'Ongoing';

  @override
  String get prize => 'Prize';

  @override
  String get trophiesAndRecognition => 'Trophies & Recognition';

  @override
  String get raceIsLiveNow => 'Race is Live Now!';

  @override
  String get watchExcitingCompetition =>
      'Watch the exciting competition unfold';

  @override
  String get aboutThisRace => 'About This Race';

  @override
  String get defaultRaceDescription =>
      'Experience the thrill of traditional animal racing in this exciting live event. Watch as skilled participants compete in this time-honored tradition that showcases the bond between humans and animals. This race category represents the rich cultural heritage of animal sports and provides an authentic glimpse into traditional racing practices.';

  @override
  String get liveStream => 'Live Stream';

  @override
  String get liveStreamComingSoon => 'Live Stream Coming Soon';

  @override
  String get youtubeLinksAvailable =>
      'YouTube links will be available when streaming begins';

  @override
  String get getNotifiedWhenStreaming =>
      'Get notified when live streaming starts for this race category';

  @override
  String get liveRace => 'LIVE RACE';

  @override
  String get na => 'N/A';

  @override
  String get regionalChampionship => 'Regional Championship';

  @override
  String get districtFinals => 'District Finals';

  @override
  String get stateCompetition => 'State Competition';

  @override
  String get tomorrowTenAM => 'Tomorrow 10:00 AM';

  @override
  String get nextWeek => 'Next Week';

  @override
  String get sellPashu => 'Sell Pashu';

  @override
  String get youCanProceedWithListing => 'You can proceed with listing';

  @override
  String get minimumRequiredToList =>
      'Minimum ₹15 required to list your animal';

  @override
  String get animalTypes => 'Animal Types';

  @override
  String get selectAnimalType => 'Select Animal Type';

  @override
  String get animalCategory => 'Animal Category';

  @override
  String get pleaseSelectAnimalTypeFirst => 'Please select animal type first';

  @override
  String get selectAnimalCategory => 'Select Animal Category';

  @override
  String get nameOfTheAnimal => 'Name of The Animal';

  @override
  String get enterAnimalAge => 'Enter Animal Age';

  @override
  String get selectGenderOfAnimal => 'Select Gender of Animal';

  @override
  String get price => 'Price';

  @override
  String get negotiable => 'Negotiable';

  @override
  String get isPriceNegotiable => 'Is price negotiable?';

  @override
  String get yourPhoneNumber => 'Your Phone Number';

  @override
  String get enterYourPhoneNumber => 'Enter your phone number';

  @override
  String get animalDescription => 'Animal Description';

  @override
  String get enterAnimalDescription => 'Enter Animal Description';

  @override
  String get getAddressForPashu => 'Get Address for Pashu';

  @override
  String get submitAndPay => 'Submit & Pay ₹15';

  @override
  String get insufficientBalance => 'Insufficient balance. Please add funds.';

  @override
  String get submitting => 'Submitting...';

  @override
  String get locationServicesDisabled => 'Location services are disabled';

  @override
  String get locationPermissionPermanentlyDenied =>
      'Location permission permanently denied';

  @override
  String get locationPermissionDenied => 'Location permission denied';

  @override
  String get unableToDetermineAddress => 'Unable to determine address';

  @override
  String get error => 'Error';

  @override
  String get missingRequiredFields => 'Missing Required Fields';

  @override
  String get pleaseEnterValidPhoneNumber => 'Please enter a valid phone number';

  @override
  String get pleaseEnterValidAge => 'Please enter a valid age';

  @override
  String get pleaseEnterValidPrice => 'Please enter a valid price';

  @override
  String get pashuListedSuccessfully => 'Pashu listed successfully!';

  @override
  String get errorOccurred => 'An error occurred';

  @override
  String get selectCategory => 'Select Category';

  @override
  String get selectGender => 'Select Gender';

  @override
  String get male => 'Male';

  @override
  String get female => 'Female';

  @override
  String get user => 'User';

  @override
  String get other => 'Other';

  @override
  String get unknown => 'Unknown';

  @override
  String get traditionalSportsAnimal => 'Traditional Sports Animal';

  @override
  String get livestockAnimal => 'Livestock Animal';

  @override
  String get petAnimal => 'Pet Animal';

  @override
  String get farmHouseAnimal => 'Farm House Animal';

  @override
  String get bull => 'Bull';

  @override
  String get camel => 'Camel';

  @override
  String get bird => 'Bird';

  @override
  String get pigeon => 'Pigeon';

  @override
  String get cock => 'Cock';

  @override
  String get dog => 'Dog';

  @override
  String get goat => 'Goat';

  @override
  String get horse => 'Horse';

  @override
  String get buffalo => 'Buffalo';

  @override
  String get sheep => 'Sheep';

  @override
  String get pigs => 'Pigs';

  @override
  String get cat => 'Cat';

  @override
  String get fishes => 'Fishes';

  @override
  String get smallMammals => 'Small Mammals';

  @override
  String get searchAnimalsBreeds => 'Search animals, breeds...';

  @override
  String get unknownAnimal => 'Unknown Animal';

  @override
  String get breed => 'Breed';

  @override
  String get owner => 'Owner';

  @override
  String get callMe => 'Call me';

  @override
  String get buyNow => 'Buy Now';

  @override
  String get addedToWishlist => 'added to wishlist';

  @override
  String get animal => 'Animal';

  @override
  String get failedToAddToWishlist => 'Failed to add to wishlist';

  @override
  String get noAnimalsFound => 'No animals found';

  @override
  String get trySelectingDifferentCategory =>
      'Try selecting a different category';

  @override
  String get checkBackLaterForNewListings =>
      'Check back later for new listings';

  @override
  String get purchaseRequestSent => 'Purchase request sent for';

  @override
  String get all => 'All';

  @override
  String get cow => 'Cow';

  @override
  String get cats => 'Cats';

  @override
  String get animalDetails => 'Animal Details';

  @override
  String get photos => 'Photos';

  @override
  String get type => 'Type';

  @override
  String get age => 'Age';

  @override
  String get gender => 'Gender';

  @override
  String get years => 'years';

  @override
  String get pricingInformation => 'Pricing Information';

  @override
  String get fixedPrice => 'Fixed Price';

  @override
  String get ownerAndLocation => 'Owner & Location';

  @override
  String get location => 'Location';

  @override
  String get distance => 'Distance';

  @override
  String get notSpecified => 'Not specified';

  @override
  String get meters => 'meters';

  @override
  String get km => 'km';

  @override
  String get description => 'Description';

  @override
  String get contactSeller => 'Contact Seller';

  @override
  String get unlockContactDetails =>
      'Unlock contact details for ₹2 to connect with the seller';

  @override
  String get unlocking => 'Unlocking...';

  @override
  String get unlockContact => 'Unlock Contact (₹2)';

  @override
  String get contactOptions => 'Contact Options';

  @override
  String get call => 'Call';

  @override
  String get whatsApp => 'WhatsApp';

  @override
  String get contact => 'Contact';

  @override
  String get notAvailable => 'Not available';

  @override
  String get userNotLoggedIn => 'User not logged in';

  @override
  String get userDataNotFound => 'User data not found';

  @override
  String get contactAlreadyUnlocked => 'This contact is already unlocked.';

  @override
  String get contactUnlockedSuccessfully => 'Contact unlocked successfully!';

  @override
  String get couldNotLaunchPhoneApp => 'Could not launch phone app';

  @override
  String get phoneNumberNotAvailable => 'Phone number not available';

  @override
  String get couldNotOpenWhatsApp => 'Could not open WhatsApp';

  @override
  String whatsAppMessageTemplate(Object animalName) {
    return 'Hi, I am interested in your $animalName listed on Pashu Parivar.';
  }

  @override
  String get locationNotAvailable => 'Location not available';

  @override
  String get remove => 'Remove';

  @override
  String get removedFromWishlist => 'Removed from wishlist';

  @override
  String get failedToRemove => 'Failed to remove';

  @override
  String get animalDetailsComingSoon => 'Animal Details Coming Soon';

  @override
  String get fullAnimalDetailsModal =>
      'Full animal details modal will be implemented here';

  @override
  String get noWishlistAnimalsFound => 'No wishlist animals found';

  @override
  String get tryAddingAnimalsToWishlist =>
      'Try adding some animals to your wishlist!';

  @override
  String get investmentProject => 'Investment Project';

  @override
  String get upcomingProjects => 'Upcoming Projects';

  @override
  String get liveProjects => 'Live Projects';

  @override
  String get completedProjects => 'Completed Projects';

  @override
  String get mvpForAquacultureInvestment => 'MVP for aquaculture investment';

  @override
  String get longTerm => 'Long Term';

  @override
  String get amount => 'Amount';

  @override
  String get startDate => 'Start Date';

  @override
  String get sixToEightMonths => '6 to 8 months';

  @override
  String get lotsBooked => 'Lots Booked';

  @override
  String get noProjectsAvailable => 'No projects available.';

  @override
  String get firstAugust2025 => '1st August 2025';

  @override
  String get addAmountAndGetPlans => 'Add Amount & Get Plans';

  @override
  String get getVerifiedYourPashu => 'Get Verified Your Pashu';

  @override
  String get termsAndPrivacy => 'Terms & Privacy';

  @override
  String get newA => 'NEW';

  @override
  String get areYouSureLogout =>
      'Are you sure you want to logout from your account?';

  @override
  String get noProfileFound => 'No Profile Found';

  @override
  String get profileInformationNotAvailable =>
      'Profile information is not available';

  @override
  String get subscriptionPlans => 'Subscription Plans';

  @override
  String get chooseYourPlan => 'Choose Your Plan';

  @override
  String get unlockPremiumFeatures =>
      'Unlock premium features and grow your livestock business with our subscription plans';

  @override
  String get diamondPlan => 'Diamond Plan';

  @override
  String get goldPlan => 'Gold Plan';

  @override
  String get silverPlan => 'Silver Plan';

  @override
  String get year => 'Year';

  @override
  String get months3 => '3 Months';

  @override
  String get month => 'Month';

  @override
  String get choosePlan => 'Choose Plan';

  @override
  String get unlimitedPashuProfileContact => 'Unlimited Pashu Profile Contact';

  @override
  String get unlimitedFreePashuListings => 'Unlimited Free Pashu Listings';

  @override
  String get priorityCustomerSupport => 'Priority Customer Support';

  @override
  String get advancedAnalytics => 'Advanced Analytics';

  @override
  String get premiumBadge => 'Premium Badge';

  @override
  String get freePashuListings10 => '10 Free Pashu Listings';

  @override
  String get standardCustomerSupport => 'Standard Customer Support';

  @override
  String get basicAnalytics => 'Basic Analytics';

  @override
  String get freePashuListings2 => '2 Free Pashu Listings';

  @override
  String get emailSupport => 'Email Support';

  @override
  String get addMoneyToYourWallet => 'Add Money to Your Wallet';

  @override
  String get addFundsToWallet =>
      'Add funds to your wallet and pay for subscriptions seamlessly. Your wallet can be used across all our services.';

  @override
  String get enterAmountEg500 => 'Enter Amount (e.g. 500)';

  @override
  String addAmount(String amount) {
    return 'Add ₹$amount';
  }

  @override
  String get tipWalletContact =>
      'Tip: Your wallet can be used to see the contact details instantly.';

  @override
  String subscribeToPlan(String planName) {
    return 'Subscribe to $planName';
  }

  @override
  String chargedForSubscription(String price, String period) {
    return 'You will be charged ₹$price for this $period subscription.';
  }

  @override
  String get confirmSubscription => 'Confirm Subscription';

  @override
  String get subscriptionSuccessful => 'Subscription Successful!';

  @override
  String subscriptionSuccessMessage(String planName) {
    return 'You have successfully subscribed to $planName. Enjoy all premium features!';
  }

  @override
  String get continueA => 'Continue';

  @override
  String get subscriptionHelp => 'Subscription Help';

  @override
  String get helpContent =>
      '• Diamond Plan: ₹365/Year\n• Gold Plan: ₹140/3 Months\n• Silver Plan: ₹49/Month\n• Cancel anytime from your profile\n• All features unlock immediately\n• 24/7 customer support included';

  @override
  String get gotIt => 'Got it';

  @override
  String get pleaseEnterValidAmount => 'Please enter a valid amount';

  @override
  String get couldNotInitiatePayment => 'Could not initiate payment';

  @override
  String get somethingWentWrongPayment =>
      'Something went wrong with the payment.';

  @override
  String get paymentCancelled =>
      'Payment was cancelled or didn\'t complete in time.';

  @override
  String get paymentFailed => 'Payment Failed';

  @override
  String get externalWalletSelected => 'External wallet selected';

  @override
  String get getInTouch => 'Get In Touch';

  @override
  String get contactUsDescription =>
      'We\'re here to help! Reach out to us anytime and we\'ll get back to you as soon as possible.';

  @override
  String get contactInformation => 'Contact Information';

  @override
  String get officeAddress => 'Office Address';

  @override
  String get pashuParivarHeadquarters =>
      'Pashu Parivar Headquarters\nBhopal, Madhya Pradesh\nIndia';

  @override
  String get sendUsAMessage => 'Send us a Message';

  @override
  String get fullName => 'Full Name';

  @override
  String get enterYourFullName => 'Enter your full name';

  @override
  String get enterYourEmailAddress => 'Enter your email address';

  @override
  String get message => 'Message';

  @override
  String get tellUsHowWeCanHelp => 'Tell us how we can help you...';

  @override
  String get sendingMessage => 'Sending Message...';

  @override
  String get sendMessage => 'Send Message';

  @override
  String get responseTimeNote =>
      'We typically respond within 24 hours during business days.';

  @override
  String get followUs => 'Follow Us';

  @override
  String get stayUpdatedWithNews =>
      'Stay updated with our latest news and updates';

  @override
  String get facebook => 'Facebook';

  @override
  String get instagram => 'Instagram';

  @override
  String get twitter => 'Twitter';

  @override
  String get youtube => 'YouTube';

  @override
  String get copiedToClipboard => 'Copied to clipboard!';

  @override
  String get messageSentSuccessfully => 'Message Sent Successfully!';

  @override
  String get thankYouForContacting =>
      'Thank you for contacting us. We\'ll get back to you within 24 hours.';

  @override
  String get nameMustBeAtLeast2Characters =>
      'Name must be at least 2 characters';

  @override
  String get emailIsRequired => 'Email is required';

  @override
  String get pleaseEnterValidEmail => 'Please enter a valid email address';

  @override
  String get messageIsRequired => 'Message is required';

  @override
  String get messageMustBeAtLeast10Characters =>
      'Message must be at least 10 characters';

  @override
  String get invest => 'Invest in Agri-Livestock';

  @override
  String get total => 'Total';

  @override
  String get active => 'Active';

  @override
  String get pending => 'PENDING';

  @override
  String get edit => 'Edit';

  @override
  String get delete => 'Delete';

  @override
  String get pendingStatus => 'PENDING';

  @override
  String get failedToLoadListings => 'Failed to Load Listings';

  @override
  String get noListedAnimals => 'No Listed Animals';

  @override
  String get noListedAnimalsDescription =>
      'You haven\'t listed any animals yet. Start by adding your first listing!';

  @override
  String get addNewListing => 'Add New Listing';

  @override
  String get deleteListing => 'Delete Listing';

  @override
  String deleteConfirmation(String animalName) {
    return 'Are you sure you want to delete \"$animalName\"? This action cannot be undone.';
  }

  @override
  String deleteSuccessMessage(String animalName) {
    return '$animalName deleted successfully';
  }

  @override
  String get withdrawFromWallet => 'Withdraw from Wallet';

  @override
  String get availableBalance => 'Available Balance';

  @override
  String get withdrawalEligible => 'Withdrawal Eligible';

  @override
  String get withdrawalRequirements => 'Withdrawal Requirements';

  @override
  String youHaveSpentAndCanWithdraw(String counter) {
    return 'You have spent ₹$counter and can withdraw funds';
  }

  @override
  String spendMoreToEnableWithdrawal(String amount, String counter) {
    return 'Spend ₹$amount more to enable withdrawal (Current: ₹$counter)';
  }

  @override
  String get withdrawalDetails => 'Withdrawal Details';

  @override
  String get enterAmountEg => 'Enter Amount e.g. 500';

  @override
  String get enterUpiIdEg => 'Enter UPI ID (e.g. example@upi)';

  @override
  String get enterUpiIdEgPlaceholder => 'Enter UPI ID e.g. example@upi';

  @override
  String get processing => 'Processing...';

  @override
  String withdrawAmount(String amount) {
    return 'Withdraw ₹$amount';
  }

  @override
  String get withdrawalRequirementsLabel => 'Withdrawal Requirements:';

  @override
  String get minimumSpendingRequired => '• Minimum spending of ₹50 required';

  @override
  String get walletBalanceRequired => '• Wallet balance must be ≥ ₹100';

  @override
  String currentSpending(String counter, String status) {
    return '• Current spending: ₹$counter ($status)';
  }

  @override
  String walletBalanceStatus(String balance, String status) {
    return '• Wallet balance: ₹$balance ($status)';
  }

  @override
  String get verified => '✓';

  @override
  String needMoreAmount(String amount) {
    return 'Need ₹$amount more';
  }

  @override
  String get tipWithdrawProcessingTime =>
      'Tip: Withdrawals are processed within 24-48 hours to your UPI account.';

  @override
  String get withdrawalRequestSubmitted => 'Withdrawal Request Submitted!';

  @override
  String withdrawalRequestSuccessMessage(String amount) {
    return 'Your withdrawal request of ₹$amount has been submitted successfully. You will receive the amount in your UPI account within 24-48 hours.';
  }

  @override
  String get failedToLoadData => 'Failed to Load Data';

  @override
  String get amountCannotBeEmpty => 'Amount cannot be empty';

  @override
  String amountCannotExceedBalance(String balance) {
    return 'Amount cannot exceed wallet balance (₹$balance)';
  }

  @override
  String get minimumWalletBalanceRequired =>
      'Minimum wallet balance of ₹100 required';

  @override
  String get upiIdCannotBeEmpty => 'UPI ID cannot be empty';

  @override
  String get pleaseEnterValidUpiId => 'Please enter a valid UPI ID';

  @override
  String get transactionHistory => 'Transaction History';

  @override
  String get noTransactions => 'No transactions';

  @override
  String get transactionSummary => 'Transaction Summary';

  @override
  String get totalCredit => 'Total Credit';

  @override
  String get totalDebit => 'Total Debit';

  @override
  String get successful => 'Successful';

  @override
  String get today => 'Today';

  @override
  String get yesterday => 'Yesterday';

  @override
  String daysAgo(String days) {
    return '$days days ago';
  }

  @override
  String get paymentId => 'Payment ID';

  @override
  String get fullDate => 'Full Date';

  @override
  String get utrNumber => 'UTR Number';

  @override
  String get failedToLoadTransactions => 'Failed to Load Transactions';

  @override
  String get noTransactionsFound => 'No Transactions Found';

  @override
  String get transactionHistoryDescription =>
      'Your transaction history will appear here once you make your first transaction';

  @override
  String get goBack => 'Go Back';

  @override
  String get success => 'SUCCESS';

  @override
  String get failed => 'FAILED';

  @override
  String get credit => 'CREDIT';

  @override
  String get debit => 'DEBIT';

  @override
  String get profileDetails => 'Profile Details';

  @override
  String get address => 'Address';

  @override
  String get notProvided => 'Not provided';

  @override
  String get profileDetailsSectionHeader => 'Profile Details';

  @override
  String get editProfileInformation => 'Edit Profile Information';

  @override
  String get nameCannotBeEmpty => 'Name cannot be empty';

  @override
  String get nameMinimumCharacters => 'Name must be at least 2 characters';

  @override
  String get addressCannotBeEmpty => 'Address cannot be empty';

  @override
  String get pleaseEnterCompleteAddress => 'Please enter a complete address';

  @override
  String get phoneAndReferralNotChangeable =>
      'Note: Phone number and referral code cannot be changed. Only name, email, and address can be updated.';

  @override
  String get updatingProfile => 'Updating Profile...';

  @override
  String get updateProfile => 'Update Profile';

  @override
  String get profileUpdatedSuccessfully => 'Profile Updated Successfully!';

  @override
  String get profileUpdateSuccessMessage =>
      'Your profile information has been updated successfully.';

  @override
  String get updateFailed => 'Update Failed';

  @override
  String get inviteEarnRewards => 'Invite & Earn Rewards';

  @override
  String get shareReferralDescription =>
      'Share your referral code with friends and family to earn exclusive rewards when they join Pashu Parivar';

  @override
  String get yourReferralCode => 'Your Referral Code';

  @override
  String get shareWithFriends => 'Share with Friends';

  @override
  String get shareLink => 'Share Link';

  @override
  String get copyLink => 'Copy Link';

  @override
  String get moreOptions => 'More Options';

  @override
  String get referralBenefits => 'Referral Benefits';

  @override
  String get earnRewards => 'Earn Rewards';

  @override
  String get earnRewardsDescription =>
      'Get exclusive rewards when your friends join using your code';

  @override
  String get helpFriends => 'Help Friends';

  @override
  String get helpFriendsDescription =>
      'Your friends also get special bonuses when they sign up';

  @override
  String get unlimitedSharing => 'Unlimited Sharing';

  @override
  String get unlimitedSharingDescription =>
      'Share your code as many times as you want with anyone';

  @override
  String get trackProgress => 'Track Progress';

  @override
  String get trackProgressDescription =>
      'Monitor your referral success and rewards in your profile';

  @override
  String get howItWorks => 'How It Works';

  @override
  String get shareYourCode => 'Share Your Code';

  @override
  String get shareYourCodeDescription =>
      'Send your referral code or link to friends and family';

  @override
  String get friendSignsUp => 'Friend Signs Up';

  @override
  String get friendSignsUpDescription =>
      'They create an account using your referral code';

  @override
  String get bothGetRewards => 'Both Get Rewards';

  @override
  String get bothGetRewardsDescription =>
      'You and your friend receive exclusive bonuses';

  @override
  String get linkCopiedToClipboard => 'Link copied to clipboard!';

  @override
  String get codeCopiedToClipboard => 'Code copied to clipboard!';

  @override
  String get referralHelp => 'Referral Help';

  @override
  String get referralHelpContent =>
      '• Share your unique referral code with friends\n• Both you and your friend get rewards\n• No limit on how many friends you can refer\n• Track your referrals in your profile\n• Rewards are credited automatically';

  @override
  String shareMessage(String referralCode, String referralUrl) {
    return '🐄 Join me on Pashu Parivar - India\'s trusted livestock marketplace! 🐄\n\nFind quality animals, connect with verified sellers, and grow your livestock business with premium features.\n\n✨ Use my referral code: $referralCode\n🎁 Get exclusive rewards for both of us!\n\nDownload now: $referralUrl\n\n#PashuParivar #Livestock #Farming #AnimalTrading';
  }

  @override
  String get termsOfService => 'Terms of Service';

  @override
  String get privacyPolicy => 'Privacy Policy';

  @override
  String get lastUpdated => 'Last updated: July 27, 2025';

  @override
  String get acceptanceOfTerms => 'Acceptance of Terms';

  @override
  String get acceptanceOfTermsContent =>
      'By accessing and using Pashu Parivar, you accept and agree to be bound by the terms and provision of this agreement.';

  @override
  String get useLicense => 'Use License';

  @override
  String get useLicenseContent =>
      'Permission is granted to temporarily download one copy of Pashu Parivar per device for personal, non-commercial transitory viewing only.';

  @override
  String get userResponsibilities => 'User Responsibilities';

  @override
  String get userResponsibilitiesContent =>
      '• Provide accurate information when creating listings\n• Respect other users and maintain professional conduct\n• Comply with all applicable laws and regulations\n• Not misuse the platform for fraudulent activities';

  @override
  String get platformServices => 'Platform Services';

  @override
  String get platformServicesContent =>
      'Pashu Parivar provides a platform for livestock trading, connecting buyers and sellers. We facilitate transactions but are not directly involved in the buying/selling process.';

  @override
  String get accountSecurity => 'Account Security';

  @override
  String get accountSecurityContent =>
      'Users are responsible for maintaining the confidentiality of their account information and password. Notify us immediately of any unauthorized use.';

  @override
  String get paymentTerms => 'Payment Terms';

  @override
  String get paymentTermsContent =>
      'All payments for premium services are processed securely. Subscription fees are non-refundable unless specified otherwise.';

  @override
  String get contentGuidelines => 'Content Guidelines';

  @override
  String get contentGuidelinesContent =>
      'All content uploaded must be appropriate, accurate, and comply with our community guidelines. We reserve the right to remove inappropriate content.';

  @override
  String get limitationOfLiability => 'Limitation of Liability';

  @override
  String get limitationOfLiabilityContent =>
      'Pashu Parivar shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of the service.';

  @override
  String get modifications => 'Modifications';

  @override
  String get modificationsContent =>
      'We reserve the right to modify these terms at any time. Users will be notified of significant changes.';

  @override
  String get contactInformationContent =>
      'For questions about these Terms of Service, please contact us at support@pashuparivar.com';

  @override
  String get informationWeCollect => 'Information We Collect';

  @override
  String get informationWeCollectContent =>
      '• Personal information: Name, phone number, email address\n• Profile information: Address, preferences, usage data\n• Device information: IP address, browser type, operating system\n• Usage data: App interactions, features used, session duration';

  @override
  String get howWeUseYourInformation => 'How We Use Your Information';

  @override
  String get howWeUseYourInformationContent =>
      'We use collected information to:\n• Provide and maintain our services\n• Process transactions and send notifications\n• Improve user experience and app functionality\n• Communicate with you about updates and offers';

  @override
  String get informationSharing => 'Information Sharing';

  @override
  String get informationSharingContent =>
      'We may share your information:\n• With other users (profile information in listings)\n• With service providers who assist our operations\n• When required by law or to protect our rights\n• With your consent for specific purposes';

  @override
  String get dataSecurity => 'Data Security';

  @override
  String get dataSecurityContent =>
      'We implement appropriate security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction.';

  @override
  String get dataRetention => 'Data Retention';

  @override
  String get dataRetentionContent =>
      'We retain your personal information only as long as necessary for the purposes outlined in this policy or as required by law.';

  @override
  String get yourRights => 'Your Rights';

  @override
  String get yourRightsContent =>
      'You have the right to:\n• Access your personal information\n• Correct inaccurate information\n• Delete your account and data\n• Opt-out of marketing communications';

  @override
  String get cookiesAndTracking => 'Cookies and Tracking';

  @override
  String get cookiesAndTrackingContent =>
      'We use cookies and similar technologies to enhance your experience, analyze usage patterns, and provide personalized content.';

  @override
  String get thirdPartyServices => 'Third-Party Services';

  @override
  String get thirdPartyServicesContent =>
      'Our app may contain links to third-party services. We are not responsible for their privacy practices.';

  @override
  String get childrensPrivacy => 'Children\'s Privacy';

  @override
  String get childrensPrivacyContent =>
      'Our service is not intended for children under 13. We do not knowingly collect personal information from children under 13.';

  @override
  String get changesToThisPolicy => 'Changes to This Policy';

  @override
  String get changesToThisPolicyContent =>
      'We may update this privacy policy from time to time. We will notify you of any changes by posting the new policy on this page.';

  @override
  String get privacyContactContent =>
      'If you have questions about this Privacy Policy, please contact us at:\nEmail: privacy@pashuparivar.com\nPhone: +91-XXXXXXXXXX';
}
