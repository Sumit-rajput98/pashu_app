import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_en.dart';
import 'app_localizations_hi.dart';
import 'app_localizations_kn.dart';
import 'app_localizations_ml.dart';
import 'app_localizations_ta.dart';
import 'app_localizations_te.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
    : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
        delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('en'),
    Locale('hi'),
    Locale('kn'),
    Locale('ml'),
    Locale('ta'),
    Locale('te'),
  ];

  /// No description provided for @welcome.
  ///
  /// In en, this message translates to:
  /// **'Welcome to Pashu Parivar'**
  String get welcome;

  /// No description provided for @locationPermissionTitle.
  ///
  /// In en, this message translates to:
  /// **'Location Permission'**
  String get locationPermissionTitle;

  /// No description provided for @locationPermissionMessage.
  ///
  /// In en, this message translates to:
  /// **'App needs access to your location.'**
  String get locationPermissionMessage;

  /// No description provided for @permissionDenied.
  ///
  /// In en, this message translates to:
  /// **'Permission Denied'**
  String get permissionDenied;

  /// No description provided for @permissionRetryMessage.
  ///
  /// In en, this message translates to:
  /// **'Location permission is required to use this feature. Would you like to try again?'**
  String get permissionRetryMessage;

  /// No description provided for @yes.
  ///
  /// In en, this message translates to:
  /// **'Yes'**
  String get yes;

  /// No description provided for @no.
  ///
  /// In en, this message translates to:
  /// **'No'**
  String get no;

  /// No description provided for @hi.
  ///
  /// In en, this message translates to:
  /// **'Hi'**
  String get hi;

  /// No description provided for @newAnimal.
  ///
  /// In en, this message translates to:
  /// **'New Animal'**
  String get newAnimal;

  /// No description provided for @newBuyers.
  ///
  /// In en, this message translates to:
  /// **'New Buyers'**
  String get newBuyers;

  /// No description provided for @buyAnimal.
  ///
  /// In en, this message translates to:
  /// **'Buy Animal'**
  String get buyAnimal;

  /// No description provided for @sellAnimal.
  ///
  /// In en, this message translates to:
  /// **'Sell Animal'**
  String get sellAnimal;

  /// No description provided for @otherServices.
  ///
  /// In en, this message translates to:
  /// **'Other Services'**
  String get otherServices;

  /// No description provided for @knowMore.
  ///
  /// In en, this message translates to:
  /// **'Know More'**
  String get knowMore;

  /// No description provided for @clicklive.
  ///
  /// In en, this message translates to:
  /// **'View Live'**
  String get clicklive;

  /// No description provided for @insurance.
  ///
  /// In en, this message translates to:
  /// **'Insurance'**
  String get insurance;

  /// No description provided for @health.
  ///
  /// In en, this message translates to:
  /// **'Health'**
  String get health;

  /// No description provided for @liverace.
  ///
  /// In en, this message translates to:
  /// **'Live Races'**
  String get liverace;

  /// No description provided for @feed.
  ///
  /// In en, this message translates to:
  /// **'Feed'**
  String get feed;

  /// No description provided for @getLocation.
  ///
  /// In en, this message translates to:
  /// **'Get Location'**
  String get getLocation;

  /// No description provided for @getLocationMessage.
  ///
  /// In en, this message translates to:
  /// **'Get Location For Your Pashu 📍'**
  String get getLocationMessage;

  /// No description provided for @comingSoon.
  ///
  /// In en, this message translates to:
  /// **'Coming Soon'**
  String get comingSoon;

  /// No description provided for @firstUsers.
  ///
  /// In en, this message translates to:
  /// **'First 10,000 Users will get'**
  String get firstUsers;

  /// No description provided for @referralBonusOnly.
  ///
  /// In en, this message translates to:
  /// **'referral bonus – Only'**
  String get referralBonusOnly;

  /// No description provided for @slotsLeft.
  ///
  /// In en, this message translates to:
  /// **'{slot} slots are left!'**
  String slotsLeft(Object slot);

  /// No description provided for @applyNow.
  ///
  /// In en, this message translates to:
  /// **'Apply Now'**
  String get applyNow;

  /// No description provided for @pashuLoan.
  ///
  /// In en, this message translates to:
  /// **'Pashu Loan'**
  String get pashuLoan;

  /// No description provided for @pashuInsurance.
  ///
  /// In en, this message translates to:
  /// **'PASHU INSURANCE'**
  String get pashuInsurance;

  /// No description provided for @investInFarming.
  ///
  /// In en, this message translates to:
  /// **'Invest'**
  String get investInFarming;

  /// No description provided for @growWealth.
  ///
  /// In en, this message translates to:
  /// **'Grow your wealth with nature'**
  String get growWealth;

  /// No description provided for @startInvesting.
  ///
  /// In en, this message translates to:
  /// **'Start Investing'**
  String get startInvesting;

  /// No description provided for @editProfile.
  ///
  /// In en, this message translates to:
  /// **'Edit Profile'**
  String get editProfile;

  /// No description provided for @animalHistory.
  ///
  /// In en, this message translates to:
  /// **'Animal List History'**
  String get animalHistory;

  /// No description provided for @referralCode.
  ///
  /// In en, this message translates to:
  /// **'Referral Code'**
  String get referralCode;

  /// No description provided for @logout.
  ///
  /// In en, this message translates to:
  /// **'Logout'**
  String get logout;

  /// No description provided for @yourListedPashu.
  ///
  /// In en, this message translates to:
  /// **'Your Listed Pashu'**
  String get yourListedPashu;

  /// No description provided for @termsPrivacy.
  ///
  /// In en, this message translates to:
  /// **'Terms & Privacy'**
  String get termsPrivacy;

  /// No description provided for @contactUs.
  ///
  /// In en, this message translates to:
  /// **'Contact Us'**
  String get contactUs;

  /// No description provided for @account.
  ///
  /// In en, this message translates to:
  /// **'Account'**
  String get account;

  /// No description provided for @soldOutPashuHistory.
  ///
  /// In en, this message translates to:
  /// **'Sold Out Pashu History'**
  String get soldOutPashuHistory;

  /// No description provided for @walletBalance.
  ///
  /// In en, this message translates to:
  /// **'Wallet Balance'**
  String get walletBalance;

  /// No description provided for @addAmountInWallet.
  ///
  /// In en, this message translates to:
  /// **'Add Amount & Get Plans'**
  String get addAmountInWallet;

  /// No description provided for @myTransaction.
  ///
  /// In en, this message translates to:
  /// **'My Transaction'**
  String get myTransaction;

  /// No description provided for @addMoneyToWallet.
  ///
  /// In en, this message translates to:
  /// **'Add Money to Your Wallet'**
  String get addMoneyToWallet;

  /// No description provided for @enterAmount.
  ///
  /// In en, this message translates to:
  /// **'Enter Amount'**
  String get enterAmount;

  /// No description provided for @enterAmountExample.
  ///
  /// In en, this message translates to:
  /// **'Enter Amount e.g. 500'**
  String get enterAmountExample;

  /// No description provided for @add.
  ///
  /// In en, this message translates to:
  /// **'Add'**
  String get add;

  /// No description provided for @walletTip.
  ///
  /// In en, this message translates to:
  /// **'Tip: Your wallet can be used to see the contact details instantly.'**
  String get walletTip;

  /// No description provided for @getVerifiedPashu.
  ///
  /// In en, this message translates to:
  /// **'Get Verified Your Pashu'**
  String get getVerifiedPashu;

  /// No description provided for @withdrawBalance.
  ///
  /// In en, this message translates to:
  /// **'Withdraw Balance'**
  String get withdrawBalance;

  /// No description provided for @signIn.
  ///
  /// In en, this message translates to:
  /// **'Sign In'**
  String get signIn;

  /// No description provided for @enterPhoneNumberToContinue.
  ///
  /// In en, this message translates to:
  /// **'Enter your phone number to continue'**
  String get enterPhoneNumberToContinue;

  /// No description provided for @phoneNumber.
  ///
  /// In en, this message translates to:
  /// **'Phone Number'**
  String get phoneNumber;

  /// No description provided for @enterPhoneNumber.
  ///
  /// In en, this message translates to:
  /// **'Enter phone number'**
  String get enterPhoneNumber;

  /// No description provided for @sendOTP.
  ///
  /// In en, this message translates to:
  /// **'Send OTP'**
  String get sendOTP;

  /// No description provided for @or.
  ///
  /// In en, this message translates to:
  /// **'OR'**
  String get or;

  /// No description provided for @dontHaveAccount.
  ///
  /// In en, this message translates to:
  /// **'Don\'t have an account? Register Now'**
  String get dontHaveAccount;

  /// No description provided for @phoneNumberRequired.
  ///
  /// In en, this message translates to:
  /// **'Phone number is required'**
  String get phoneNumberRequired;

  /// No description provided for @enterValidPhoneNumber.
  ///
  /// In en, this message translates to:
  /// **'Enter a valid 10-digit Indian phone number'**
  String get enterValidPhoneNumber;

  /// No description provided for @otpSentTo.
  ///
  /// In en, this message translates to:
  /// **'OTP sent to +91 {phoneNumber}'**
  String otpSentTo(Object phoneNumber);

  /// No description provided for @register.
  ///
  /// In en, this message translates to:
  /// **'Register'**
  String get register;

  /// No description provided for @login.
  ///
  /// In en, this message translates to:
  /// **'Login'**
  String get login;

  /// No description provided for @registerNow.
  ///
  /// In en, this message translates to:
  /// **'Register Now'**
  String get registerNow;

  /// No description provided for @enterYourName.
  ///
  /// In en, this message translates to:
  /// **'Enter your name'**
  String get enterYourName;

  /// No description provided for @enterReferralCode.
  ///
  /// In en, this message translates to:
  /// **'Enter Referral Code (Optional)'**
  String get enterReferralCode;

  /// No description provided for @getOTP.
  ///
  /// In en, this message translates to:
  /// **'Get OTP'**
  String get getOTP;

  /// No description provided for @alreadyHaveAccount.
  ///
  /// In en, this message translates to:
  /// **'Already have an Account? Sign In'**
  String get alreadyHaveAccount;

  /// No description provided for @optional.
  ///
  /// In en, this message translates to:
  /// **'Optional'**
  String get optional;

  /// No description provided for @nameIsRequired.
  ///
  /// In en, this message translates to:
  /// **'Name is required'**
  String get nameIsRequired;

  /// No description provided for @nameMinLength.
  ///
  /// In en, this message translates to:
  /// **'Name must be at least 2 characters long'**
  String get nameMinLength;

  /// No description provided for @failedToSendOTP.
  ///
  /// In en, this message translates to:
  /// **'Failed to send OTP. Please try again.'**
  String get failedToSendOTP;

  /// No description provided for @enterOTP.
  ///
  /// In en, this message translates to:
  /// **'Enter OTP'**
  String get enterOTP;

  /// No description provided for @otpSentMessage.
  ///
  /// In en, this message translates to:
  /// **'We have sent a 6-digit OTP to +91 {phoneNumber}'**
  String otpSentMessage(Object phoneNumber);

  /// No description provided for @enterComplete6DigitOTP.
  ///
  /// In en, this message translates to:
  /// **'Please enter complete 6-digit OTP'**
  String get enterComplete6DigitOTP;

  /// No description provided for @successfulLogin.
  ///
  /// In en, this message translates to:
  /// **'Successful Login'**
  String get successfulLogin;

  /// No description provided for @didntReceiveOTP.
  ///
  /// In en, this message translates to:
  /// **'Didn\'t receive OTP?'**
  String get didntReceiveOTP;

  /// No description provided for @resendIn.
  ///
  /// In en, this message translates to:
  /// **'Resend in {seconds}s'**
  String resendIn(Object seconds);

  /// No description provided for @resendOTP.
  ///
  /// In en, this message translates to:
  /// **'Resend OTP'**
  String get resendOTP;

  /// No description provided for @resending.
  ///
  /// In en, this message translates to:
  /// **'Resending...'**
  String get resending;

  /// No description provided for @otpResentTo.
  ///
  /// In en, this message translates to:
  /// **'OTP resent to +91 {phoneNumber}'**
  String otpResentTo(Object phoneNumber);

  /// No description provided for @failedToResendOTP.
  ///
  /// In en, this message translates to:
  /// **'Failed to resend OTP. Please try again.'**
  String get failedToResendOTP;

  /// No description provided for @homeScreen.
  ///
  /// In en, this message translates to:
  /// **'Home'**
  String get homeScreen;

  /// No description provided for @welcomeToHomeScreen.
  ///
  /// In en, this message translates to:
  /// **'Welcome to the Home Screen!'**
  String get welcomeToHomeScreen;

  /// No description provided for @newBadge.
  ///
  /// In en, this message translates to:
  /// **'NEW'**
  String get newBadge;

  /// No description provided for @logoutConfirmation.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to logout from your account?'**
  String get logoutConfirmation;

  /// No description provided for @cancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// No description provided for @failedToLoadProfile.
  ///
  /// In en, this message translates to:
  /// **'Failed to Load Profile'**
  String get failedToLoadProfile;

  /// No description provided for @uploadPashuImageOne.
  ///
  /// In en, this message translates to:
  /// **'Upload Your Pashu Image One'**
  String get uploadPashuImageOne;

  /// No description provided for @selectPictureOne.
  ///
  /// In en, this message translates to:
  /// **'SELECT PICTURE ONE'**
  String get selectPictureOne;

  /// No description provided for @uploadPashuImageTwo.
  ///
  /// In en, this message translates to:
  /// **'Upload Your Pashu Image Two'**
  String get uploadPashuImageTwo;

  /// No description provided for @selectPictureTwo.
  ///
  /// In en, this message translates to:
  /// **'SELECT PICTURE TWO'**
  String get selectPictureTwo;

  /// No description provided for @paymentCompletedSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Payment completed successfully!'**
  String get paymentCompletedSuccessfully;

  /// No description provided for @paymentVerificationFailed.
  ///
  /// In en, this message translates to:
  /// **'Payment verification failed. Please try again.'**
  String get paymentVerificationFailed;

  /// No description provided for @errorVerifyingPayment.
  ///
  /// In en, this message translates to:
  /// **'Error verifying payment'**
  String get errorVerifyingPayment;

  /// No description provided for @insuranceApplication.
  ///
  /// In en, this message translates to:
  /// **'Insurance Application'**
  String get insuranceApplication;

  /// No description provided for @responseReceived.
  ///
  /// In en, this message translates to:
  /// **'Response Received!'**
  String get responseReceived;

  /// No description provided for @insuranceThankYouMessage.
  ///
  /// In en, this message translates to:
  /// **'Thank you for submitting your pashu insurance application. Our team will get back to you soon with further details.'**
  String get insuranceThankYouMessage;

  /// No description provided for @selectLanguage.
  ///
  /// In en, this message translates to:
  /// **'Select Language'**
  String get selectLanguage;

  /// No description provided for @ok.
  ///
  /// In en, this message translates to:
  /// **'OK'**
  String get ok;

  /// No description provided for @appTitle.
  ///
  /// In en, this message translates to:
  /// **'Pashu Parivar'**
  String get appTitle;

  /// No description provided for @languageShort.
  ///
  /// In en, this message translates to:
  /// **'हि/E/ತ'**
  String get languageShort;

  /// No description provided for @wishlist.
  ///
  /// In en, this message translates to:
  /// **'Wishlist'**
  String get wishlist;

  /// No description provided for @loanFormTitle.
  ///
  /// In en, this message translates to:
  /// **'Pashu Loan Form'**
  String get loanFormTitle;

  /// No description provided for @loanApplicationHeader.
  ///
  /// In en, this message translates to:
  /// **'Animal Loan Application'**
  String get loanApplicationHeader;

  /// No description provided for @loanApplicationSubheader.
  ///
  /// In en, this message translates to:
  /// **'Get financial support for your livestock farming needs'**
  String get loanApplicationSubheader;

  /// No description provided for @loanApplicationDetails.
  ///
  /// In en, this message translates to:
  /// **'Loan Application Details'**
  String get loanApplicationDetails;

  /// No description provided for @applicantInformation.
  ///
  /// In en, this message translates to:
  /// **'Applicant Information'**
  String get applicantInformation;

  /// No description provided for @applicantName.
  ///
  /// In en, this message translates to:
  /// **'Applicant Name'**
  String get applicantName;

  /// No description provided for @applicantNameRequired.
  ///
  /// In en, this message translates to:
  /// **'Applicant name is required'**
  String get applicantNameRequired;

  /// No description provided for @applicantAddress.
  ///
  /// In en, this message translates to:
  /// **'Applicant Address'**
  String get applicantAddress;

  /// No description provided for @applicantAddressRequired.
  ///
  /// In en, this message translates to:
  /// **'Applicant address is required'**
  String get applicantAddressRequired;

  /// No description provided for @contactNumber.
  ///
  /// In en, this message translates to:
  /// **'Contact Number'**
  String get contactNumber;

  /// No description provided for @contactNumberRequired.
  ///
  /// In en, this message translates to:
  /// **'Contact number is required'**
  String get contactNumberRequired;

  /// No description provided for @contactNumberInvalid.
  ///
  /// In en, this message translates to:
  /// **'Please enter a valid contact number'**
  String get contactNumberInvalid;

  /// No description provided for @emailAddress.
  ///
  /// In en, this message translates to:
  /// **'Email Address'**
  String get emailAddress;

  /// No description provided for @emailAddressRequired.
  ///
  /// In en, this message translates to:
  /// **'Email address is required'**
  String get emailAddressRequired;

  /// No description provided for @emailAddressInvalid.
  ///
  /// In en, this message translates to:
  /// **'Please enter a valid email address'**
  String get emailAddressInvalid;

  /// No description provided for @loanInformation.
  ///
  /// In en, this message translates to:
  /// **'Loan Information'**
  String get loanInformation;

  /// No description provided for @loanAmount.
  ///
  /// In en, this message translates to:
  /// **'Loan Amount (₹)'**
  String get loanAmount;

  /// No description provided for @loanAmountRequired.
  ///
  /// In en, this message translates to:
  /// **'Loan amount is required'**
  String get loanAmountRequired;

  /// No description provided for @loanAmountInvalid.
  ///
  /// In en, this message translates to:
  /// **'Please enter a valid loan amount'**
  String get loanAmountInvalid;

  /// No description provided for @repaymentPeriod.
  ///
  /// In en, this message translates to:
  /// **'Repayment Period'**
  String get repaymentPeriod;

  /// No description provided for @repaymentPeriodRequired.
  ///
  /// In en, this message translates to:
  /// **'Repayment period is required'**
  String get repaymentPeriodRequired;

  /// No description provided for @incomeSource.
  ///
  /// In en, this message translates to:
  /// **'Income Source'**
  String get incomeSource;

  /// No description provided for @incomeSourceRequired.
  ///
  /// In en, this message translates to:
  /// **'Income source is required'**
  String get incomeSourceRequired;

  /// No description provided for @purposeOfLoan.
  ///
  /// In en, this message translates to:
  /// **'Purpose of Loan'**
  String get purposeOfLoan;

  /// No description provided for @purposeOfLoanRequired.
  ///
  /// In en, this message translates to:
  /// **'Purpose of loan is required'**
  String get purposeOfLoanRequired;

  /// No description provided for @additionalInformation.
  ///
  /// In en, this message translates to:
  /// **'Additional Information'**
  String get additionalInformation;

  /// No description provided for @additionalRemarks.
  ///
  /// In en, this message translates to:
  /// **'Additional Remarks'**
  String get additionalRemarks;

  /// No description provided for @additionalRemarksRequired.
  ///
  /// In en, this message translates to:
  /// **'Additional remarks are required'**
  String get additionalRemarksRequired;

  /// No description provided for @submittingForm.
  ///
  /// In en, this message translates to:
  /// **'Submitting Form...'**
  String get submittingForm;

  /// No description provided for @submitForm.
  ///
  /// In en, this message translates to:
  /// **'Submit Form'**
  String get submitForm;

  /// No description provided for @loanTermsNote.
  ///
  /// In en, this message translates to:
  /// **'By submitting this form, you agree to our loan terms and conditions. Our team will review your application and contact you within 3-5 business days with loan approval status.'**
  String get loanTermsNote;

  /// No description provided for @allFieldsRequired.
  ///
  /// In en, this message translates to:
  /// **'All fields are required'**
  String get allFieldsRequired;

  /// No description provided for @animalInformation.
  ///
  /// In en, this message translates to:
  /// **'Animal Information'**
  String get animalInformation;

  /// No description provided for @animalAgeInvalid.
  ///
  /// In en, this message translates to:
  /// **'Please enter a valid animal age'**
  String get animalAgeInvalid;

  /// No description provided for @animalWeightInvalid.
  ///
  /// In en, this message translates to:
  /// **'Please enter a valid animal weight'**
  String get animalWeightInvalid;

  /// No description provided for @allowLocationAccess.
  ///
  /// In en, this message translates to:
  /// **'Allow Location Access'**
  String get allowLocationAccess;

  /// No description provided for @locationDescription.
  ///
  /// In en, this message translates to:
  /// **'We need your location to show nearby livestock, events, and personalized content based on your area.'**
  String get locationDescription;

  /// No description provided for @locationPrivacyNote.
  ///
  /// In en, this message translates to:
  /// **'Your location data is secure and only used to enhance your experience.'**
  String get locationPrivacyNote;

  /// No description provided for @liveRaces.
  ///
  /// In en, this message translates to:
  /// **'Live Races'**
  String get liveRaces;

  /// No description provided for @viewLive.
  ///
  /// In en, this message translates to:
  /// **'View Live'**
  String get viewLive;

  /// No description provided for @animalInsurance.
  ///
  /// In en, this message translates to:
  /// **'Animal Insurance'**
  String get animalInsurance;

  /// No description provided for @insuranceFormTitle.
  ///
  /// In en, this message translates to:
  /// **'Animal Insurance Form'**
  String get insuranceFormTitle;

  /// No description provided for @insuranceApplicationHeader.
  ///
  /// In en, this message translates to:
  /// **'Animal Insurance Application'**
  String get insuranceApplicationHeader;

  /// No description provided for @insuranceApplicationSubheader.
  ///
  /// In en, this message translates to:
  /// **'Get financial support for your animal insurance needs'**
  String get insuranceApplicationSubheader;

  /// No description provided for @insuranceApplicationDetails.
  ///
  /// In en, this message translates to:
  /// **'Insurance Application Details'**
  String get insuranceApplicationDetails;

  /// No description provided for @ownerInformation.
  ///
  /// In en, this message translates to:
  /// **'Owner Information'**
  String get ownerInformation;

  /// No description provided for @ownerName.
  ///
  /// In en, this message translates to:
  /// **'Owner Name'**
  String get ownerName;

  /// No description provided for @ownerNameRequired.
  ///
  /// In en, this message translates to:
  /// **'Owner name is required'**
  String get ownerNameRequired;

  /// No description provided for @ownerAddress.
  ///
  /// In en, this message translates to:
  /// **'Owner Address'**
  String get ownerAddress;

  /// No description provided for @ownerAddressRequired.
  ///
  /// In en, this message translates to:
  /// **'Owner address is required'**
  String get ownerAddressRequired;

  /// No description provided for @animalType.
  ///
  /// In en, this message translates to:
  /// **'Animal Type'**
  String get animalType;

  /// No description provided for @animalTypeRequired.
  ///
  /// In en, this message translates to:
  /// **'Animal type is required'**
  String get animalTypeRequired;

  /// No description provided for @animalBreed.
  ///
  /// In en, this message translates to:
  /// **'Animal Breed'**
  String get animalBreed;

  /// No description provided for @animalBreedRequired.
  ///
  /// In en, this message translates to:
  /// **'Animal breed is required'**
  String get animalBreedRequired;

  /// No description provided for @animalAge.
  ///
  /// In en, this message translates to:
  /// **'Animal Age'**
  String get animalAge;

  /// No description provided for @animalAgeRequired.
  ///
  /// In en, this message translates to:
  /// **'Animal age is required'**
  String get animalAgeRequired;

  /// No description provided for @animalColor.
  ///
  /// In en, this message translates to:
  /// **'Animal Color'**
  String get animalColor;

  /// No description provided for @animalColorRequired.
  ///
  /// In en, this message translates to:
  /// **'Animal color is required'**
  String get animalColorRequired;

  /// No description provided for @animalWeight.
  ///
  /// In en, this message translates to:
  /// **'Animal Weight'**
  String get animalWeight;

  /// No description provided for @animalWeightRequired.
  ///
  /// In en, this message translates to:
  /// **'Animal weight is required'**
  String get animalWeightRequired;

  /// No description provided for @healthStatus.
  ///
  /// In en, this message translates to:
  /// **'Health Status'**
  String get healthStatus;

  /// No description provided for @healthStatusRequired.
  ///
  /// In en, this message translates to:
  /// **'Health status is required'**
  String get healthStatusRequired;

  /// No description provided for @insuranceTermsNote.
  ///
  /// In en, this message translates to:
  /// **'By submitting this form, you agree to our insurance terms and conditions. Our team will review your application and contact you within 3-5 business days with insurance approval status.'**
  String get insuranceTermsNote;

  /// No description provided for @liveRaceTitle.
  ///
  /// In en, this message translates to:
  /// **'Live Race'**
  String get liveRaceTitle;

  /// No description provided for @liveRaceHeader.
  ///
  /// In en, this message translates to:
  /// **'LIVE RACE'**
  String get liveRaceHeader;

  /// No description provided for @chooseRaceCategory.
  ///
  /// In en, this message translates to:
  /// **'Choose Your Race Category'**
  String get chooseRaceCategory;

  /// No description provided for @raceExperienceSubheader.
  ///
  /// In en, this message translates to:
  /// **'Experience the thrill of traditional animal racing'**
  String get raceExperienceSubheader;

  /// No description provided for @raceCategoryFallback.
  ///
  /// In en, this message translates to:
  /// **'Race Category'**
  String get raceCategoryFallback;

  /// No description provided for @raceCategoryDetailFallback.
  ///
  /// In en, this message translates to:
  /// **'Join the exciting race and experience the thrill of traditional animal racing'**
  String get raceCategoryDetailFallback;

  /// No description provided for @liveNow.
  ///
  /// In en, this message translates to:
  /// **'Live Now'**
  String get liveNow;

  /// No description provided for @tapToJoin.
  ///
  /// In en, this message translates to:
  /// **'Tap to Join'**
  String get tapToJoin;

  /// No description provided for @liveBadge.
  ///
  /// In en, this message translates to:
  /// **'LIVE'**
  String get liveBadge;

  /// No description provided for @failedToLoadCategories.
  ///
  /// In en, this message translates to:
  /// **'Failed to Load Categories'**
  String get failedToLoadCategories;

  /// No description provided for @somethingWentWrong.
  ///
  /// In en, this message translates to:
  /// **'Something went wrong'**
  String get somethingWentWrong;

  /// No description provided for @retry.
  ///
  /// In en, this message translates to:
  /// **'Retry'**
  String get retry;

  /// No description provided for @noLiveRacesAvailable.
  ///
  /// In en, this message translates to:
  /// **'No Live Races Available'**
  String get noLiveRacesAvailable;

  /// No description provided for @checkBackLater.
  ///
  /// In en, this message translates to:
  /// **'Check back later for exciting live racing events'**
  String get checkBackLater;

  /// No description provided for @raceCategory.
  ///
  /// In en, this message translates to:
  /// **'Race Category'**
  String get raceCategory;

  /// No description provided for @traditionalRacingExperience.
  ///
  /// In en, this message translates to:
  /// **'Traditional Racing Experience'**
  String get traditionalRacingExperience;

  /// No description provided for @raceInformation.
  ///
  /// In en, this message translates to:
  /// **'Race Information'**
  String get raceInformation;

  /// No description provided for @category.
  ///
  /// In en, this message translates to:
  /// **'Category'**
  String get category;

  /// No description provided for @status.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get status;

  /// No description provided for @participants.
  ///
  /// In en, this message translates to:
  /// **'Participants'**
  String get participants;

  /// No description provided for @multipleEntries.
  ///
  /// In en, this message translates to:
  /// **'Multiple Entries'**
  String get multipleEntries;

  /// No description provided for @duration.
  ///
  /// In en, this message translates to:
  /// **'Duration'**
  String get duration;

  /// No description provided for @ongoing.
  ///
  /// In en, this message translates to:
  /// **'Ongoing'**
  String get ongoing;

  /// No description provided for @prize.
  ///
  /// In en, this message translates to:
  /// **'Prize'**
  String get prize;

  /// No description provided for @trophiesAndRecognition.
  ///
  /// In en, this message translates to:
  /// **'Trophies & Recognition'**
  String get trophiesAndRecognition;

  /// No description provided for @raceIsLiveNow.
  ///
  /// In en, this message translates to:
  /// **'Race is Live Now!'**
  String get raceIsLiveNow;

  /// No description provided for @watchExcitingCompetition.
  ///
  /// In en, this message translates to:
  /// **'Watch the exciting competition unfold'**
  String get watchExcitingCompetition;

  /// No description provided for @aboutThisRace.
  ///
  /// In en, this message translates to:
  /// **'About This Race'**
  String get aboutThisRace;

  /// No description provided for @defaultRaceDescription.
  ///
  /// In en, this message translates to:
  /// **'Experience the thrill of traditional animal racing in this exciting live event. Watch as skilled participants compete in this time-honored tradition that showcases the bond between humans and animals. This race category represents the rich cultural heritage of animal sports and provides an authentic glimpse into traditional racing practices.'**
  String get defaultRaceDescription;

  /// No description provided for @liveStream.
  ///
  /// In en, this message translates to:
  /// **'Live Stream'**
  String get liveStream;

  /// No description provided for @liveStreamComingSoon.
  ///
  /// In en, this message translates to:
  /// **'Live Stream Coming Soon'**
  String get liveStreamComingSoon;

  /// No description provided for @youtubeLinksAvailable.
  ///
  /// In en, this message translates to:
  /// **'YouTube links will be available when streaming begins'**
  String get youtubeLinksAvailable;

  /// No description provided for @getNotifiedWhenStreaming.
  ///
  /// In en, this message translates to:
  /// **'Get notified when live streaming starts for this race category'**
  String get getNotifiedWhenStreaming;

  /// No description provided for @liveRace.
  ///
  /// In en, this message translates to:
  /// **'LIVE RACE'**
  String get liveRace;

  /// No description provided for @na.
  ///
  /// In en, this message translates to:
  /// **'N/A'**
  String get na;

  /// No description provided for @regionalChampionship.
  ///
  /// In en, this message translates to:
  /// **'Regional Championship'**
  String get regionalChampionship;

  /// No description provided for @districtFinals.
  ///
  /// In en, this message translates to:
  /// **'District Finals'**
  String get districtFinals;

  /// No description provided for @stateCompetition.
  ///
  /// In en, this message translates to:
  /// **'State Competition'**
  String get stateCompetition;

  /// No description provided for @tomorrowTenAM.
  ///
  /// In en, this message translates to:
  /// **'Tomorrow 10:00 AM'**
  String get tomorrowTenAM;

  /// No description provided for @nextWeek.
  ///
  /// In en, this message translates to:
  /// **'Next Week'**
  String get nextWeek;

  /// No description provided for @sellPashu.
  ///
  /// In en, this message translates to:
  /// **'Sell Pashu'**
  String get sellPashu;

  /// No description provided for @youCanProceedWithListing.
  ///
  /// In en, this message translates to:
  /// **'You can proceed with listing'**
  String get youCanProceedWithListing;

  /// No description provided for @minimumRequiredToList.
  ///
  /// In en, this message translates to:
  /// **'Minimum ₹15 required to list your animal'**
  String get minimumRequiredToList;

  /// No description provided for @animalTypes.
  ///
  /// In en, this message translates to:
  /// **'Animal Types'**
  String get animalTypes;

  /// No description provided for @selectAnimalType.
  ///
  /// In en, this message translates to:
  /// **'Select Animal Type'**
  String get selectAnimalType;

  /// No description provided for @animalCategory.
  ///
  /// In en, this message translates to:
  /// **'Animal Category'**
  String get animalCategory;

  /// No description provided for @pleaseSelectAnimalTypeFirst.
  ///
  /// In en, this message translates to:
  /// **'Please select animal type first'**
  String get pleaseSelectAnimalTypeFirst;

  /// No description provided for @selectAnimalCategory.
  ///
  /// In en, this message translates to:
  /// **'Select Animal Category'**
  String get selectAnimalCategory;

  /// No description provided for @nameOfTheAnimal.
  ///
  /// In en, this message translates to:
  /// **'Name of The Animal'**
  String get nameOfTheAnimal;

  /// No description provided for @enterAnimalAge.
  ///
  /// In en, this message translates to:
  /// **'Enter Animal Age'**
  String get enterAnimalAge;

  /// No description provided for @selectGenderOfAnimal.
  ///
  /// In en, this message translates to:
  /// **'Select Gender of Animal'**
  String get selectGenderOfAnimal;

  /// No description provided for @price.
  ///
  /// In en, this message translates to:
  /// **'Price'**
  String get price;

  /// No description provided for @negotiable.
  ///
  /// In en, this message translates to:
  /// **'Negotiable'**
  String get negotiable;

  /// No description provided for @isPriceNegotiable.
  ///
  /// In en, this message translates to:
  /// **'Is price negotiable?'**
  String get isPriceNegotiable;

  /// No description provided for @yourPhoneNumber.
  ///
  /// In en, this message translates to:
  /// **'Your Phone Number'**
  String get yourPhoneNumber;

  /// No description provided for @enterYourPhoneNumber.
  ///
  /// In en, this message translates to:
  /// **'Enter your phone number'**
  String get enterYourPhoneNumber;

  /// No description provided for @animalDescription.
  ///
  /// In en, this message translates to:
  /// **'Animal Description'**
  String get animalDescription;

  /// No description provided for @enterAnimalDescription.
  ///
  /// In en, this message translates to:
  /// **'Enter Animal Description'**
  String get enterAnimalDescription;

  /// No description provided for @getAddressForPashu.
  ///
  /// In en, this message translates to:
  /// **'Get Address for Pashu'**
  String get getAddressForPashu;

  /// No description provided for @submitAndPay.
  ///
  /// In en, this message translates to:
  /// **'Submit & Pay ₹15'**
  String get submitAndPay;

  /// No description provided for @insufficientBalance.
  ///
  /// In en, this message translates to:
  /// **'Insufficient balance. Please add funds.'**
  String get insufficientBalance;

  /// No description provided for @submitting.
  ///
  /// In en, this message translates to:
  /// **'Submitting...'**
  String get submitting;

  /// No description provided for @locationServicesDisabled.
  ///
  /// In en, this message translates to:
  /// **'Location services are disabled'**
  String get locationServicesDisabled;

  /// No description provided for @locationPermissionPermanentlyDenied.
  ///
  /// In en, this message translates to:
  /// **'Location permission permanently denied'**
  String get locationPermissionPermanentlyDenied;

  /// No description provided for @locationPermissionDenied.
  ///
  /// In en, this message translates to:
  /// **'Location permission denied'**
  String get locationPermissionDenied;

  /// No description provided for @unableToDetermineAddress.
  ///
  /// In en, this message translates to:
  /// **'Unable to determine address'**
  String get unableToDetermineAddress;

  /// No description provided for @error.
  ///
  /// In en, this message translates to:
  /// **'Error'**
  String get error;

  /// No description provided for @missingRequiredFields.
  ///
  /// In en, this message translates to:
  /// **'Missing Required Fields'**
  String get missingRequiredFields;

  /// No description provided for @pleaseEnterValidPhoneNumber.
  ///
  /// In en, this message translates to:
  /// **'Please enter a valid phone number'**
  String get pleaseEnterValidPhoneNumber;

  /// No description provided for @pleaseEnterValidAge.
  ///
  /// In en, this message translates to:
  /// **'Please enter a valid age'**
  String get pleaseEnterValidAge;

  /// No description provided for @pleaseEnterValidPrice.
  ///
  /// In en, this message translates to:
  /// **'Please enter a valid price'**
  String get pleaseEnterValidPrice;

  /// No description provided for @pashuListedSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Pashu listed successfully!'**
  String get pashuListedSuccessfully;

  /// No description provided for @errorOccurred.
  ///
  /// In en, this message translates to:
  /// **'An error occurred'**
  String get errorOccurred;

  /// No description provided for @selectCategory.
  ///
  /// In en, this message translates to:
  /// **'Select Category'**
  String get selectCategory;

  /// No description provided for @selectGender.
  ///
  /// In en, this message translates to:
  /// **'Select Gender'**
  String get selectGender;

  /// No description provided for @male.
  ///
  /// In en, this message translates to:
  /// **'Male'**
  String get male;

  /// No description provided for @female.
  ///
  /// In en, this message translates to:
  /// **'Female'**
  String get female;

  /// No description provided for @user.
  ///
  /// In en, this message translates to:
  /// **'User'**
  String get user;

  /// No description provided for @other.
  ///
  /// In en, this message translates to:
  /// **'Other'**
  String get other;

  /// No description provided for @unknown.
  ///
  /// In en, this message translates to:
  /// **'Unknown'**
  String get unknown;

  /// No description provided for @traditionalSportsAnimal.
  ///
  /// In en, this message translates to:
  /// **'Traditional Sports Animal'**
  String get traditionalSportsAnimal;

  /// No description provided for @livestockAnimal.
  ///
  /// In en, this message translates to:
  /// **'Livestock Animal'**
  String get livestockAnimal;

  /// No description provided for @petAnimal.
  ///
  /// In en, this message translates to:
  /// **'Pet Animal'**
  String get petAnimal;

  /// No description provided for @farmHouseAnimal.
  ///
  /// In en, this message translates to:
  /// **'Farm House Animal'**
  String get farmHouseAnimal;

  /// No description provided for @bull.
  ///
  /// In en, this message translates to:
  /// **'Bull'**
  String get bull;

  /// No description provided for @camel.
  ///
  /// In en, this message translates to:
  /// **'Camel'**
  String get camel;

  /// No description provided for @bird.
  ///
  /// In en, this message translates to:
  /// **'Bird'**
  String get bird;

  /// No description provided for @pigeon.
  ///
  /// In en, this message translates to:
  /// **'Pigeon'**
  String get pigeon;

  /// No description provided for @cock.
  ///
  /// In en, this message translates to:
  /// **'Cock'**
  String get cock;

  /// No description provided for @dog.
  ///
  /// In en, this message translates to:
  /// **'Dog'**
  String get dog;

  /// No description provided for @goat.
  ///
  /// In en, this message translates to:
  /// **'Goat'**
  String get goat;

  /// No description provided for @horse.
  ///
  /// In en, this message translates to:
  /// **'Horse'**
  String get horse;

  /// No description provided for @buffalo.
  ///
  /// In en, this message translates to:
  /// **'Buffalo'**
  String get buffalo;

  /// No description provided for @sheep.
  ///
  /// In en, this message translates to:
  /// **'Sheep'**
  String get sheep;

  /// No description provided for @pigs.
  ///
  /// In en, this message translates to:
  /// **'Pigs'**
  String get pigs;

  /// No description provided for @cat.
  ///
  /// In en, this message translates to:
  /// **'Cat'**
  String get cat;

  /// No description provided for @fishes.
  ///
  /// In en, this message translates to:
  /// **'Fishes'**
  String get fishes;

  /// No description provided for @smallMammals.
  ///
  /// In en, this message translates to:
  /// **'Small Mammals'**
  String get smallMammals;

  /// No description provided for @searchAnimalsBreeds.
  ///
  /// In en, this message translates to:
  /// **'Search animals, breeds...'**
  String get searchAnimalsBreeds;

  /// No description provided for @unknownAnimal.
  ///
  /// In en, this message translates to:
  /// **'Unknown Animal'**
  String get unknownAnimal;

  /// No description provided for @breed.
  ///
  /// In en, this message translates to:
  /// **'Breed'**
  String get breed;

  /// No description provided for @owner.
  ///
  /// In en, this message translates to:
  /// **'Owner'**
  String get owner;

  /// No description provided for @callMe.
  ///
  /// In en, this message translates to:
  /// **'Call me'**
  String get callMe;

  /// No description provided for @buyNow.
  ///
  /// In en, this message translates to:
  /// **'Buy Now'**
  String get buyNow;

  /// No description provided for @addedToWishlist.
  ///
  /// In en, this message translates to:
  /// **'added to wishlist'**
  String get addedToWishlist;

  /// No description provided for @animal.
  ///
  /// In en, this message translates to:
  /// **'Animal'**
  String get animal;

  /// No description provided for @failedToAddToWishlist.
  ///
  /// In en, this message translates to:
  /// **'Failed to add to wishlist'**
  String get failedToAddToWishlist;

  /// No description provided for @noAnimalsFound.
  ///
  /// In en, this message translates to:
  /// **'No animals found'**
  String get noAnimalsFound;

  /// No description provided for @trySelectingDifferentCategory.
  ///
  /// In en, this message translates to:
  /// **'Try selecting a different category'**
  String get trySelectingDifferentCategory;

  /// No description provided for @checkBackLaterForNewListings.
  ///
  /// In en, this message translates to:
  /// **'Check back later for new listings'**
  String get checkBackLaterForNewListings;

  /// No description provided for @purchaseRequestSent.
  ///
  /// In en, this message translates to:
  /// **'Purchase request sent for'**
  String get purchaseRequestSent;

  /// No description provided for @all.
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get all;

  /// No description provided for @cow.
  ///
  /// In en, this message translates to:
  /// **'Cow'**
  String get cow;

  /// No description provided for @cats.
  ///
  /// In en, this message translates to:
  /// **'Cats'**
  String get cats;

  /// No description provided for @animalDetails.
  ///
  /// In en, this message translates to:
  /// **'Animal Details'**
  String get animalDetails;

  /// No description provided for @photos.
  ///
  /// In en, this message translates to:
  /// **'Photos'**
  String get photos;

  /// No description provided for @type.
  ///
  /// In en, this message translates to:
  /// **'Type'**
  String get type;

  /// No description provided for @age.
  ///
  /// In en, this message translates to:
  /// **'Age'**
  String get age;

  /// No description provided for @gender.
  ///
  /// In en, this message translates to:
  /// **'Gender'**
  String get gender;

  /// No description provided for @years.
  ///
  /// In en, this message translates to:
  /// **'years'**
  String get years;

  /// No description provided for @pricingInformation.
  ///
  /// In en, this message translates to:
  /// **'Pricing Information'**
  String get pricingInformation;

  /// No description provided for @fixedPrice.
  ///
  /// In en, this message translates to:
  /// **'Fixed Price'**
  String get fixedPrice;

  /// No description provided for @ownerAndLocation.
  ///
  /// In en, this message translates to:
  /// **'Owner & Location'**
  String get ownerAndLocation;

  /// No description provided for @location.
  ///
  /// In en, this message translates to:
  /// **'Location'**
  String get location;

  /// No description provided for @distance.
  ///
  /// In en, this message translates to:
  /// **'Distance'**
  String get distance;

  /// No description provided for @notSpecified.
  ///
  /// In en, this message translates to:
  /// **'Not specified'**
  String get notSpecified;

  /// No description provided for @meters.
  ///
  /// In en, this message translates to:
  /// **'meters'**
  String get meters;

  /// No description provided for @km.
  ///
  /// In en, this message translates to:
  /// **'km'**
  String get km;

  /// No description provided for @description.
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get description;

  /// No description provided for @contactSeller.
  ///
  /// In en, this message translates to:
  /// **'Contact Seller'**
  String get contactSeller;

  /// No description provided for @unlockContactDetails.
  ///
  /// In en, this message translates to:
  /// **'Unlock contact details for ₹2 to connect with the seller'**
  String get unlockContactDetails;

  /// No description provided for @unlocking.
  ///
  /// In en, this message translates to:
  /// **'Unlocking...'**
  String get unlocking;

  /// No description provided for @unlockContact.
  ///
  /// In en, this message translates to:
  /// **'Unlock Contact (₹2)'**
  String get unlockContact;

  /// No description provided for @contactOptions.
  ///
  /// In en, this message translates to:
  /// **'Contact Options'**
  String get contactOptions;

  /// No description provided for @call.
  ///
  /// In en, this message translates to:
  /// **'Call'**
  String get call;

  /// No description provided for @whatsApp.
  ///
  /// In en, this message translates to:
  /// **'WhatsApp'**
  String get whatsApp;

  /// No description provided for @contact.
  ///
  /// In en, this message translates to:
  /// **'Contact'**
  String get contact;

  /// No description provided for @notAvailable.
  ///
  /// In en, this message translates to:
  /// **'Not available'**
  String get notAvailable;

  /// No description provided for @userNotLoggedIn.
  ///
  /// In en, this message translates to:
  /// **'User not logged in'**
  String get userNotLoggedIn;

  /// No description provided for @userDataNotFound.
  ///
  /// In en, this message translates to:
  /// **'User data not found'**
  String get userDataNotFound;

  /// No description provided for @contactAlreadyUnlocked.
  ///
  /// In en, this message translates to:
  /// **'This contact is already unlocked.'**
  String get contactAlreadyUnlocked;

  /// No description provided for @contactUnlockedSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Contact unlocked successfully!'**
  String get contactUnlockedSuccessfully;

  /// No description provided for @couldNotLaunchPhoneApp.
  ///
  /// In en, this message translates to:
  /// **'Could not launch phone app'**
  String get couldNotLaunchPhoneApp;

  /// No description provided for @phoneNumberNotAvailable.
  ///
  /// In en, this message translates to:
  /// **'Phone number not available'**
  String get phoneNumberNotAvailable;

  /// No description provided for @couldNotOpenWhatsApp.
  ///
  /// In en, this message translates to:
  /// **'Could not open WhatsApp'**
  String get couldNotOpenWhatsApp;

  /// No description provided for @whatsAppMessageTemplate.
  ///
  /// In en, this message translates to:
  /// **'Hi, I am interested in your {animalName} listed on Pashu Parivar.'**
  String whatsAppMessageTemplate(Object animalName);

  /// No description provided for @locationNotAvailable.
  ///
  /// In en, this message translates to:
  /// **'Location not available'**
  String get locationNotAvailable;

  /// No description provided for @remove.
  ///
  /// In en, this message translates to:
  /// **'Remove'**
  String get remove;

  /// No description provided for @removedFromWishlist.
  ///
  /// In en, this message translates to:
  /// **'Removed from wishlist'**
  String get removedFromWishlist;

  /// No description provided for @failedToRemove.
  ///
  /// In en, this message translates to:
  /// **'Failed to remove'**
  String get failedToRemove;

  /// No description provided for @animalDetailsComingSoon.
  ///
  /// In en, this message translates to:
  /// **'Animal Details Coming Soon'**
  String get animalDetailsComingSoon;

  /// No description provided for @fullAnimalDetailsModal.
  ///
  /// In en, this message translates to:
  /// **'Full animal details modal will be implemented here'**
  String get fullAnimalDetailsModal;

  /// No description provided for @noWishlistAnimalsFound.
  ///
  /// In en, this message translates to:
  /// **'No wishlist animals found'**
  String get noWishlistAnimalsFound;

  /// No description provided for @tryAddingAnimalsToWishlist.
  ///
  /// In en, this message translates to:
  /// **'Try adding some animals to your wishlist!'**
  String get tryAddingAnimalsToWishlist;

  /// No description provided for @investmentProject.
  ///
  /// In en, this message translates to:
  /// **'Investment Project'**
  String get investmentProject;

  /// No description provided for @upcomingProjects.
  ///
  /// In en, this message translates to:
  /// **'Upcoming Projects'**
  String get upcomingProjects;

  /// No description provided for @liveProjects.
  ///
  /// In en, this message translates to:
  /// **'Live Projects'**
  String get liveProjects;

  /// No description provided for @completedProjects.
  ///
  /// In en, this message translates to:
  /// **'Completed Projects'**
  String get completedProjects;

  /// No description provided for @mvpForAquacultureInvestment.
  ///
  /// In en, this message translates to:
  /// **'MVP for aquaculture investment'**
  String get mvpForAquacultureInvestment;

  /// No description provided for @longTerm.
  ///
  /// In en, this message translates to:
  /// **'Long Term'**
  String get longTerm;

  /// No description provided for @amount.
  ///
  /// In en, this message translates to:
  /// **'Amount'**
  String get amount;

  /// No description provided for @startDate.
  ///
  /// In en, this message translates to:
  /// **'Start Date'**
  String get startDate;

  /// No description provided for @sixToEightMonths.
  ///
  /// In en, this message translates to:
  /// **'6 to 8 months'**
  String get sixToEightMonths;

  /// No description provided for @lotsBooked.
  ///
  /// In en, this message translates to:
  /// **'Lots Booked'**
  String get lotsBooked;

  /// No description provided for @noProjectsAvailable.
  ///
  /// In en, this message translates to:
  /// **'No projects available.'**
  String get noProjectsAvailable;

  /// No description provided for @firstAugust2025.
  ///
  /// In en, this message translates to:
  /// **'1st August 2025'**
  String get firstAugust2025;

  /// No description provided for @addAmountAndGetPlans.
  ///
  /// In en, this message translates to:
  /// **'Add Amount & Get Plans'**
  String get addAmountAndGetPlans;

  /// No description provided for @getVerifiedYourPashu.
  ///
  /// In en, this message translates to:
  /// **'Get Verified Your Pashu'**
  String get getVerifiedYourPashu;

  /// No description provided for @termsAndPrivacy.
  ///
  /// In en, this message translates to:
  /// **'Terms & Privacy'**
  String get termsAndPrivacy;

  /// No description provided for @newA.
  ///
  /// In en, this message translates to:
  /// **'NEW'**
  String get newA;

  /// No description provided for @areYouSureLogout.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to logout from your account?'**
  String get areYouSureLogout;

  /// No description provided for @noProfileFound.
  ///
  /// In en, this message translates to:
  /// **'No Profile Found'**
  String get noProfileFound;

  /// No description provided for @profileInformationNotAvailable.
  ///
  /// In en, this message translates to:
  /// **'Profile information is not available'**
  String get profileInformationNotAvailable;

  /// No description provided for @subscriptionPlans.
  ///
  /// In en, this message translates to:
  /// **'Subscription Plans'**
  String get subscriptionPlans;

  /// No description provided for @chooseYourPlan.
  ///
  /// In en, this message translates to:
  /// **'Choose Your Plan'**
  String get chooseYourPlan;

  /// No description provided for @unlockPremiumFeatures.
  ///
  /// In en, this message translates to:
  /// **'Unlock premium features and grow your livestock business with our subscription plans'**
  String get unlockPremiumFeatures;

  /// No description provided for @diamondPlan.
  ///
  /// In en, this message translates to:
  /// **'Diamond Plan'**
  String get diamondPlan;

  /// No description provided for @goldPlan.
  ///
  /// In en, this message translates to:
  /// **'Gold Plan'**
  String get goldPlan;

  /// No description provided for @silverPlan.
  ///
  /// In en, this message translates to:
  /// **'Silver Plan'**
  String get silverPlan;

  /// No description provided for @year.
  ///
  /// In en, this message translates to:
  /// **'Year'**
  String get year;

  /// No description provided for @months3.
  ///
  /// In en, this message translates to:
  /// **'3 Months'**
  String get months3;

  /// No description provided for @month.
  ///
  /// In en, this message translates to:
  /// **'Month'**
  String get month;

  /// No description provided for @choosePlan.
  ///
  /// In en, this message translates to:
  /// **'Choose Plan'**
  String get choosePlan;

  /// No description provided for @unlimitedPashuProfileContact.
  ///
  /// In en, this message translates to:
  /// **'Unlimited Pashu Profile Contact'**
  String get unlimitedPashuProfileContact;

  /// No description provided for @unlimitedFreePashuListings.
  ///
  /// In en, this message translates to:
  /// **'Unlimited Free Pashu Listings'**
  String get unlimitedFreePashuListings;

  /// No description provided for @priorityCustomerSupport.
  ///
  /// In en, this message translates to:
  /// **'Priority Customer Support'**
  String get priorityCustomerSupport;

  /// No description provided for @advancedAnalytics.
  ///
  /// In en, this message translates to:
  /// **'Advanced Analytics'**
  String get advancedAnalytics;

  /// No description provided for @premiumBadge.
  ///
  /// In en, this message translates to:
  /// **'Premium Badge'**
  String get premiumBadge;

  /// No description provided for @freePashuListings10.
  ///
  /// In en, this message translates to:
  /// **'10 Free Pashu Listings'**
  String get freePashuListings10;

  /// No description provided for @standardCustomerSupport.
  ///
  /// In en, this message translates to:
  /// **'Standard Customer Support'**
  String get standardCustomerSupport;

  /// No description provided for @basicAnalytics.
  ///
  /// In en, this message translates to:
  /// **'Basic Analytics'**
  String get basicAnalytics;

  /// No description provided for @freePashuListings2.
  ///
  /// In en, this message translates to:
  /// **'2 Free Pashu Listings'**
  String get freePashuListings2;

  /// No description provided for @emailSupport.
  ///
  /// In en, this message translates to:
  /// **'Email Support'**
  String get emailSupport;

  /// No description provided for @addMoneyToYourWallet.
  ///
  /// In en, this message translates to:
  /// **'Add Money to Your Wallet'**
  String get addMoneyToYourWallet;

  /// No description provided for @addFundsToWallet.
  ///
  /// In en, this message translates to:
  /// **'Add funds to your wallet and pay for subscriptions seamlessly. Your wallet can be used across all our services.'**
  String get addFundsToWallet;

  /// No description provided for @enterAmountEg500.
  ///
  /// In en, this message translates to:
  /// **'Enter Amount (e.g. 500)'**
  String get enterAmountEg500;

  /// No description provided for @addAmount.
  ///
  /// In en, this message translates to:
  /// **'Add ₹{amount}'**
  String addAmount(String amount);

  /// No description provided for @tipWalletContact.
  ///
  /// In en, this message translates to:
  /// **'Tip: Your wallet can be used to see the contact details instantly.'**
  String get tipWalletContact;

  /// No description provided for @subscribeToPlan.
  ///
  /// In en, this message translates to:
  /// **'Subscribe to {planName}'**
  String subscribeToPlan(String planName);

  /// No description provided for @chargedForSubscription.
  ///
  /// In en, this message translates to:
  /// **'You will be charged ₹{price} for this {period} subscription.'**
  String chargedForSubscription(String price, String period);

  /// No description provided for @confirmSubscription.
  ///
  /// In en, this message translates to:
  /// **'Confirm Subscription'**
  String get confirmSubscription;

  /// No description provided for @subscriptionSuccessful.
  ///
  /// In en, this message translates to:
  /// **'Subscription Successful!'**
  String get subscriptionSuccessful;

  /// No description provided for @subscriptionSuccessMessage.
  ///
  /// In en, this message translates to:
  /// **'You have successfully subscribed to {planName}. Enjoy all premium features!'**
  String subscriptionSuccessMessage(String planName);

  /// No description provided for @continueA.
  ///
  /// In en, this message translates to:
  /// **'Continue'**
  String get continueA;

  /// No description provided for @subscriptionHelp.
  ///
  /// In en, this message translates to:
  /// **'Subscription Help'**
  String get subscriptionHelp;

  /// No description provided for @helpContent.
  ///
  /// In en, this message translates to:
  /// **'• Diamond Plan: ₹365/Year\n• Gold Plan: ₹140/3 Months\n• Silver Plan: ₹49/Month\n• Cancel anytime from your profile\n• All features unlock immediately\n• 24/7 customer support included'**
  String get helpContent;

  /// No description provided for @gotIt.
  ///
  /// In en, this message translates to:
  /// **'Got it'**
  String get gotIt;

  /// No description provided for @pleaseEnterValidAmount.
  ///
  /// In en, this message translates to:
  /// **'Please enter a valid amount'**
  String get pleaseEnterValidAmount;

  /// No description provided for @couldNotInitiatePayment.
  ///
  /// In en, this message translates to:
  /// **'Could not initiate payment'**
  String get couldNotInitiatePayment;

  /// No description provided for @somethingWentWrongPayment.
  ///
  /// In en, this message translates to:
  /// **'Something went wrong with the payment.'**
  String get somethingWentWrongPayment;

  /// No description provided for @paymentCancelled.
  ///
  /// In en, this message translates to:
  /// **'Payment was cancelled or didn\'t complete in time.'**
  String get paymentCancelled;

  /// No description provided for @paymentFailed.
  ///
  /// In en, this message translates to:
  /// **'Payment Failed'**
  String get paymentFailed;

  /// No description provided for @externalWalletSelected.
  ///
  /// In en, this message translates to:
  /// **'External wallet selected'**
  String get externalWalletSelected;

  /// No description provided for @getInTouch.
  ///
  /// In en, this message translates to:
  /// **'Get In Touch'**
  String get getInTouch;

  /// No description provided for @contactUsDescription.
  ///
  /// In en, this message translates to:
  /// **'We\'re here to help! Reach out to us anytime and we\'ll get back to you as soon as possible.'**
  String get contactUsDescription;

  /// No description provided for @contactInformation.
  ///
  /// In en, this message translates to:
  /// **'Contact Information'**
  String get contactInformation;

  /// No description provided for @officeAddress.
  ///
  /// In en, this message translates to:
  /// **'Office Address'**
  String get officeAddress;

  /// No description provided for @pashuParivarHeadquarters.
  ///
  /// In en, this message translates to:
  /// **'Pashu Parivar Headquarters\nBhopal, Madhya Pradesh\nIndia'**
  String get pashuParivarHeadquarters;

  /// No description provided for @sendUsAMessage.
  ///
  /// In en, this message translates to:
  /// **'Send us a Message'**
  String get sendUsAMessage;

  /// No description provided for @fullName.
  ///
  /// In en, this message translates to:
  /// **'Full Name'**
  String get fullName;

  /// No description provided for @enterYourFullName.
  ///
  /// In en, this message translates to:
  /// **'Enter your full name'**
  String get enterYourFullName;

  /// No description provided for @enterYourEmailAddress.
  ///
  /// In en, this message translates to:
  /// **'Enter your email address'**
  String get enterYourEmailAddress;

  /// No description provided for @message.
  ///
  /// In en, this message translates to:
  /// **'Message'**
  String get message;

  /// No description provided for @tellUsHowWeCanHelp.
  ///
  /// In en, this message translates to:
  /// **'Tell us how we can help you...'**
  String get tellUsHowWeCanHelp;

  /// No description provided for @sendingMessage.
  ///
  /// In en, this message translates to:
  /// **'Sending Message...'**
  String get sendingMessage;

  /// No description provided for @sendMessage.
  ///
  /// In en, this message translates to:
  /// **'Send Message'**
  String get sendMessage;

  /// No description provided for @responseTimeNote.
  ///
  /// In en, this message translates to:
  /// **'We typically respond within 24 hours during business days.'**
  String get responseTimeNote;

  /// No description provided for @followUs.
  ///
  /// In en, this message translates to:
  /// **'Follow Us'**
  String get followUs;

  /// No description provided for @stayUpdatedWithNews.
  ///
  /// In en, this message translates to:
  /// **'Stay updated with our latest news and updates'**
  String get stayUpdatedWithNews;

  /// No description provided for @facebook.
  ///
  /// In en, this message translates to:
  /// **'Facebook'**
  String get facebook;

  /// No description provided for @instagram.
  ///
  /// In en, this message translates to:
  /// **'Instagram'**
  String get instagram;

  /// No description provided for @twitter.
  ///
  /// In en, this message translates to:
  /// **'Twitter'**
  String get twitter;

  /// No description provided for @youtube.
  ///
  /// In en, this message translates to:
  /// **'YouTube'**
  String get youtube;

  /// No description provided for @copiedToClipboard.
  ///
  /// In en, this message translates to:
  /// **'Copied to clipboard!'**
  String get copiedToClipboard;

  /// No description provided for @messageSentSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Message Sent Successfully!'**
  String get messageSentSuccessfully;

  /// No description provided for @thankYouForContacting.
  ///
  /// In en, this message translates to:
  /// **'Thank you for contacting us. We\'ll get back to you within 24 hours.'**
  String get thankYouForContacting;

  /// No description provided for @nameMustBeAtLeast2Characters.
  ///
  /// In en, this message translates to:
  /// **'Name must be at least 2 characters'**
  String get nameMustBeAtLeast2Characters;

  /// No description provided for @emailIsRequired.
  ///
  /// In en, this message translates to:
  /// **'Email is required'**
  String get emailIsRequired;

  /// No description provided for @pleaseEnterValidEmail.
  ///
  /// In en, this message translates to:
  /// **'Please enter a valid email address'**
  String get pleaseEnterValidEmail;

  /// No description provided for @messageIsRequired.
  ///
  /// In en, this message translates to:
  /// **'Message is required'**
  String get messageIsRequired;

  /// No description provided for @messageMustBeAtLeast10Characters.
  ///
  /// In en, this message translates to:
  /// **'Message must be at least 10 characters'**
  String get messageMustBeAtLeast10Characters;

  /// No description provided for @invest.
  ///
  /// In en, this message translates to:
  /// **'Invest in Agri-Livestock'**
  String get invest;

  /// No description provided for @total.
  ///
  /// In en, this message translates to:
  /// **'Total'**
  String get total;

  /// No description provided for @active.
  ///
  /// In en, this message translates to:
  /// **'Active'**
  String get active;

  /// No description provided for @pending.
  ///
  /// In en, this message translates to:
  /// **'PENDING'**
  String get pending;

  /// No description provided for @edit.
  ///
  /// In en, this message translates to:
  /// **'Edit'**
  String get edit;

  /// No description provided for @delete.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get delete;

  /// No description provided for @pendingStatus.
  ///
  /// In en, this message translates to:
  /// **'PENDING'**
  String get pendingStatus;

  /// No description provided for @failedToLoadListings.
  ///
  /// In en, this message translates to:
  /// **'Failed to Load Listings'**
  String get failedToLoadListings;

  /// No description provided for @noListedAnimals.
  ///
  /// In en, this message translates to:
  /// **'No Listed Animals'**
  String get noListedAnimals;

  /// No description provided for @noListedAnimalsDescription.
  ///
  /// In en, this message translates to:
  /// **'You haven\'t listed any animals yet. Start by adding your first listing!'**
  String get noListedAnimalsDescription;

  /// No description provided for @addNewListing.
  ///
  /// In en, this message translates to:
  /// **'Add New Listing'**
  String get addNewListing;

  /// No description provided for @deleteListing.
  ///
  /// In en, this message translates to:
  /// **'Delete Listing'**
  String get deleteListing;

  /// No description provided for @deleteConfirmation.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to delete \"{animalName}\"? This action cannot be undone.'**
  String deleteConfirmation(String animalName);

  /// No description provided for @deleteSuccessMessage.
  ///
  /// In en, this message translates to:
  /// **'{animalName} deleted successfully'**
  String deleteSuccessMessage(String animalName);

  /// No description provided for @withdrawFromWallet.
  ///
  /// In en, this message translates to:
  /// **'Withdraw from Wallet'**
  String get withdrawFromWallet;

  /// No description provided for @availableBalance.
  ///
  /// In en, this message translates to:
  /// **'Available Balance'**
  String get availableBalance;

  /// No description provided for @withdrawalEligible.
  ///
  /// In en, this message translates to:
  /// **'Withdrawal Eligible'**
  String get withdrawalEligible;

  /// No description provided for @withdrawalRequirements.
  ///
  /// In en, this message translates to:
  /// **'Withdrawal Requirements'**
  String get withdrawalRequirements;

  /// No description provided for @youHaveSpentAndCanWithdraw.
  ///
  /// In en, this message translates to:
  /// **'You have spent ₹{counter} and can withdraw funds'**
  String youHaveSpentAndCanWithdraw(String counter);

  /// No description provided for @spendMoreToEnableWithdrawal.
  ///
  /// In en, this message translates to:
  /// **'Spend ₹{amount} more to enable withdrawal (Current: ₹{counter})'**
  String spendMoreToEnableWithdrawal(String amount, String counter);

  /// No description provided for @withdrawalDetails.
  ///
  /// In en, this message translates to:
  /// **'Withdrawal Details'**
  String get withdrawalDetails;

  /// No description provided for @enterAmountEg.
  ///
  /// In en, this message translates to:
  /// **'Enter Amount e.g. 500'**
  String get enterAmountEg;

  /// No description provided for @enterUpiIdEg.
  ///
  /// In en, this message translates to:
  /// **'Enter UPI ID (e.g. example@upi)'**
  String get enterUpiIdEg;

  /// No description provided for @enterUpiIdEgPlaceholder.
  ///
  /// In en, this message translates to:
  /// **'Enter UPI ID e.g. example@upi'**
  String get enterUpiIdEgPlaceholder;

  /// No description provided for @processing.
  ///
  /// In en, this message translates to:
  /// **'Processing...'**
  String get processing;

  /// No description provided for @withdrawAmount.
  ///
  /// In en, this message translates to:
  /// **'Withdraw ₹{amount}'**
  String withdrawAmount(String amount);

  /// No description provided for @withdrawalRequirementsLabel.
  ///
  /// In en, this message translates to:
  /// **'Withdrawal Requirements:'**
  String get withdrawalRequirementsLabel;

  /// No description provided for @minimumSpendingRequired.
  ///
  /// In en, this message translates to:
  /// **'• Minimum spending of ₹50 required'**
  String get minimumSpendingRequired;

  /// No description provided for @walletBalanceRequired.
  ///
  /// In en, this message translates to:
  /// **'• Wallet balance must be ≥ ₹100'**
  String get walletBalanceRequired;

  /// No description provided for @currentSpending.
  ///
  /// In en, this message translates to:
  /// **'• Current spending: ₹{counter} ({status})'**
  String currentSpending(String counter, String status);

  /// No description provided for @walletBalanceStatus.
  ///
  /// In en, this message translates to:
  /// **'• Wallet balance: ₹{balance} ({status})'**
  String walletBalanceStatus(String balance, String status);

  /// No description provided for @verified.
  ///
  /// In en, this message translates to:
  /// **'✓'**
  String get verified;

  /// No description provided for @needMoreAmount.
  ///
  /// In en, this message translates to:
  /// **'Need ₹{amount} more'**
  String needMoreAmount(String amount);

  /// No description provided for @tipWithdrawProcessingTime.
  ///
  /// In en, this message translates to:
  /// **'Tip: Withdrawals are processed within 24-48 hours to your UPI account.'**
  String get tipWithdrawProcessingTime;

  /// No description provided for @withdrawalRequestSubmitted.
  ///
  /// In en, this message translates to:
  /// **'Withdrawal Request Submitted!'**
  String get withdrawalRequestSubmitted;

  /// No description provided for @withdrawalRequestSuccessMessage.
  ///
  /// In en, this message translates to:
  /// **'Your withdrawal request of ₹{amount} has been submitted successfully. You will receive the amount in your UPI account within 24-48 hours.'**
  String withdrawalRequestSuccessMessage(String amount);

  /// No description provided for @failedToLoadData.
  ///
  /// In en, this message translates to:
  /// **'Failed to Load Data'**
  String get failedToLoadData;

  /// No description provided for @amountCannotBeEmpty.
  ///
  /// In en, this message translates to:
  /// **'Amount cannot be empty'**
  String get amountCannotBeEmpty;

  /// No description provided for @amountCannotExceedBalance.
  ///
  /// In en, this message translates to:
  /// **'Amount cannot exceed wallet balance (₹{balance})'**
  String amountCannotExceedBalance(String balance);

  /// No description provided for @minimumWalletBalanceRequired.
  ///
  /// In en, this message translates to:
  /// **'Minimum wallet balance of ₹100 required'**
  String get minimumWalletBalanceRequired;

  /// No description provided for @upiIdCannotBeEmpty.
  ///
  /// In en, this message translates to:
  /// **'UPI ID cannot be empty'**
  String get upiIdCannotBeEmpty;

  /// No description provided for @pleaseEnterValidUpiId.
  ///
  /// In en, this message translates to:
  /// **'Please enter a valid UPI ID'**
  String get pleaseEnterValidUpiId;

  /// No description provided for @transactionHistory.
  ///
  /// In en, this message translates to:
  /// **'Transaction History'**
  String get transactionHistory;

  /// No description provided for @noTransactions.
  ///
  /// In en, this message translates to:
  /// **'No transactions'**
  String get noTransactions;

  /// No description provided for @transactionSummary.
  ///
  /// In en, this message translates to:
  /// **'Transaction Summary'**
  String get transactionSummary;

  /// No description provided for @totalCredit.
  ///
  /// In en, this message translates to:
  /// **'Total Credit'**
  String get totalCredit;

  /// No description provided for @totalDebit.
  ///
  /// In en, this message translates to:
  /// **'Total Debit'**
  String get totalDebit;

  /// No description provided for @successful.
  ///
  /// In en, this message translates to:
  /// **'Successful'**
  String get successful;

  /// No description provided for @today.
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get today;

  /// No description provided for @yesterday.
  ///
  /// In en, this message translates to:
  /// **'Yesterday'**
  String get yesterday;

  /// No description provided for @daysAgo.
  ///
  /// In en, this message translates to:
  /// **'{days} days ago'**
  String daysAgo(String days);

  /// No description provided for @paymentId.
  ///
  /// In en, this message translates to:
  /// **'Payment ID'**
  String get paymentId;

  /// No description provided for @fullDate.
  ///
  /// In en, this message translates to:
  /// **'Full Date'**
  String get fullDate;

  /// No description provided for @utrNumber.
  ///
  /// In en, this message translates to:
  /// **'UTR Number'**
  String get utrNumber;

  /// No description provided for @failedToLoadTransactions.
  ///
  /// In en, this message translates to:
  /// **'Failed to Load Transactions'**
  String get failedToLoadTransactions;

  /// No description provided for @noTransactionsFound.
  ///
  /// In en, this message translates to:
  /// **'No Transactions Found'**
  String get noTransactionsFound;

  /// No description provided for @transactionHistoryDescription.
  ///
  /// In en, this message translates to:
  /// **'Your transaction history will appear here once you make your first transaction'**
  String get transactionHistoryDescription;

  /// No description provided for @goBack.
  ///
  /// In en, this message translates to:
  /// **'Go Back'**
  String get goBack;

  /// No description provided for @success.
  ///
  /// In en, this message translates to:
  /// **'SUCCESS'**
  String get success;

  /// No description provided for @failed.
  ///
  /// In en, this message translates to:
  /// **'FAILED'**
  String get failed;

  /// No description provided for @credit.
  ///
  /// In en, this message translates to:
  /// **'CREDIT'**
  String get credit;

  /// No description provided for @debit.
  ///
  /// In en, this message translates to:
  /// **'DEBIT'**
  String get debit;

  /// No description provided for @profileDetails.
  ///
  /// In en, this message translates to:
  /// **'Profile Details'**
  String get profileDetails;

  /// No description provided for @address.
  ///
  /// In en, this message translates to:
  /// **'Address'**
  String get address;

  /// No description provided for @notProvided.
  ///
  /// In en, this message translates to:
  /// **'Not provided'**
  String get notProvided;

  /// No description provided for @profileDetailsSectionHeader.
  ///
  /// In en, this message translates to:
  /// **'Profile Details'**
  String get profileDetailsSectionHeader;

  /// No description provided for @editProfileInformation.
  ///
  /// In en, this message translates to:
  /// **'Edit Profile Information'**
  String get editProfileInformation;

  /// No description provided for @nameCannotBeEmpty.
  ///
  /// In en, this message translates to:
  /// **'Name cannot be empty'**
  String get nameCannotBeEmpty;

  /// No description provided for @nameMinimumCharacters.
  ///
  /// In en, this message translates to:
  /// **'Name must be at least 2 characters'**
  String get nameMinimumCharacters;

  /// No description provided for @addressCannotBeEmpty.
  ///
  /// In en, this message translates to:
  /// **'Address cannot be empty'**
  String get addressCannotBeEmpty;

  /// No description provided for @pleaseEnterCompleteAddress.
  ///
  /// In en, this message translates to:
  /// **'Please enter a complete address'**
  String get pleaseEnterCompleteAddress;

  /// No description provided for @phoneAndReferralNotChangeable.
  ///
  /// In en, this message translates to:
  /// **'Note: Phone number and referral code cannot be changed. Only name, email, and address can be updated.'**
  String get phoneAndReferralNotChangeable;

  /// No description provided for @updatingProfile.
  ///
  /// In en, this message translates to:
  /// **'Updating Profile...'**
  String get updatingProfile;

  /// No description provided for @updateProfile.
  ///
  /// In en, this message translates to:
  /// **'Update Profile'**
  String get updateProfile;

  /// No description provided for @profileUpdatedSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Profile Updated Successfully!'**
  String get profileUpdatedSuccessfully;

  /// No description provided for @profileUpdateSuccessMessage.
  ///
  /// In en, this message translates to:
  /// **'Your profile information has been updated successfully.'**
  String get profileUpdateSuccessMessage;

  /// No description provided for @updateFailed.
  ///
  /// In en, this message translates to:
  /// **'Update Failed'**
  String get updateFailed;

  /// No description provided for @inviteEarnRewards.
  ///
  /// In en, this message translates to:
  /// **'Invite & Earn Rewards'**
  String get inviteEarnRewards;

  /// No description provided for @shareReferralDescription.
  ///
  /// In en, this message translates to:
  /// **'Share your referral code with friends and family to earn exclusive rewards when they join Pashu Parivar'**
  String get shareReferralDescription;

  /// No description provided for @yourReferralCode.
  ///
  /// In en, this message translates to:
  /// **'Your Referral Code'**
  String get yourReferralCode;

  /// No description provided for @shareWithFriends.
  ///
  /// In en, this message translates to:
  /// **'Share with Friends'**
  String get shareWithFriends;

  /// No description provided for @shareLink.
  ///
  /// In en, this message translates to:
  /// **'Share Link'**
  String get shareLink;

  /// No description provided for @copyLink.
  ///
  /// In en, this message translates to:
  /// **'Copy Link'**
  String get copyLink;

  /// No description provided for @moreOptions.
  ///
  /// In en, this message translates to:
  /// **'More Options'**
  String get moreOptions;

  /// No description provided for @referralBenefits.
  ///
  /// In en, this message translates to:
  /// **'Referral Benefits'**
  String get referralBenefits;

  /// No description provided for @earnRewards.
  ///
  /// In en, this message translates to:
  /// **'Earn Rewards'**
  String get earnRewards;

  /// No description provided for @earnRewardsDescription.
  ///
  /// In en, this message translates to:
  /// **'Get exclusive rewards when your friends join using your code'**
  String get earnRewardsDescription;

  /// No description provided for @helpFriends.
  ///
  /// In en, this message translates to:
  /// **'Help Friends'**
  String get helpFriends;

  /// No description provided for @helpFriendsDescription.
  ///
  /// In en, this message translates to:
  /// **'Your friends also get special bonuses when they sign up'**
  String get helpFriendsDescription;

  /// No description provided for @unlimitedSharing.
  ///
  /// In en, this message translates to:
  /// **'Unlimited Sharing'**
  String get unlimitedSharing;

  /// No description provided for @unlimitedSharingDescription.
  ///
  /// In en, this message translates to:
  /// **'Share your code as many times as you want with anyone'**
  String get unlimitedSharingDescription;

  /// No description provided for @trackProgress.
  ///
  /// In en, this message translates to:
  /// **'Track Progress'**
  String get trackProgress;

  /// No description provided for @trackProgressDescription.
  ///
  /// In en, this message translates to:
  /// **'Monitor your referral success and rewards in your profile'**
  String get trackProgressDescription;

  /// No description provided for @howItWorks.
  ///
  /// In en, this message translates to:
  /// **'How It Works'**
  String get howItWorks;

  /// No description provided for @shareYourCode.
  ///
  /// In en, this message translates to:
  /// **'Share Your Code'**
  String get shareYourCode;

  /// No description provided for @shareYourCodeDescription.
  ///
  /// In en, this message translates to:
  /// **'Send your referral code or link to friends and family'**
  String get shareYourCodeDescription;

  /// No description provided for @friendSignsUp.
  ///
  /// In en, this message translates to:
  /// **'Friend Signs Up'**
  String get friendSignsUp;

  /// No description provided for @friendSignsUpDescription.
  ///
  /// In en, this message translates to:
  /// **'They create an account using your referral code'**
  String get friendSignsUpDescription;

  /// No description provided for @bothGetRewards.
  ///
  /// In en, this message translates to:
  /// **'Both Get Rewards'**
  String get bothGetRewards;

  /// No description provided for @bothGetRewardsDescription.
  ///
  /// In en, this message translates to:
  /// **'You and your friend receive exclusive bonuses'**
  String get bothGetRewardsDescription;

  /// No description provided for @linkCopiedToClipboard.
  ///
  /// In en, this message translates to:
  /// **'Link copied to clipboard!'**
  String get linkCopiedToClipboard;

  /// No description provided for @codeCopiedToClipboard.
  ///
  /// In en, this message translates to:
  /// **'Code copied to clipboard!'**
  String get codeCopiedToClipboard;

  /// No description provided for @referralHelp.
  ///
  /// In en, this message translates to:
  /// **'Referral Help'**
  String get referralHelp;

  /// No description provided for @referralHelpContent.
  ///
  /// In en, this message translates to:
  /// **'• Share your unique referral code with friends\n• Both you and your friend get rewards\n• No limit on how many friends you can refer\n• Track your referrals in your profile\n• Rewards are credited automatically'**
  String get referralHelpContent;

  /// No description provided for @shareMessage.
  ///
  /// In en, this message translates to:
  /// **'🐄 Join me on Pashu Parivar - India\'s trusted livestock marketplace! 🐄\n\nFind quality animals, connect with verified sellers, and grow your livestock business with premium features.\n\n✨ Use my referral code: {referralCode}\n🎁 Get exclusive rewards for both of us!\n\nDownload now: {referralUrl}\n\n#PashuParivar #Livestock #Farming #AnimalTrading'**
  String shareMessage(String referralCode, String referralUrl);

  /// No description provided for @termsOfService.
  ///
  /// In en, this message translates to:
  /// **'Terms of Service'**
  String get termsOfService;

  /// No description provided for @privacyPolicy.
  ///
  /// In en, this message translates to:
  /// **'Privacy Policy'**
  String get privacyPolicy;

  /// No description provided for @lastUpdated.
  ///
  /// In en, this message translates to:
  /// **'Last updated: July 27, 2025'**
  String get lastUpdated;

  /// No description provided for @acceptanceOfTerms.
  ///
  /// In en, this message translates to:
  /// **'Acceptance of Terms'**
  String get acceptanceOfTerms;

  /// No description provided for @acceptanceOfTermsContent.
  ///
  /// In en, this message translates to:
  /// **'By accessing and using Pashu Parivar, you accept and agree to be bound by the terms and provision of this agreement.'**
  String get acceptanceOfTermsContent;

  /// No description provided for @useLicense.
  ///
  /// In en, this message translates to:
  /// **'Use License'**
  String get useLicense;

  /// No description provided for @useLicenseContent.
  ///
  /// In en, this message translates to:
  /// **'Permission is granted to temporarily download one copy of Pashu Parivar per device for personal, non-commercial transitory viewing only.'**
  String get useLicenseContent;

  /// No description provided for @userResponsibilities.
  ///
  /// In en, this message translates to:
  /// **'User Responsibilities'**
  String get userResponsibilities;

  /// No description provided for @userResponsibilitiesContent.
  ///
  /// In en, this message translates to:
  /// **'• Provide accurate information when creating listings\n• Respect other users and maintain professional conduct\n• Comply with all applicable laws and regulations\n• Not misuse the platform for fraudulent activities'**
  String get userResponsibilitiesContent;

  /// No description provided for @platformServices.
  ///
  /// In en, this message translates to:
  /// **'Platform Services'**
  String get platformServices;

  /// No description provided for @platformServicesContent.
  ///
  /// In en, this message translates to:
  /// **'Pashu Parivar provides a platform for livestock trading, connecting buyers and sellers. We facilitate transactions but are not directly involved in the buying/selling process.'**
  String get platformServicesContent;

  /// No description provided for @accountSecurity.
  ///
  /// In en, this message translates to:
  /// **'Account Security'**
  String get accountSecurity;

  /// No description provided for @accountSecurityContent.
  ///
  /// In en, this message translates to:
  /// **'Users are responsible for maintaining the confidentiality of their account information and password. Notify us immediately of any unauthorized use.'**
  String get accountSecurityContent;

  /// No description provided for @paymentTerms.
  ///
  /// In en, this message translates to:
  /// **'Payment Terms'**
  String get paymentTerms;

  /// No description provided for @paymentTermsContent.
  ///
  /// In en, this message translates to:
  /// **'All payments for premium services are processed securely. Subscription fees are non-refundable unless specified otherwise.'**
  String get paymentTermsContent;

  /// No description provided for @contentGuidelines.
  ///
  /// In en, this message translates to:
  /// **'Content Guidelines'**
  String get contentGuidelines;

  /// No description provided for @contentGuidelinesContent.
  ///
  /// In en, this message translates to:
  /// **'All content uploaded must be appropriate, accurate, and comply with our community guidelines. We reserve the right to remove inappropriate content.'**
  String get contentGuidelinesContent;

  /// No description provided for @limitationOfLiability.
  ///
  /// In en, this message translates to:
  /// **'Limitation of Liability'**
  String get limitationOfLiability;

  /// No description provided for @limitationOfLiabilityContent.
  ///
  /// In en, this message translates to:
  /// **'Pashu Parivar shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of the service.'**
  String get limitationOfLiabilityContent;

  /// No description provided for @modifications.
  ///
  /// In en, this message translates to:
  /// **'Modifications'**
  String get modifications;

  /// No description provided for @modificationsContent.
  ///
  /// In en, this message translates to:
  /// **'We reserve the right to modify these terms at any time. Users will be notified of significant changes.'**
  String get modificationsContent;

  /// No description provided for @contactInformationContent.
  ///
  /// In en, this message translates to:
  /// **'For questions about these Terms of Service, please contact us at support@pashuparivar.com'**
  String get contactInformationContent;

  /// No description provided for @informationWeCollect.
  ///
  /// In en, this message translates to:
  /// **'Information We Collect'**
  String get informationWeCollect;

  /// No description provided for @informationWeCollectContent.
  ///
  /// In en, this message translates to:
  /// **'• Personal information: Name, phone number, email address\n• Profile information: Address, preferences, usage data\n• Device information: IP address, browser type, operating system\n• Usage data: App interactions, features used, session duration'**
  String get informationWeCollectContent;

  /// No description provided for @howWeUseYourInformation.
  ///
  /// In en, this message translates to:
  /// **'How We Use Your Information'**
  String get howWeUseYourInformation;

  /// No description provided for @howWeUseYourInformationContent.
  ///
  /// In en, this message translates to:
  /// **'We use collected information to:\n• Provide and maintain our services\n• Process transactions and send notifications\n• Improve user experience and app functionality\n• Communicate with you about updates and offers'**
  String get howWeUseYourInformationContent;

  /// No description provided for @informationSharing.
  ///
  /// In en, this message translates to:
  /// **'Information Sharing'**
  String get informationSharing;

  /// No description provided for @informationSharingContent.
  ///
  /// In en, this message translates to:
  /// **'We may share your information:\n• With other users (profile information in listings)\n• With service providers who assist our operations\n• When required by law or to protect our rights\n• With your consent for specific purposes'**
  String get informationSharingContent;

  /// No description provided for @dataSecurity.
  ///
  /// In en, this message translates to:
  /// **'Data Security'**
  String get dataSecurity;

  /// No description provided for @dataSecurityContent.
  ///
  /// In en, this message translates to:
  /// **'We implement appropriate security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction.'**
  String get dataSecurityContent;

  /// No description provided for @dataRetention.
  ///
  /// In en, this message translates to:
  /// **'Data Retention'**
  String get dataRetention;

  /// No description provided for @dataRetentionContent.
  ///
  /// In en, this message translates to:
  /// **'We retain your personal information only as long as necessary for the purposes outlined in this policy or as required by law.'**
  String get dataRetentionContent;

  /// No description provided for @yourRights.
  ///
  /// In en, this message translates to:
  /// **'Your Rights'**
  String get yourRights;

  /// No description provided for @yourRightsContent.
  ///
  /// In en, this message translates to:
  /// **'You have the right to:\n• Access your personal information\n• Correct inaccurate information\n• Delete your account and data\n• Opt-out of marketing communications'**
  String get yourRightsContent;

  /// No description provided for @cookiesAndTracking.
  ///
  /// In en, this message translates to:
  /// **'Cookies and Tracking'**
  String get cookiesAndTracking;

  /// No description provided for @cookiesAndTrackingContent.
  ///
  /// In en, this message translates to:
  /// **'We use cookies and similar technologies to enhance your experience, analyze usage patterns, and provide personalized content.'**
  String get cookiesAndTrackingContent;

  /// No description provided for @thirdPartyServices.
  ///
  /// In en, this message translates to:
  /// **'Third-Party Services'**
  String get thirdPartyServices;

  /// No description provided for @thirdPartyServicesContent.
  ///
  /// In en, this message translates to:
  /// **'Our app may contain links to third-party services. We are not responsible for their privacy practices.'**
  String get thirdPartyServicesContent;

  /// No description provided for @childrensPrivacy.
  ///
  /// In en, this message translates to:
  /// **'Children\'s Privacy'**
  String get childrensPrivacy;

  /// No description provided for @childrensPrivacyContent.
  ///
  /// In en, this message translates to:
  /// **'Our service is not intended for children under 13. We do not knowingly collect personal information from children under 13.'**
  String get childrensPrivacyContent;

  /// No description provided for @changesToThisPolicy.
  ///
  /// In en, this message translates to:
  /// **'Changes to This Policy'**
  String get changesToThisPolicy;

  /// No description provided for @changesToThisPolicyContent.
  ///
  /// In en, this message translates to:
  /// **'We may update this privacy policy from time to time. We will notify you of any changes by posting the new policy on this page.'**
  String get changesToThisPolicyContent;

  /// No description provided for @privacyContactContent.
  ///
  /// In en, this message translates to:
  /// **'If you have questions about this Privacy Policy, please contact us at:\nEmail: privacy@pashuparivar.com\nPhone: +91-XXXXXXXXXX'**
  String get privacyContactContent;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>[
    'en',
    'hi',
    'kn',
    'ml',
    'ta',
    'te',
  ].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'en':
      return AppLocalizationsEn();
    case 'hi':
      return AppLocalizationsHi();
    case 'kn':
      return AppLocalizationsKn();
    case 'ml':
      return AppLocalizationsMl();
    case 'ta':
      return AppLocalizationsTa();
    case 'te':
      return AppLocalizationsTe();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.',
  );
}
