// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Telugu (`te`).
class AppLocalizationsTe extends AppLocalizations {
  AppLocalizationsTe([String locale = 'te']) : super(locale);

  @override
  String get welcome => 'పశు కుటుంబానికి స్వాగతం';

  @override
  String get locationPermissionTitle => 'స్థాన అనుమతి';

  @override
  String get locationPermissionMessage => 'యాప్‌కు మీ స్థాన ప్రాప్తి అవసరం.';

  @override
  String get permissionDenied => 'అనుమతి నిరాకరించబడింది';

  @override
  String get permissionRetryMessage =>
      'ఈ ఫీచర్ కోసం స్థాన అనుమతి అవసరం. మళ్ళీ ప్రయత్నించాలా?';

  @override
  String get yes => 'అవును';

  @override
  String get no => 'లేదు';

  @override
  String get hi => 'హలో';

  @override
  String get newAnimal => 'కొత్త పశువు';

  @override
  String get newBuyers => 'కొత్త కొనుగోలుదారులు';

  @override
  String get buyAnimal => 'పశువును కొనండి';

  @override
  String get sellAnimal => 'పశువును అమ్మండి';

  @override
  String get otherServices => 'ఇతర సేవలు';

  @override
  String get knowMore => 'మరింత తెలుసుకోండి';

  @override
  String get clicklive => 'లైవ్ చూడండి';

  @override
  String get insurance => 'ఇన్సూరెన్స్';

  @override
  String get health => 'ఆరోగ్యం';

  @override
  String get liverace => 'లైవ్ రేస్‌లు';

  @override
  String get feed => 'మేత';

  @override
  String get getLocation => 'స్థానం పొందండి';

  @override
  String get getLocationMessage => 'మీ పశువుకు స్థానాన్ని పొందండి 📍';

  @override
  String get comingSoon => 'விரைவில் வருகிறது';

  @override
  String get firstUsers => 'మొదటి 10,000 వినియోగదారులకు లభిస్తుంది';

  @override
  String get referralBonusOnly => 'రిఫరల్ బోనస్ – కేవలం';

  @override
  String slotsLeft(Object slot) {
    return 'స్లాట్‌లు మిగిలి ఉన్నాయి!';
  }

  @override
  String get applyNow => 'ఇప్పుడు దరఖాస్తు చేయండి';

  @override
  String get pashuLoan => 'పశు రుణం';

  @override
  String get pashuInsurance => 'పశు బీమా';

  @override
  String get investInFarming => 'వ్యవసాయంలో పెట్టుబడి పెట్టండి';

  @override
  String get growWealth => 'ప్రకృతితో మీ సంపదను పెంచుకోండి';

  @override
  String get startInvesting => 'పెట్టుబడి పెట్టడం ప్రారంభించండి';

  @override
  String get editProfile => 'ప్రొఫైల్ సవరించు';

  @override
  String get animalHistory => 'జంతు జాబితా చరిత్ర';

  @override
  String get referralCode => 'రెఫరల్ కోడ్';

  @override
  String get logout => 'లాగ్అవుట్';

  @override
  String get yourListedPashu => 'మీ జాబితా చేసిన పశువులు';

  @override
  String get termsPrivacy => 'నిబంధనలు & గోప్యతా';

  @override
  String get contactUs => 'మమ్మల్ని సంప్రదించండి';

  @override
  String get account => 'ఖాతా';

  @override
  String get soldOutPashuHistory => 'అమ్మిన పశువుల చరిత్ర';

  @override
  String get walletBalance => 'వాలెట్ బ్యాలెన్స్';

  @override
  String get addAmountInWallet => 'వాలెట్‌లో మొత్తం జోడించండి';

  @override
  String get myTransaction => 'నా లావాదేవీ';

  @override
  String get addMoneyToWallet => 'మీ వాలెట్‌లో డబ్బు జోడించండి';

  @override
  String get enterAmount => 'మొత్తాన్ని నమోదు చేయండి';

  @override
  String get enterAmountExample => 'ఉదాహరణ: 500 నమోదు చేయండి';

  @override
  String get add => 'జోడించు';

  @override
  String get walletTip =>
      'సూచన: మీరు తక్షణమే సంప్రదింపు వివరాలు చూడటానికి వాలెట్‌ను ఉపయోగించవచ్చు.';

  @override
  String get getVerifiedPashu => 'మీ పశువును ధృవీకరించండి';

  @override
  String get withdrawBalance => 'బ్యాలెన్స్ ఉపసంహరించుకోండి';

  @override
  String get signIn => 'సైన్ ఇన్';

  @override
  String get enterPhoneNumberToContinue =>
      'కొనసాగించడానికి మీ ఫోన్ నంబర్‌ను నమోదు చేయండి';

  @override
  String get phoneNumber => 'ఫోన్ నంబర్';

  @override
  String get enterPhoneNumber => 'ఫోన్ నంబర్‌ను నమోదు చేయండి';

  @override
  String get sendOTP => 'ఓటిపి పంపండి';

  @override
  String get or => 'లేదా';

  @override
  String get dontHaveAccount => 'ఖాతా లేదా? ఇప్పుడే రిజిస్టర్ చేయండి';

  @override
  String get phoneNumberRequired => 'ఫోన్ నంబర్ అవసరం';

  @override
  String get enterValidPhoneNumber =>
      'చెల్లుబాటు అయ్యే 10 అంకెల భారతీయ ఫోన్ నంబర్‌ను నమోదు చేయండి';

  @override
  String otpSentTo(Object phoneNumber) {
    return 'ఓటిపి +91 $phoneNumber కు పంపబడింది';
  }

  @override
  String get register => 'రిజిస్టర్';

  @override
  String get login => 'లాగిన్';

  @override
  String get registerNow => 'ఇప్పుడే రిజిస్టర్ చేయండి';

  @override
  String get enterYourName => 'మీ పేరును నమోదు చేయండి';

  @override
  String get enterReferralCode => 'రిఫరల్ కోడ్‌ను నమోదు చేయండి (ఐచ్ఛికం)';

  @override
  String get getOTP => 'ఓటిపి పొందండి';

  @override
  String get alreadyHaveAccount => 'ఇప్పటికే ఖాతా ఉందా? సైన్ ఇన్ చేయండి';

  @override
  String get optional => 'ఐచ్ఛికం';

  @override
  String get nameIsRequired => 'పేరు అవసరం';

  @override
  String get nameMinLength => 'పేరు కనీసం 2 అక్షరాలు ఉండాలి';

  @override
  String get failedToSendOTP =>
      'ఓటిపి పంపడంలో విఫలమైంది. దయచేసి మళ్లీ ప్రయత్నించండి.';

  @override
  String get enterOTP => 'ఓటిపి నమోదు చేయండి';

  @override
  String otpSentMessage(Object phoneNumber) {
    return 'మేము +91 $phoneNumber కు 6 అంకెల ఓటిపి పంపాము';
  }

  @override
  String get enterComplete6DigitOTP =>
      'దయచేసి పూర్తిగా 6 అంకెల ఓటిపి నమోదు చేయండి';

  @override
  String get successfulLogin => 'విజయవంతమైన లాగిన్';

  @override
  String get didntReceiveOTP => 'ఓటిపి రాలేదా?';

  @override
  String resendIn(Object seconds) {
    return '$seconds సెకన్లలో మళ్లీ పంపండి';
  }

  @override
  String get resendOTP => 'ఓటిపి మళ్లీ పంపండి';

  @override
  String get resending => 'మళ్లీ పంపుతున్నాం...';

  @override
  String otpResentTo(Object phoneNumber) {
    return 'ఓటిపి +91 $phoneNumber కు మళ్లీ పంపబడింది';
  }

  @override
  String get failedToResendOTP =>
      'ఓటిపి మళ్లీ పంపడంలో విఫలమైంది. దయచేసి మళ్లీ ప్రయత్నించండి.';

  @override
  String get homeScreen => 'హోమ్';

  @override
  String get welcomeToHomeScreen => 'హోమ్ స్క్రీన్‌కు స్వాగతం!';

  @override
  String get newBadge => 'కొత్తది';

  @override
  String get logoutConfirmation =>
      'మీరు ఖచ్చితంగా మీ ఖాతా నుండి లాగ్ అవుట్ కావాలనుకుంటున్నారా?';

  @override
  String get cancel => 'రద్దు చేయండి';

  @override
  String get failedToLoadProfile => 'ప్రొఫైల్ లోడ్ చేయడంలో విఫలమైంది';

  @override
  String get uploadPashuImageOne => 'మీ పశు చిత్రం ఒకటి అప్‌లోడ్ చేయండి';

  @override
  String get selectPictureOne => 'చిత్రం ఒకటి ఎంచుకోండి';

  @override
  String get uploadPashuImageTwo => 'మీ పశు చిత్రం రెండు అప్‌లోడ్ చేయండి';

  @override
  String get selectPictureTwo => 'చిత్రం రెండు ఎంచుకోండి';

  @override
  String get paymentCompletedSuccessfully => 'చెల్లింపు విజయవంతంగా పూర్తయింది!';

  @override
  String get paymentVerificationFailed =>
      'చెల్లింపు ధృవీకరణ విఫలమైంది. దయచేసి మళ్లీ ప్రయత్నించండి.';

  @override
  String get errorVerifyingPayment => 'చెల్లింపును ధృవీకరించడంలో లోపం';

  @override
  String get insuranceApplication => 'బీమా దరఖాస్తు';

  @override
  String get responseReceived => 'ప్రతిస్పందన అందింది!';

  @override
  String get insuranceThankYouMessage =>
      'మీ పశు బీమా దరఖాస్తును సమర్పించినందుకు ధన్యవాదాలు. మరిన్ని వివరాల కోసం మా బృందం త్వరలో మీతో సంప్రదిస్తుంది.';

  @override
  String get selectLanguage => 'భాషను ఎంచుకోండి';

  @override
  String get ok => 'సరే';

  @override
  String get appTitle => 'పశు కుటుంబం';

  @override
  String get languageShort => 'हि/E/ತ';

  @override
  String get wishlist => 'విష్‌లిస్ట్';

  @override
  String get loanFormTitle => 'పశు రుణ ఫారం';

  @override
  String get loanApplicationHeader => 'పశు రుణ దరఖాస్తు';

  @override
  String get loanApplicationSubheader =>
      'మీ పశుపోషణ అవసరాలకు ఆర్థిక సహాయం పొందండి';

  @override
  String get loanApplicationDetails => 'రుణ దరఖాస్తు వివరాలు';

  @override
  String get applicantInformation => 'దరఖాస్తుదారు సమాచారం';

  @override
  String get applicantName => 'దరఖాస్తుదారు పేరు';

  @override
  String get applicantNameRequired => 'దరఖాస్తుదారు పేరు అవసరం';

  @override
  String get applicantAddress => 'దరఖాస్తుదారు చిరునామా';

  @override
  String get applicantAddressRequired => 'దరఖాస్తుదారు చిరునామా అవసరం';

  @override
  String get contactNumber => 'సంప్రదింపు సంఖ్య';

  @override
  String get contactNumberRequired => 'సంప్రదింపు సంఖ్య అవసరం';

  @override
  String get contactNumberInvalid =>
      'దయచేసి సరైన సంప్రదింపు సంఖ్యను నమోదు చేయండి';

  @override
  String get emailAddress => 'ఇమెయిల్ చిరునామా';

  @override
  String get emailAddressRequired => 'ఇమెయిల్ చిరునామా అవసరం';

  @override
  String get emailAddressInvalid =>
      'దయచేసి సరైన ఇమెయిల్ చిరునామాను నమోదు చేయండి';

  @override
  String get loanInformation => 'రుణ సమాచారం';

  @override
  String get loanAmount => 'రుణ మొత్తం (₹)';

  @override
  String get loanAmountRequired => 'రుణ మొత్తం అవసరం';

  @override
  String get loanAmountInvalid => 'దయచేసి సరైన రుణ మొత్తాన్ని నమోదు చేయండి';

  @override
  String get repaymentPeriod => 'తిరిగి చెల్లించే కాలం';

  @override
  String get repaymentPeriodRequired => 'తిరిగి చెల్లించే కాలం అవసరం';

  @override
  String get incomeSource => 'ఆదాయ మూలం';

  @override
  String get incomeSourceRequired => 'ఆదాయ మూలం అవసరం';

  @override
  String get purposeOfLoan => 'రుణ ఉద్దేశ్యం';

  @override
  String get purposeOfLoanRequired => 'రుణ ఉద్దేశ్యం అవసరం';

  @override
  String get additionalInformation => 'అదనపు సమాచారం';

  @override
  String get additionalRemarks => 'అదనపు వ్యాఖ్యలు';

  @override
  String get additionalRemarksRequired => 'అదనపు వ్యాఖ్యలు అవసరం';

  @override
  String get submittingForm => 'ఫారం సమర్పించబడుతోంది...';

  @override
  String get submitForm => 'ఫారాన్ని సమర్పించండి';

  @override
  String get loanTermsNote =>
      'ఈ ఫారాన్ని సమర్పించడం ద్వారా, మీరు మా రుణ నిబంధనలు మరియు షరతులను అంగీకరిస్తారు. మా బృందం మీ దరఖాస్తును సమీక్షించి 3-5 వ్యాపార రోజుల్లో రుణ ఆమోద స్థితిని సంప్రదిస్తుంది.';

  @override
  String get allFieldsRequired => 'అన్ని ఫీల్డ్‌లు అవసరం';

  @override
  String get animalInformation => 'జంతువు సమాచారం';

  @override
  String get animalAgeInvalid => 'దయచేసి సరైన ప్రాణి వయస్సును నమోదు చేయండి';

  @override
  String get animalWeightInvalid => 'దయచేసి సరైన ప్రాణి బరువును నమోదు చేయండి';

  @override
  String get allowLocationAccess => 'స్థానాన్ని అనుమతించండి';

  @override
  String get locationDescription =>
      'మీ ప్రాంతంలో సమీపంలోని పశువులు, ఈవెంట్లు మరియు వ్యక్తిగతీకరించిన కంటెంట్‌ను చూపించడానికి మీ స్థానం అవసరం.';

  @override
  String get locationPrivacyNote =>
      'మీ స్థానం డేటా సురక్షితంగా ఉంటుంది మరియు మీ అనుభవాన్ని మెరుగుపరచడానికి మాత్రమే ఉపయోగించబడుతుంది.';

  @override
  String get liveRaces => 'ప్రత్యక్ష రేసులు';

  @override
  String get viewLive => 'ప్రత్యక్షంగా చూడండి';

  @override
  String get animalInsurance => 'పశు బీమా';

  @override
  String get insuranceFormTitle => 'పశు బీమా ఫారం';

  @override
  String get insuranceApplicationHeader => 'పశు బీమా దరఖాస్తు';

  @override
  String get insuranceApplicationSubheader =>
      'మీ పశు బీమా అవసరాలకు ఆర్థిక సహాయం పొందండి';

  @override
  String get insuranceApplicationDetails => 'బీమా దరఖాస్తు వివరాలు';

  @override
  String get ownerInformation => 'యజమాని సమాచారం';

  @override
  String get ownerName => 'యజమాని పేరు';

  @override
  String get ownerNameRequired => 'యజమాని పేరు అవసరం';

  @override
  String get ownerAddress => 'యజమాని చిరునామా';

  @override
  String get ownerAddressRequired => 'యజమాని చిరునామా అవసరం';

  @override
  String get animalType => 'పశు రకం';

  @override
  String get animalTypeRequired => 'పశు రకం అవసరం';

  @override
  String get animalBreed => 'పశు జాతి';

  @override
  String get animalBreedRequired => 'పశు జాతి అవసరం';

  @override
  String get animalAge => 'పశు వయస్సు';

  @override
  String get animalAgeRequired => 'పశు వయస్సు అవసరం';

  @override
  String get animalColor => 'పశు రంగు';

  @override
  String get animalColorRequired => 'పశు రంగు అవసరం';

  @override
  String get animalWeight => 'పశు బరువు';

  @override
  String get animalWeightRequired => 'పశు బరువు అవసరం';

  @override
  String get healthStatus => 'ఆరోగ్య స్థితి';

  @override
  String get healthStatusRequired => 'ఆరోగ్య స్థితి అవసరం';

  @override
  String get insuranceTermsNote =>
      'ఈ ఫారాన్ని సమర్పించడం ద్వారా, మీరు మా బీమా నిబంధనలు మరియు షరతులను అంగీకరిస్తారు. మా బృందం మీ దరఖాస్తును సమీక్షించి 3-5 వ్యాపార రోజుల్లో బీమా ఆమోద స్థితిని సంప్రదిస్తుంది.';

  @override
  String get liveRaceTitle => 'లైవ్ రేస్';

  @override
  String get liveRaceHeader => 'లైవ్ రేస్';

  @override
  String get chooseRaceCategory => 'మీ రేస్ వర్గాన్ని ఎంచుకోండి';

  @override
  String get raceExperienceSubheader =>
      'పారంపర్య జంతు పందెం ఉల్లాసాన్ని అనుభవించండి';

  @override
  String get raceCategoryFallback => 'రేస్ వర్గం';

  @override
  String get raceCategoryDetailFallback =>
      'ఉల్లాసమైన రేస్‌లో చేరండి మరియు పారంపర్య జంతు పందెం ఉల్లాసాన్ని అనుభవించండి';

  @override
  String get liveNow => 'இப்போது நேரலை';

  @override
  String get tapToJoin => 'చేరడానికి ట్యాప్ చేయండి';

  @override
  String get liveBadge => 'లైవ్';

  @override
  String get failedToLoadCategories => 'వర్గాలను లోడ్ చేయడంలో విఫలమయ్యారు';

  @override
  String get somethingWentWrong => 'ఏదో తప్పు జరిగింది';

  @override
  String get retry => 'మళ్ళీ ప్రయత్నించండి';

  @override
  String get noLiveRacesAvailable => 'లైవ్ రేస్‌లు లభ్యం కావు';

  @override
  String get checkBackLater =>
      'ఉల్లాసమైన లైవ్ రేసింగ్ ఈవెంట్స్ కోసం తర్వాత చెక్ చేయండి';

  @override
  String get raceCategory => 'பந்தய வகை';

  @override
  String get traditionalRacingExperience => 'பாரம்பரிய பந்தய அனுபவம்';

  @override
  String get raceInformation => 'பந്தய தகவல்';

  @override
  String get category => 'వర్గం';

  @override
  String get status => 'நிலை';

  @override
  String get participants => 'பங்கேற்பாளர்கள்';

  @override
  String get multipleEntries => 'பல பதிவுகள்';

  @override
  String get duration => 'వ్యవధి';

  @override
  String get ongoing => 'நடைபெற்று வரும்';

  @override
  String get prize => 'பரிசு';

  @override
  String get trophiesAndRecognition => 'கோப்பைகள் மற்றும் அங்கீகாரம்';

  @override
  String get raceIsLiveNow => 'பந்தயம் இப்போது நேரலையில்!';

  @override
  String get watchExcitingCompetition => 'உற்சாகமான போட்டியைப் பார்க்கவும்';

  @override
  String get aboutThisRace => 'இந்த பந்தயம் பற்றி';

  @override
  String get defaultRaceDescription =>
      'இந்த உற்சாகமான நேரலை நிகழ்வில் பாரம்பரிய விலங்கு பந்தயத்தின் சிலிர்ப்பை அனுபவிக்கவும். மனிதர்களுக்கும் விலங்குகளுக்கும் இடையிலான பிணைப்பை வெளிப்படுத்தும் இந்த காலத்தால் மதிக்கப்படும் பாரம்பரியத்தில் திறமையான பங்கேற்பாளர்கள் போட்டியிடுவதைப் பாருங்கள்.';

  @override
  String get liveStream => 'நேரலை ஒளிபரப்பு';

  @override
  String get liveStreamComingSoon => 'நேரலை ஒளிபரப்பு விரைவில் வருகிறது';

  @override
  String get youtubeLinksAvailable =>
      'ஸ்ட்ரீமிங் தொடங்கும்போது YouTube இணைப்புகள் கிடைக்கும்';

  @override
  String get getNotifiedWhenStreaming =>
      'இந்த பந்தய வகைக்கு நேரலை ஒளிபரப்பு தொடங்கும்போது அறிவிப்பு பெறுங்கள்';

  @override
  String get liveRace => 'நேரலை பந்தயம்';

  @override
  String get na => 'கிடைக்கவில்லை';

  @override
  String get regionalChampionship => 'பிராந்திய சாம்பியன்ஷிப்';

  @override
  String get districtFinals => 'மாவட்ட இறுதிப்போட்டி';

  @override
  String get stateCompetition => 'மாநில போட்டி';

  @override
  String get tomorrowTenAM => 'நாளை காலை 10:00 மணிக்கு';

  @override
  String get nextWeek => 'அடுத்த வாரம்';

  @override
  String get sellPashu => 'పశువు అమ్మండి';

  @override
  String get youCanProceedWithListing => 'మీరు లిస్టింగ్‌తో కొనసాగవచ్చు';

  @override
  String get minimumRequiredToList =>
      'మీ జంతువును జాబితా చేయడానికి కనీసం ₹15 అవసరం';

  @override
  String get animalTypes => 'జంతు రకాలు';

  @override
  String get selectAnimalType => 'జంతు రకాన్ని ఎంచుకోండి';

  @override
  String get animalCategory => 'జంతు వర్గం';

  @override
  String get pleaseSelectAnimalTypeFirst =>
      'దయచేసి మొదట జంతు రకాన్ని ఎంచుకోండి';

  @override
  String get selectAnimalCategory => 'జంతు వర్గాన్ని ఎంచుకోండి';

  @override
  String get nameOfTheAnimal => 'జంతువు పేరు';

  @override
  String get enterAnimalAge => 'జంతువు వయస్సు నమోదు చేయండి';

  @override
  String get selectGenderOfAnimal => 'జంతువు లింగాన్ని ఎంచుకోండి';

  @override
  String get price => 'ధర';

  @override
  String get negotiable => 'చర్చించదగినది';

  @override
  String get isPriceNegotiable => 'ధర చర్చించదగినదా?';

  @override
  String get yourPhoneNumber => 'మీ ఫోన్ నంబర్';

  @override
  String get enterYourPhoneNumber => 'మీ ఫోన్ నంబర్ నమోదు చేయండి';

  @override
  String get animalDescription => 'జంతువు వివరణ';

  @override
  String get enterAnimalDescription => 'జంతువు వివరణ నమోదు చేయండి';

  @override
  String get getAddressForPashu => 'పశువు కోసం చిరునామా పొందండి';

  @override
  String get submitAndPay => 'సమర్పించి ₹15 చెల్లించండి';

  @override
  String get insufficientBalance =>
      'తగినంత బ్యాలెన్స్ లేదు. దయచేసి నిధులు జోడించండి।';

  @override
  String get submitting => 'సమర్పిస్తోంది...';

  @override
  String get locationServicesDisabled => 'లొకేషన్ సేవలు నిలిపివేయబడ్డాయి';

  @override
  String get locationPermissionPermanentlyDenied =>
      'లొకేషన్ అనుమతి శాశ్వతంగా తిరస్కరించబడింది';

  @override
  String get locationPermissionDenied => 'లొకేషన్ అనుమతి తిరస్కరించబడింది';

  @override
  String get unableToDetermineAddress => 'చిరునామాను గుర్తించలేకపోయాం';

  @override
  String get error => 'లోపం';

  @override
  String get missingRequiredFields => 'అవసరమైన ఫీల్డ్‌లు లేవు';

  @override
  String get pleaseEnterValidPhoneNumber =>
      'దయచేసి చెల్లుబాటు అయ్యే ఫోన్ నంబర్ నమోదు చేయండి';

  @override
  String get pleaseEnterValidAge =>
      'దయచేసి చెల్లుబాటు అయ్యే వయస్సు నమోదు చేయండి';

  @override
  String get pleaseEnterValidPrice => 'దయచేసి చెల్లుబాటు అయ్యే ధర నమోదు చేయండి';

  @override
  String get pashuListedSuccessfully => 'పశువు విజయవంతంగా జాబితా చేయబడింది!';

  @override
  String get errorOccurred => 'ఒక లోపం సంభవించింది';

  @override
  String get selectCategory => 'వర్గాన్ని ఎంచుకోండి';

  @override
  String get selectGender => 'లింగాన్ని ఎంచుకోండి';

  @override
  String get male => 'మగ';

  @override
  String get female => 'ఆడ';

  @override
  String get user => 'వినియోగదారు';

  @override
  String get other => 'ఇతర';

  @override
  String get unknown => 'తెలియదు';

  @override
  String get traditionalSportsAnimal => 'సాంప్రదాయ క్రీడా జంతువు';

  @override
  String get livestockAnimal => 'పశువుల జంతువు';

  @override
  String get petAnimal => 'పెంపుడు జంతువు';

  @override
  String get farmHouseAnimal => 'ఫార్మ్ హౌస్ జంతువు';

  @override
  String get bull => 'ఎద్దు';

  @override
  String get camel => 'ఒంటె';

  @override
  String get bird => 'పక్షి';

  @override
  String get pigeon => 'పావురం';

  @override
  String get cock => 'కోడిమేక';

  @override
  String get dog => 'కుక్క';

  @override
  String get goat => 'మేక';

  @override
  String get horse => 'గుర్రం';

  @override
  String get buffalo => 'గేదె';

  @override
  String get sheep => 'గొర్రె';

  @override
  String get pigs => 'వర్రాహాలు';

  @override
  String get cat => 'పిల్లి';

  @override
  String get fishes => 'చేపలు';

  @override
  String get smallMammals => 'చిన్న క్షీరదాలు';

  @override
  String get searchAnimalsBreeds => 'జంతువులు, జాతులను వెతకండి...';

  @override
  String get unknownAnimal => 'తెలియని జంతువు';

  @override
  String get breed => 'జాతి';

  @override
  String get owner => 'యజమాని';

  @override
  String get callMe => 'నాకు కాల్ చేయండి';

  @override
  String get buyNow => 'ఇప్పుడే కొనండి';

  @override
  String get addedToWishlist => 'విష్‌లిస్ట్‌కు జోడించబడింది';

  @override
  String get animal => 'జంతువు';

  @override
  String get failedToAddToWishlist => 'విష్‌లిస్ట్‌కు జోడించడంలో విఫలమైంది';

  @override
  String get noAnimalsFound => 'జంతువులు కనుగొనబడలేదు';

  @override
  String get trySelectingDifferentCategory =>
      'వేరే వర్గాన్ని ఎంచుకోవడానికి ప్రయత్నించండి';

  @override
  String get checkBackLaterForNewListings =>
      'కొత్త లిస్టింగ్‌ల కోసం తర్వాత తనిఖీ చేయండి';

  @override
  String get purchaseRequestSent => 'కొనుగోలు అభ్యర్థన పంపబడింది';

  @override
  String get all => 'అన్ని';

  @override
  String get cow => 'ఆవు';

  @override
  String get cats => 'పిల్లులు';

  @override
  String get animalDetails => 'జంతువు వివరాలు';

  @override
  String get photos => 'ఫోటోలు';

  @override
  String get type => 'రకం';

  @override
  String get age => 'వయస్సు';

  @override
  String get gender => 'లింగం';

  @override
  String get years => 'సంవత్సరాలు';

  @override
  String get pricingInformation => 'ధర సమాచారం';

  @override
  String get fixedPrice => 'స్థిర ధర';

  @override
  String get ownerAndLocation => 'యజమాని మరియు స్థానం';

  @override
  String get location => 'స్థానం';

  @override
  String get distance => 'దూరం';

  @override
  String get notSpecified => 'పేర్కొనబడలేదు';

  @override
  String get meters => 'మీటర్లు';

  @override
  String get km => 'కిమీ';

  @override
  String get description => 'వివరణ';

  @override
  String get contactSeller => 'విక్రేతతో సంప్రదించండి';

  @override
  String get unlockContactDetails =>
      'విక్రేతతో కనెక్ట్ అవ్వడానికి ₹2కి సంప్రదింపు వివరాలను అన్‌లాక్ చేయండి';

  @override
  String get unlocking => 'అన్‌లాక్ చేస్తోంది...';

  @override
  String get unlockContact => 'సంప్రదింపును అన్‌లాక్ చేయండి (₹2)';

  @override
  String get contactOptions => 'సంప్రదింపు ఎంపికలు';

  @override
  String get call => 'కాల్';

  @override
  String get whatsApp => 'వాట్సాప్';

  @override
  String get contact => 'సంప్రదింపు';

  @override
  String get notAvailable => 'లభ్యం కాదు';

  @override
  String get userNotLoggedIn => 'వినియోగదారు లాగిన్ కాలేదు';

  @override
  String get userDataNotFound => 'వినియోగదారు డేటా కనుగొనబడలేదు';

  @override
  String get contactAlreadyUnlocked =>
      'ఈ సంప్రదింపు ఇప్పటికే అన్‌లాక్ చేయబడింది।';

  @override
  String get contactUnlockedSuccessfully =>
      'సంప్రదింపు విజయవంతంగా అన్‌లాక్ చేయబడింది!';

  @override
  String get couldNotLaunchPhoneApp => 'ఫోన్ యాప్‌ను లాంచ్ చేయలేకపోయింది';

  @override
  String get phoneNumberNotAvailable => 'ఫోన్ నంబర్ అందుబాటులో లేదు';

  @override
  String get couldNotOpenWhatsApp => 'వాట్సాప్‌ను తెరవలేకపోయింది';

  @override
  String whatsAppMessageTemplate(Object animalName) {
    return 'హాయ్, పశు పరివార్‌లో లిస్ట్ చేసిన మీ $animalNameలో నాకు ఆసక్తి ఉంది।';
  }

  @override
  String get locationNotAvailable => 'లొకేషన్ అందుబాటులో లేదు';

  @override
  String get remove => 'తీసివేయండి';

  @override
  String get removedFromWishlist => 'విష్‌లిస్ట్ నుండి తీసివేయబడింది';

  @override
  String get failedToRemove => 'తీసివేయడంలో విఫలమైంది';

  @override
  String get animalDetailsComingSoon => 'జంతువు వివరాలు త్వరలో వస్తున్నాయి';

  @override
  String get fullAnimalDetailsModal =>
      'పూర్తి జంతువు వివరాల మోడల్ ఇక్కడ అమలు చేయబడుతుంది';

  @override
  String get noWishlistAnimalsFound => 'విష్‌లిస్ట్ జంతువులు కనుగొనబడలేదు';

  @override
  String get tryAddingAnimalsToWishlist =>
      'మీ విష్‌లిస్ట్‌కు కొన్ని జంతువులను జోడించడానికి ప్రయత్నించండి!';

  @override
  String get investmentProject => 'పెట్టుబడి ప్రాజెక్ట్';

  @override
  String get upcomingProjects => 'రాబోయే ప్రాజెక్ట్‌లు';

  @override
  String get liveProjects => 'లైవ్ ప్రాజెక్ట్‌లు';

  @override
  String get completedProjects => 'పూర్తయిన ప్రాజెక్ట్‌లు';

  @override
  String get mvpForAquacultureInvestment => 'ఆక్వాకల్చర్ పెట్టుబడి కోసం MVP';

  @override
  String get longTerm => 'దీర్ఘకాలిక';

  @override
  String get amount => 'మొత్తం';

  @override
  String get startDate => 'ప్రారంభ తేదీ';

  @override
  String get sixToEightMonths => '6 నుండి 8 నెలలు';

  @override
  String get lotsBooked => 'లాట్‌లు బుక్ చేయబడ్డాయి';

  @override
  String get noProjectsAvailable => 'ప్రాజెక్ట్‌లు అందుబాటులో లేవు।';

  @override
  String get firstAugust2025 => '1 ఆగస్ట్ 2025';

  @override
  String get addAmountAndGetPlans => 'మొత్తం జోడించి ప్లాన్‌లు పొందండి';

  @override
  String get getVerifiedYourPashu => 'మీ పశువును ధృవీకరించుకోండి';

  @override
  String get termsAndPrivacy => 'నియమాలు & గోప్యత';

  @override
  String get newA => 'కొత్త';

  @override
  String get areYouSureLogout =>
      'మీరు మీ ఖాతా నుండి లాగ్అవుట్ కావాలని ఖచ్చితంగా అనుకుంటున్నారా?';

  @override
  String get noProfileFound => 'ప్రొఫైల్ కనుగొనబడలేదు';

  @override
  String get profileInformationNotAvailable =>
      'ప్రొఫైల్ సమాచారం అందుబాటులో లేదు';

  @override
  String get subscriptionPlans => 'సబ్‌స్క్రిప్షన్ ప్లాన్‌లు';

  @override
  String get chooseYourPlan => 'మీ ప్లాన్‌ను ఎంచుకోండి';

  @override
  String get unlockPremiumFeatures =>
      'ప్రీమియం ఫీచర్‌లను అన్‌లాక్ చేసి, మా సబ్‌స్క్రిప్షన్ ప్లాన్‌లతో మీ పశువుల వ్యాపారాన్ని పెంచుకోండి';

  @override
  String get diamondPlan => 'డైమండ్ ప్లాన్';

  @override
  String get goldPlan => 'గోల్డ్ ప్లాన్';

  @override
  String get silverPlan => 'సిల్వర్ ప్లాన్';

  @override
  String get year => 'సంవత్సరం';

  @override
  String get months3 => '3 నెలలు';

  @override
  String get month => 'నెల';

  @override
  String get choosePlan => 'ప్లాన్ ఎంచుకోండి';

  @override
  String get unlimitedPashuProfileContact =>
      'అన్‌లిమిటెడ్ పశు ప్రొఫైల్ కాంటాక్ట్';

  @override
  String get unlimitedFreePashuListings => 'అన్‌లిమిటెడ్ ఉచిత పశు లిస్టింగ్‌లు';

  @override
  String get priorityCustomerSupport => 'ప్రాధాన్యత కస్టమర్ సపోర్ట్';

  @override
  String get advancedAnalytics => 'అధునాతన విశ్లేషణలు';

  @override
  String get premiumBadge => 'ప్రీమియం బ్యాడ్జ్';

  @override
  String get freePashuListings10 => '10 ఉచిత పశు లిస్టింగ్‌లు';

  @override
  String get standardCustomerSupport => 'ప్రామాణిక కస్టమర్ సపోర్ట్';

  @override
  String get basicAnalytics => 'ప్రాథమిక విశ్లేషణలు';

  @override
  String get freePashuListings2 => '2 ఉచిత పశు లిస్టింగ్‌లు';

  @override
  String get emailSupport => 'ఇమెయిల్ సపోర్ట్';

  @override
  String get addMoneyToYourWallet => 'మీ వాలెట్‌కు డబ్బు జోడించండి';

  @override
  String get addFundsToWallet =>
      'మీ వాలెట్‌కు ఫండ్స్ జోడించి, సబ్‌స్క్రిప్షన్‌ల కోసం సులభంగా చెల్లించండి। మీ వాలెట్ మా అన్ని సేవలలో ఉపయోగించవచ్చు.';

  @override
  String get enterAmountEg500 => 'మొత్తం నమోదు చేయండి (ఉదా. 500)';

  @override
  String addAmount(String amount) {
    return '₹$amount జోడించండి';
  }

  @override
  String get tipWalletContact =>
      'చిట్కా: మీ వాలెట్‌ను కాంటాక్ట్ వివరాలను తక్షణమే చూడటానికి ఉపయోగించవచ్చు.';

  @override
  String subscribeToPlan(String planName) {
    return 'Subscribe to $planName';
  }

  @override
  String chargedForSubscription(String price, String period) {
    return 'ఈ $period సబ్‌స్క్రిప్షన్ కోసం మీకు ₹$price చార్జ్ చేయబడుతుంది.';
  }

  @override
  String get confirmSubscription => 'సబ్‌స్క్రిప్షన్‌ను ధృవీకరించండి';

  @override
  String get subscriptionSuccessful => 'సబ్‌స్క్రిప్షన్ విజయవంతం!';

  @override
  String subscriptionSuccessMessage(String planName) {
    return 'మీరు విజయవంతంగా $planNameకు సబ్‌స్క్రైబ్ చేసారు. అన్ని ప్రీమియం ఫీచర్‌లను ఆనందించండి!';
  }

  @override
  String get continueA => 'కొనసాగించండి';

  @override
  String get subscriptionHelp => 'సబ్‌స్క్రిప్షన్ సహాయం';

  @override
  String get helpContent =>
      '• డైమండ్ ప్లాన్: ₹365/సంవత్సరం\n• గోల్డ్ ప్లాన్: ₹140/3 నెలలు\n• సిల్వర్ ప్లాన్: ₹49/నెల\n• మీ ప్రొఫైల్ నుండి ఎప్పుడైనా రద్దు చేయండి\n• అన్ని ఫీచర్‌లు తక్షణమే అన్‌లాక్ అవుతాయి\n• 24/7 కస్టమర్ సపోర్ట్ చేర్చబడింది';

  @override
  String get gotIt => 'అర్థమైంది';

  @override
  String get pleaseEnterValidAmount =>
      'దయచేసి చెల్లుబాటు అయ్యే మొత్తాన్ని నమోదు చేయండి';

  @override
  String get couldNotInitiatePayment => 'చెల్లింపును ప్రారంభించలేకపోయింది';

  @override
  String get somethingWentWrongPayment => 'చెల్లింపులో ఏదో తప్పు జరిగింది.';

  @override
  String get paymentCancelled =>
      'చెల్లింపు రద్దు చేయబడింది లేదా సమయానికి పూర్తి కాలేదు.';

  @override
  String get paymentFailed => 'చెల్లింపు విఫలమైంది';

  @override
  String get externalWalletSelected => 'బాహ్య వాలెట్ ఎంచుకోబడింది';

  @override
  String get getInTouch => 'సంప్రదింపులో ఉండండి';

  @override
  String get contactUsDescription =>
      'మేము సహాయం చేయడానికి ఇక్కడ ఉన్నాము! ఎప్పుడైనా మమ్మల్ని సంప్రదించండి మరియు వీలైనంత త్వరగా మేము మీకు తిరిగి వస్తాము.';

  @override
  String get contactInformation => 'సంప్రదింపు సమాచారం';

  @override
  String get officeAddress => 'కార్యాలయ చిరునామా';

  @override
  String get pashuParivarHeadquarters =>
      'పశు పరివార్ ప్రధాన కార్యాలయం\nభోపాల్, మధ్య ప్రదేశ్\nభారతదేశం';

  @override
  String get sendUsAMessage => 'మాకు సందేశం పంపండి';

  @override
  String get fullName => 'పూర్తి పేరు';

  @override
  String get enterYourFullName => 'మీ పూర్తి పేరును నమోదు చేయండి';

  @override
  String get enterYourEmailAddress => 'మీ ఇమెయిల్ చిరునామాను నమోదు చేయండి';

  @override
  String get message => 'సందేశం';

  @override
  String get tellUsHowWeCanHelp => 'మేము మీకు ఎలా సహాయం చేయగలమో చెప్పండి...';

  @override
  String get sendingMessage => 'సందేశం పంపుతోంది...';

  @override
  String get sendMessage => 'సందేశం పంపండి';

  @override
  String get responseTimeNote =>
      'మేము సాధారణంగా వ్యాపార దినాలలో 24 గంటలలోపు ప్రతిస్పందిస్తాము.';

  @override
  String get followUs => 'మమ్మల్ని అనుసరించండి';

  @override
  String get stayUpdatedWithNews =>
      'మా తాజా వార్తలు మరియు అప్‌డేట్‌లతో అప్‌డేట్‌గా ఉండండి';

  @override
  String get facebook => 'ఫేస్‌బుక్';

  @override
  String get instagram => 'ఇన్‌స్టాగ్రామ్';

  @override
  String get twitter => 'ట్విట్టర్';

  @override
  String get youtube => 'యూట్యూబ్';

  @override
  String get copiedToClipboard => 'క్లిప్‌బోర్డ్‌కు కాపీ చేయబడింది!';

  @override
  String get messageSentSuccessfully => 'సందేశం విజయవంతంగా పంపబడింది!';

  @override
  String get thankYouForContacting =>
      'మమ్మల్ని సంప్రదించినందుకు ధన్యవాదాలు. మేము 24 గంటలలోపు మీకు తిరిగి వస్తాము.';

  @override
  String get nameMustBeAtLeast2Characters => 'పేరు కనీసం 2 అక్షరాలు ఉండాలి';

  @override
  String get emailIsRequired => 'ఇమెయిల్ అవసరం';

  @override
  String get pleaseEnterValidEmail =>
      'దయచేసి చెల్లుబాటు అయ్యే ఇమెయిల్ చిరునామాను నమోదు చేయండి';

  @override
  String get messageIsRequired => 'సందేశం అవసరం';

  @override
  String get messageMustBeAtLeast10Characters =>
      'సందేశం కనీసం 10 అక్షరాలు ఉండాలి';

  @override
  String get invest => 'వ్యవసాయ-పశుపాలనలో పెట్టుబడి పెట్టండి';

  @override
  String get total => 'మొత్తం';

  @override
  String get active => 'సక్రియం';

  @override
  String get pending => 'పెండింగ్';

  @override
  String get edit => 'సవరించు';

  @override
  String get delete => 'తొలగించు';

  @override
  String get pendingStatus => 'పెండింగ్';

  @override
  String get failedToLoadListings => 'లిస్టింగ్‌లను లోడ్ చేయడంలో విఫలమైంది';

  @override
  String get noListedAnimals => 'జాబితా చేసిన జంతువులు లేవు';

  @override
  String get noListedAnimalsDescription =>
      'మీరు ఇంకా జంతువులను జాబితా చేయలేదు. మీ మొదటి లిస్టింగ్‌ను జోడించడంతో ప్రారంభించండి!';

  @override
  String get addNewListing => 'కొత్త లిస్టింగ్ జోడించండి';

  @override
  String get deleteListing => 'లిస్టింగ్ తొలగించండి';

  @override
  String deleteConfirmation(String animalName) {
    return 'మీరు నిజంగా \"$animalName\"ని తొలగించాలనుకుంటున్నారా? ఈ చర్య రద్దు చేయలేము.';
  }

  @override
  String deleteSuccessMessage(String animalName) {
    return '$animalName విజయవంతంగా తొలగించబడింది';
  }

  @override
  String get withdrawFromWallet => 'వాలెట్ నుండి ఉపసంహరించండి';

  @override
  String get availableBalance => 'అందుబాటులో ఉన్న బ్యాలెన్స్';

  @override
  String get withdrawalEligible => 'ఉపసంహరణ అర్హత';

  @override
  String get withdrawalRequirements => 'ఉపసంహరణ అవసరాలు';

  @override
  String youHaveSpentAndCanWithdraw(String counter) {
    return 'మీరు ₹$counter ఖర్చు చేసారు మరియు నిధులను ఉపసంహరించవచ్చు';
  }

  @override
  String spendMoreToEnableWithdrawal(String amount, String counter) {
    return 'ఉపసంహరణను ప్రారంభించడానికి ₹$amount మరింత ఖర్చు చేయండి (ప్రస్తుత: ₹$counter)';
  }

  @override
  String get withdrawalDetails => 'ఉపసంహరణ వివరాలు';

  @override
  String get enterAmountEg => 'మొత్తం నమోదు చేయండి ఉదా. 500';

  @override
  String get enterUpiIdEg => 'UPI ID నమోదు చేయండి (ఉదా. example@upi)';

  @override
  String get enterUpiIdEgPlaceholder => 'UPI ID నమోదు చేయండి ఉదా. example@upi';

  @override
  String get processing => 'ప్రాసెసింగ్...';

  @override
  String withdrawAmount(String amount) {
    return '₹$amount ఉపసంహరించండి';
  }

  @override
  String get withdrawalRequirementsLabel => 'ఉపసంహరణ అవసరాలు:';

  @override
  String get minimumSpendingRequired => '• కనీసం ₹50 ఖర్చు అవసరం';

  @override
  String get walletBalanceRequired => '• వాలెట్ బ్యాలెన్స్ ≥ ₹100 ఉండాలి';

  @override
  String currentSpending(String counter, String status) {
    return '• ప్రస్తుత ఖర్చు: ₹$counter ($status)';
  }

  @override
  String walletBalanceStatus(String balance, String status) {
    return '• వాలెట్ బ్యాలెన్స్: ₹$balance ($status)';
  }

  @override
  String get verified => '✓';

  @override
  String needMoreAmount(String amount) {
    return '₹$amount మరింత అవసరం';
  }

  @override
  String get tipWithdrawProcessingTime =>
      'చిట్కా: ఉపసంహరణలు మీ UPI ఖాతాకు 24-48 గంటలలో ప్రాసెస్ చేయబడతాయి.';

  @override
  String get withdrawalRequestSubmitted => 'ఉపసంహరణ అభ్యర్థన సమర్పించబడింది!';

  @override
  String withdrawalRequestSuccessMessage(String amount) {
    return '₹$amount మీ ఉపసంహరణ అభ్యర్థన విజయవంతంగా సమర్పించబడింది. మీరు 24-48 గంటలలో మీ UPI ఖాతాలో మొత్తాన్ని అందుకుంటారు.';
  }

  @override
  String get failedToLoadData => 'డేటాను లోడ్ చేయడంలో విఫలమైంది';

  @override
  String get amountCannotBeEmpty => 'మొత్తం ఖాళీగా ఉండకూడదు';

  @override
  String amountCannotExceedBalance(String balance) {
    return 'మొత్తం వాలెట్ బ్యాలెన్స్ మించకూడదు (₹$balance)';
  }

  @override
  String get minimumWalletBalanceRequired =>
      'కనీసం ₹100 వాలెట్ బ్యాలెన్స్ అవసరం';

  @override
  String get upiIdCannotBeEmpty => 'UPI ID ఖాళీగా ఉండకూడదు';

  @override
  String get pleaseEnterValidUpiId =>
      'దయచేసి చెల్లుబాటు అయ్యే UPI ID ని నమోదు చేయండి';

  @override
  String get transactionHistory => 'లావాదేవీ చరిత్ర';

  @override
  String get noTransactions => 'లావాదేవీలు లేవు';

  @override
  String get transactionSummary => 'లావాదేవీ సారాంశం';

  @override
  String get totalCredit => 'మొత్తం క్రెడిట్';

  @override
  String get totalDebit => 'మొత్తం డెబిట్';

  @override
  String get successful => 'విజయవంతం';

  @override
  String get today => 'ఈరోజు';

  @override
  String get yesterday => 'నిన్న';

  @override
  String daysAgo(String days) {
    return '$days రోజుల క్రితం';
  }

  @override
  String get paymentId => 'చెల్లింపు ID';

  @override
  String get fullDate => 'పూర్తి తేదీ';

  @override
  String get utrNumber => 'UTR నంబర్';

  @override
  String get failedToLoadTransactions => 'లావాదేవీలను లోడ్ చేయడంలో విఫలమైంది';

  @override
  String get noTransactionsFound => 'లావాదేవీలు కనుగొనబడలేదు';

  @override
  String get transactionHistoryDescription =>
      'మీరు మీ మొదటి లావాదేవీ చేసిన తర్వాత మీ లావాదేవీ చరిత్ర ఇక్కడ కనిపిస్తుంది';

  @override
  String get goBack => 'వెనుకకు వెళ్ళు';

  @override
  String get success => 'విజయవంతం';

  @override
  String get failed => 'విఫలమైంది';

  @override
  String get credit => 'క్రెడిట్';

  @override
  String get debit => 'డెబిట్';

  @override
  String get profileDetails => 'ప్రొఫైల్ వివరాలు';

  @override
  String get address => 'చిరునామా';

  @override
  String get notProvided => 'ఇవ్వలేదు';

  @override
  String get profileDetailsSectionHeader => 'ప్రొఫైల్ వివరాలు';

  @override
  String get editProfileInformation => 'ప్రొఫైల్ సమాచారాన్ని సవరించండి';

  @override
  String get nameCannotBeEmpty => 'పేరు ఖాళీగా ఉండకూడదు';

  @override
  String get nameMinimumCharacters => 'పేరు కనీసం 2 అక్షరాలు ఉండాలి';

  @override
  String get addressCannotBeEmpty => 'చిరునామా ఖాళీగా ఉండకూడదు';

  @override
  String get pleaseEnterCompleteAddress =>
      'దయచేసి పూర్తి చిరునామాను నమోదు చేయండి';

  @override
  String get phoneAndReferralNotChangeable =>
      'గమనిక: ఫోన్ నంబర్ మరియు రిఫరల్ కోడ్ మార్చలేరు. పేరు, ఇమెయిల్ మరియు చిరునామా మాత్రమే అప్డేట్ చేయవచ్చు.';

  @override
  String get updatingProfile => 'ప్రొఫైల్ అప్డేట్ అవుతోంది...';

  @override
  String get updateProfile => 'ప్రొఫైల్ అప్డేట్ చేయండి';

  @override
  String get profileUpdatedSuccessfully =>
      'ప్రొఫైల్ విజయవంతంగా అప్డేట్ అయింది!';

  @override
  String get profileUpdateSuccessMessage =>
      'మీ ప్రొఫైల్ సమాచారం విజయవంతంగా అప్డేట్ చేయబడింది.';

  @override
  String get updateFailed => 'అప్డేట్ విఫలమైంది';

  @override
  String get inviteEarnRewards => 'ఆహ్వానించండి & బహుమతులు గెలుచుకోండి';

  @override
  String get shareReferralDescription =>
      'మీ రెఫరల్ కోడ్‌ను స్నేహితులు మరియు కుటుంబ సభ్యులతో పంచుకోండి మరియు వారు పశు పరివార్‌లో చేరినప్పుడు ప్రత్యేక బహుమతులు పొందండి';

  @override
  String get yourReferralCode => 'మీ రెఫరల్ కోడ్';

  @override
  String get shareWithFriends => 'స్నేహితులతో పంచుకోండి';

  @override
  String get shareLink => 'లింక్ పంచుకోండి';

  @override
  String get copyLink => 'లింక్ కాపీ చేయండి';

  @override
  String get moreOptions => 'మరిన్ని ఎంపికలు';

  @override
  String get referralBenefits => 'రెఫరల్ ప్రయోజనాలు';

  @override
  String get earnRewards => 'బహుమతులు గెలుచుకోండి';

  @override
  String get earnRewardsDescription =>
      'మీ స్నేహితులు మీ కోడ్ ఉపయోగించి చేరినప్పుడు ప్రత్యేక బహుమతులు పొందండి';

  @override
  String get helpFriends => 'స్నేహితులకు సహాయం చేయండి';

  @override
  String get helpFriendsDescription =>
      'మీ స్నేహితులు కూడా సైన్ అప్ చేసినప్పుడు ప్రత్యేక బోనస్‌లు పొందుతారు';

  @override
  String get unlimitedSharing => 'అపరిమిత భాగస్వామ్యం';

  @override
  String get unlimitedSharingDescription =>
      'మీ కోడ్‌ను ఎవరితోనైనా ఎన్నిసార్లు వేండుమనుకున్నా పంచుకోండి';

  @override
  String get trackProgress => 'పురోగతిని ట్రాక్ చేయండి';

  @override
  String get trackProgressDescription =>
      'మీ ప్రొఫైల్‌లో మీ రెఫరల్ విజయం మరియు బహుమతులను పర్యవేక్షించండి';

  @override
  String get howItWorks => 'ఇది ఎలా పనిచేస్తుంది';

  @override
  String get shareYourCode => 'మీ కోడ్ పంచుకోండి';

  @override
  String get shareYourCodeDescription =>
      'మీ రెఫరల్ కోడ్ లేదా లింక్‌ను స్నేహితులు మరియు కుటుంబ సభ్యులకు పంపండి';

  @override
  String get friendSignsUp => 'స్నేహితుడు సైన్ అప్ చేస్తాడు';

  @override
  String get friendSignsUpDescription =>
      'వారు మీ రెఫరల్ కోడ్ ఉపయోగించి ఖాతా సృష్టిస్తారు';

  @override
  String get bothGetRewards => 'ఇద్దరూ బహుమతులు పొందుతారు';

  @override
  String get bothGetRewardsDescription =>
      'మీరు మరియు మీ స్నేహితుడు ప్రత్యేక బోనస్‌లు అందుకుంటారు';

  @override
  String get linkCopiedToClipboard => 'లింక్ క్లిప్‌బోర్డ్‌కు కాపీ చేయబడింది!';

  @override
  String get codeCopiedToClipboard => 'కోడ్ క్లిప్‌బోర్డ్‌కు కాపీ చేయబడింది!';

  @override
  String get referralHelp => 'రెఫరల్ సహాయం';

  @override
  String get referralHelpContent =>
      '• మీ ప్రత్యేక రెఫరల్ కోడ్‌ను స్నేహితులతో పంచుకోండి\n• మీరు మరియు మీ స్నేహితుడు ఇద్దరూ బహుమతులు పొందుతారు\n• మీరు ఎంతమంది స్నేహితులను రెఫర్ చేసినా పరిమితి లేదు\n• మీ ప్రొఫైల్‌లో మీ రెఫరల్‌లను ట్రాక్ చేయండి\n• బహుమతులు స్వయంచాలకంగా క్రెడిట్ చేయబడతాయి';

  @override
  String shareMessage(String referralCode, String referralUrl) {
    return '🐄 పశు పరివార్‌లో నాతో చేరండి - భారతదేశపు విశ్వసనీయ పశువుల మార్కెట్‌ప్లేస్! 🐄\n\nనాణ్యమైన జంతువులను కనుగొనండి, ధృవీకరించబడిన విక్రేతలతో కనెక్ట్ అవ్వండి మరియు ప్రీమియం ఫీచర్‌లతో మీ పశువుల వ్యాపారాన్ని పెంచుకోండి.\n\n✨ నా రెఫరల్ కోడ్ ఉపయోగించండి: $referralCode\n🎁 మా ఇద్దరికీ ప్రత్యేక బహుమతులు పొందండి!\n\nఇప్పుడే డౌన్‌లోడ్ చేయండి: $referralUrl\n\n#పశుపరివార్ #పశువులు #వ్యవసాయం #జంతువుల వ్యాపారం';
  }

  @override
  String get termsOfService => 'సేవా నియమాలు';

  @override
  String get privacyPolicy => 'గోప్యతా విధానం';

  @override
  String get lastUpdated => 'చివరిసారి నవీకరించబడింది: జూలై 27, 2025';

  @override
  String get acceptanceOfTerms => 'నియమాల అంగీకారం';

  @override
  String get acceptanceOfTermsContent =>
      'పశు పరివార్‌ను యాక్సెస్ చేసి ఉపయోగించడం ద్వారా, మీరు ఈ ఒప్పందం యొక్క నియమాలు మరియు నిబంధనలకు కట్టుబడి ఉండడానికి అంగీకరిస్తారు.';

  @override
  String get useLicense => 'వాడుక లైసెన్స్';

  @override
  String get useLicenseContent =>
      'వ్యక్తిగత, వాణిజ్యేతర తాత్కాలిక వీక్షణ కోసం మాత్రమే పరికరానికి పశు పరివార్ యొక్క ఒక కాపీని తాత్కాలికంగా డౌన్‌లోడ్ చేయడానికి అనుమతి ఇవ్వబడింది.';

  @override
  String get userResponsibilities => 'వినియోగదారు బాధ్యతలు';

  @override
  String get userResponsibilitiesContent =>
      '• లిస్టింగ్‌లను సృష్టించేటప్పుడు ఖచ్చితమైన సమాచారాన్ని అందించండి\n• ఇతర వినియోగదారులను గౌరవించండి మరియు వృత్తిపరమైన ప్రవర్తనను కొనసాగించండి\n• వర్తించే అన్ని చట్టాలు మరియు నిబంధనలకు కట్టుబడండి\n• మోసపూరిత కార్యకలాపాలకు ప్లాట్‌ఫారమ్‌ను దుర్వినియోగం చేయవద్దు';

  @override
  String get platformServices => 'ప్లాట్‌ఫారమ్ సేవలు';

  @override
  String get platformServicesContent =>
      'పశు పరివార్ పశువుల వ్యాపారం కోసం ప్లాట్‌ఫారమ్‌ను అందిస్తుంది, కొనుగోలుదారులు మరియు అమ్మకందారులను కనెక్ట్ చేస్తుంది. మేము లావాదేవీలను సులభతరం చేస్తాము కానీ కొనుగోలు/అమ్మకం ప్రక్రియలో ప్రత్యక్షంగా పాల్గొనము.';

  @override
  String get accountSecurity => 'ఖాతా భద్రత';

  @override
  String get accountSecurityContent =>
      'వారి ఖాతా సమాచారం మరియు పాస్‌వర్డ్ యొక్క గోప్యతను కొనసాగించడం వినియోగదారుల బాధ్యత. ఏదైనా అనధికార వినియోగం గురించి వెంటనే మాకు తెలియజేయండి.';

  @override
  String get paymentTerms => 'చెల్లింపు నియమాలు';

  @override
  String get paymentTermsContent =>
      'ప్రీమియం సేవలకు అన్ని చెల్లింపులు సురక్షితంగా ప్రాసెస్ చేయబడతాయి. సబ్‌స్క్రిప్షన్ ఫీజులు వేరుగా పేర్కొనకపోతే వాపసు చేయలేనివి.';

  @override
  String get contentGuidelines => 'కంటెంట్ మార్గదర్శకాలు';

  @override
  String get contentGuidelinesContent =>
      'అప్‌లోడ్ చేయబడిన అన్ని కంటెంట్ తగినది, ఖచ్చితమైనది మరియు మా కమ్యూనిటీ మార్గదర్శకాలకు అనుగుణంగా ఉండాలి. అనుచితమైన కంటెంట్‌ను తొలగించే హక్కును మేము కలిగి ఉన్నాము.';

  @override
  String get limitationOfLiability => 'బాధ్యత పరిమితి';

  @override
  String get limitationOfLiabilityContent =>
      'మీ సేవా వినియోగం వల్ల కలిగే ఏదైనా పరోక్ష, యాదృచ్ఛిక, ప్రత్యేక, పర్యవసాన లేదా శిక్షాత్మక నష్టాలకు పశు పరివార్ బాధ్యత వహించదు.';

  @override
  String get modifications => 'మార్పులు';

  @override
  String get modificationsContent =>
      'ఈ నియమాలను ఎప్పుడైనా సవరించే హక్కును మేము కలిగి ఉన్నాము. ముఖ్యమైన మార్పుల గురించి వినియోగదారులకు తెలియజేయబడుతుంది.';

  @override
  String get contactInformationContent =>
      'ఈ సేవా నియమాల గురించి ప్రశ్నలకు, దయచేసి మాను support@pashuparivar.com వద్ద సంప్రదించండి';

  @override
  String get informationWeCollect => 'మేము సేకరించే సమాచారం';

  @override
  String get informationWeCollectContent =>
      '• వ్యక్తిగత సమాచారం: పేరు, ఫోన్ నంబర్, ఇమెయిల్ చిరునామా\n• ప్రొఫైల్ సమాచారం: చిరునామా, ప్రాధాన్యతలు, వినియోగ డేటా\n• పరికర సమాచారం: IP చిరునామా, బ్రౌజర్ రకం, ఆపరేటింగ్ సిస్టమ్\n• వినియోగ డేటా: యాప్ ఇంటరాక్షన్లు, ఉపయోగించిన ఫీచర్లు, సెషన్ వ్యవధి';

  @override
  String get howWeUseYourInformation => 'మేము మీ సమాచారాన్ని ఎలా ఉపయోగిస్తాము';

  @override
  String get howWeUseYourInformationContent =>
      'సేకరించిన సమాచారాన్ని మేము ఉపయోగిస్తాము:\n• మా సేవలను అందించడానికి మరియు నిర్వహించడానికి\n• లావాదేవీలను ప్రాసెస్ చేసి నోటిఫికేషన్లు పంపడానికి\n• వినియోగదారు అనుభవం మరియు యాప్ కార్యాచరణను మెరుగుపరచడానికి\n• అప్‌డేట్లు మరియు ఆఫర్‌ల గురించి మీతో కమ్యూనికేట్ చేయడానికి';

  @override
  String get informationSharing => 'సమాచార భాగస్వామ్యం';

  @override
  String get informationSharingContent =>
      'మేము మీ సమాచారాన్ని పంచుకోవచ్చు:\n• ఇతర వినియోగదారులతో (లిస్టింగ్‌లలో ప్రొఫైల్ సమాచారం)\n• మా కార్యకలాపాలకు సహాయపడే సేవా ప్రదాతలతో\n• చట్టం ద్వారా అవసరమైనప్పుడు లేదా మా హక్కులను రక్షించడానికి\n• నిర్దిష్ట ప్రయోజనాల కోసం మీ అనుమతితో';

  @override
  String get dataSecurity => 'డేటా భద్రత';

  @override
  String get dataSecurityContent =>
      'అనధికార యాక్సెస్, మార్పు, బహిర్గతం లేదా నాశనానికి వ్యతిరేకంగా మీ వ్యక్తిగత సమాచారాన్ని రక్షించడానికి మేము తగిన భద్రతా చర్యలను అమలు చేస్తాము.';

  @override
  String get dataRetention => 'డేటా నిలుపుదల';

  @override
  String get dataRetentionContent =>
      'ఈ విధానంలో పేర్కొన్న ప్రయోజనాలకు అవసరమైనంత కాలం లేదా చట్టం ప్రకారం అవసరమైనంత కాలం మాత్రమే మేము మీ వ్యక్తిగత సమాచారాన్ని కలిగి ఉంటాము.';

  @override
  String get yourRights => 'మీ హక్కులు';

  @override
  String get yourRightsContent =>
      'మీకు హక్కు ఉంది:\n• మీ వ్యక్తిగత సమాచారాన్ని యాక్సెస్ చేయడానికి\n• తప్పుడు సమాచారాన్ని సరిదిద్దడానికి\n• మీ ఖాతా మరియు డేటాను తొలగించడానికి\n• మార్కెటింగ్ కమ్యూనికేషన్‌ల నుండి వైదొలగడానికి';

  @override
  String get cookiesAndTracking => 'కుకీలు మరియు ట్రాకింగ్';

  @override
  String get cookiesAndTrackingContent =>
      'మీ అనుభవాన్ని మెరుగుపరచడానికి, వినియోగ నమూనాలను విశ్లేషించడానికి మరియు వ్యక్తిగతీకరించిన కంటెంట్‌ను అందించడానికి మేము కుకీలు మరియు సారూప్య సాంకేతికతలను ఉపయోగిస్తాము.';

  @override
  String get thirdPartyServices => 'మూడవ పక్షం సేవలు';

  @override
  String get thirdPartyServicesContent =>
      'మా యాప్‌లో మూడవ పక్షం సేవలకు లింక్‌లు ఉండవచ్చు. వారి గోప్యతా పద్ధతులకు మేము బాధ్యత వహించము.';

  @override
  String get childrensPrivacy => 'పిల్లల గోప్యత';

  @override
  String get childrensPrivacyContent =>
      'మా సేవ 13 సంవత్సరాలలోపు పిల్లల కోసం ఉద్దేశించబడలేదు. 13 సంవత్సరాలలోపు పిల్లల నుండి వ్యక్తిగత సమాచారాన్ని మేము ఉద్దేశపూర్వకంగా సేకరించము.';

  @override
  String get changesToThisPolicy => 'ఈ విధానంలో మార్పులు';

  @override
  String get changesToThisPolicyContent =>
      'మేము ఎప్పటికప్పుడు ఈ గోప్యతా విధానాన్ని అప్‌డేట్ చేయవచ్చు. ఈ పేజీలో కొత్త విధానాన్ని పోస్ట్ చేయడం ద్వారా ఏదైనా మార్పుల గురించి మేము మీకు తెలియజేస్తాము.';

  @override
  String get privacyContactContent =>
      'ఈ గోప్యతా విధానం గురించి మీకు ప్రశ్నలు ఉంటే, దయచేసి మమ్మల్ని సంప్రదించండి:\nఇమెయిల్: privacy@pashuparivar.com\nఫోన్: +91-XXXXXXXXXX';
}
