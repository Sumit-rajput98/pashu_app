// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Kannada (`kn`).
class AppLocalizationsKn extends AppLocalizations {
  AppLocalizationsKn([String locale = 'kn']) : super(locale);

  @override
  String get welcome => 'ಪಶು ಕುಟುಂಬಕ್ಕೆ ಸ್ವಾಗತ';

  @override
  String get locationPermissionTitle => 'ಸ್ಥಳ ಅನುಮತಿ';

  @override
  String get locationPermissionMessage =>
      'ಆಪ್‌ಗೆ ನಿಮ್ಮ ಸ್ಥಳದ ಪ್ರವೇಶ ಬೇಕಾಗಿರುತ್ತದೆ.';

  @override
  String get permissionDenied => 'ಅನುಮತಿ ನಿರಾಕರಿಸಲಾಗಿದೆ';

  @override
  String get permissionRetryMessage =>
      'ಸ್ಥಳದ ಅನುಮತಿ ಅಗತ್ಯವಿದೆ. ನೀವು ಮತ್ತೆ ಪ್ರಯತ್ನಿಸುತ್ತೀರಾ?';

  @override
  String get yes => 'ಹೌದು';

  @override
  String get no => 'ಇಲ್ಲ';

  @override
  String get hi => 'ಹಲೋ';

  @override
  String get newAnimal => 'ಹೊಸ ಪಶು';

  @override
  String get newBuyers => 'ಹೊಸ ಖರೀದಿದಾರರು';

  @override
  String get buyAnimal => 'ಪಶು ಖರೀದಿಸಿ';

  @override
  String get sellAnimal => 'ಪಶು ಮಾರಾಟ ಮಾಡಿ';

  @override
  String get otherServices => 'ಇತರ ಸೇವೆಗಳು';

  @override
  String get knowMore => 'ಹೆಚ್ಚಿನ ಮಾಹಿತಿಯನ್ನು ತಿಳಿದುಕೊಳ್ಳಿ';

  @override
  String get clicklive => 'ಲೈವ್ ವೀಕ್ಷಿಸಿ';

  @override
  String get insurance => 'ವಿಮೆ';

  @override
  String get health => 'ಆರೋಗ್ಯ';

  @override
  String get liverace => 'ಲೈವ್ ರೇಸ್';

  @override
  String get feed => 'ಮೇವು';

  @override
  String get getLocation => 'ಸ್ಥಳವನ್ನು ಪಡೆಯಿರಿ';

  @override
  String get getLocationMessage => 'ನಿಮ್ಮ ಪಶುವಿಗೆ ಸ್ಥಳವನ್ನು ಪಡೆಯಿರಿ 📍';

  @override
  String get comingSoon => 'త్వరలో వస్తుంది';

  @override
  String get firstUsers => 'ಮೊದಲ 10,000 ಬಳಕೆದಾರರಿಗೆ ಸಿಗುತ್ತದೆ';

  @override
  String get referralBonusOnly => 'ರೆಫರಲ್ ಬೋನಸ್ – ಕೇವಲ';

  @override
  String slotsLeft(Object slot) {
    return 'ಸ್ಲಾಟ್‌ಗಳು ಉಳಿದಿವೆ!';
  }

  @override
  String get applyNow => 'ಈಗಲೇ ಅರ್ಜಿ ಹಾಕಿ';

  @override
  String get pashuLoan => 'ಪಶು ಸಾಲ';

  @override
  String get pashuInsurance => 'ಪಶು ವಿಮೆ';

  @override
  String get investInFarming => 'ಕೃಷಿಯಲ್ಲಿ ಹೂಡಿಕೆ ಮಾಡಿ';

  @override
  String get growWealth => 'ಪ್ರಕೃತಿಯೊಂದಿಗೆ ನಿಮ್ಮ ಸಂಪತ್ತನ್ನು ಬೆಳೆಸಿಕೊಳ್ಳಿ';

  @override
  String get startInvesting => 'ಹೂಡಿಕೆ ಆರಂಭಿಸಿ';

  @override
  String get editProfile => 'ಪ್ರೊಫೈಲ್ ಸಂಪಾದಿಸಿ';

  @override
  String get animalHistory => 'ಪ್ರಾಣಿ ಪಟ್ಟಿ ಇತಿಹಾಸ';

  @override
  String get referralCode => 'ರೆಫರಲ್ ಕೋಡ್';

  @override
  String get logout => 'ಲಾಗೌಟ್';

  @override
  String get yourListedPashu => 'ನಿಮ್ಮ ಪಟ್ಟಿ ಮಾಡಿದ ಪಶುಗಳು';

  @override
  String get termsPrivacy => 'ನಿಯಮಗಳು ಮತ್ತು ಗೌಪ್ಯತೆ';

  @override
  String get contactUs => 'ನಮ್ಮನ್ನು ಸಂಪರ್ಕಿಸಿ';

  @override
  String get account => 'ಖಾತೆ';

  @override
  String get soldOutPashuHistory => 'ಮಾರಾಟವಾದ ಪಶು ಇತಿಹಾಸ';

  @override
  String get walletBalance => 'ವಾಲೆಟ್ ಬ್ಯಾಲೆನ್ಸ್';

  @override
  String get addAmountInWallet => 'ವಾಲೆಟ್‌ಗೆ ಮೊತ್ತ ಸೇರಿಸಿ';

  @override
  String get myTransaction => 'ನನ್ನ ವಹಿವಾಟು';

  @override
  String get addMoneyToWallet => 'ನಿಮ್ಮ ವಾಲೆಟ್‌ಗೆ ಹಣ ಸೇರಿಸಿ';

  @override
  String get enterAmount => 'ಮೊತ್ತ ನಮೂದಿಸಿ';

  @override
  String get enterAmountExample => 'ಉದಾಹರಣೆ: 500 ನಮೂದಿಸಿ';

  @override
  String get add => 'ಸೇರಿಸಿ';

  @override
  String get walletTip =>
      'ಸಲಹೆ: ನಿಮ್ಮ ವಾಲೆಟ್ ಅನ್ನು ತಕ್ಷಣ ಸಂಪರ್ಕ ವಿವರಗಳನ್ನು ನೋಡಲು ಬಳಸಬಹುದು.';

  @override
  String get getVerifiedPashu => 'ನಿಮ್ಮ ಪಶುವನ್ನು ಪ್ರಮಾಣೀಕರಿಸಿ';

  @override
  String get withdrawBalance => 'ಬ್ಯಾಲೆನ್ಸ್ ಹಿಂಪಡೆಯಿರಿ';

  @override
  String get signIn => 'ಸೈನ್ ಇನ್';

  @override
  String get enterPhoneNumberToContinue =>
      'ಮುಂದುವರಿಸಲು ನಿಮ್ಮ ಫೋನ್ ಸಂಖ್ಯೆ ನಮೂದಿಸಿ';

  @override
  String get phoneNumber => 'ದೂರವಾಣಿ ಸಂಖ್ಯೆ';

  @override
  String get enterPhoneNumber => 'ಫೋನ್ ಸಂಖ್ಯೆ ನಮೂದಿಸಿ';

  @override
  String get sendOTP => 'ಒಟಿಪಿ ಕಳುಹಿಸಿ';

  @override
  String get or => 'ಅಥವಾ';

  @override
  String get dontHaveAccount => 'ಖಾತೆ ಇಲ್ಲವೇ? ಈಗಲೇ ನೋಂದಾಯಿಸಿ';

  @override
  String get phoneNumberRequired => 'ಫೋನ್ ಸಂಖ್ಯೆ ಅಗತ್ಯವಿದೆ';

  @override
  String get enterValidPhoneNumber =>
      'ಮಾನ್ಯವಾದ 10 ಅಂಕಿಯ ಭಾರತೀಯ ಫೋನ್ ಸಂಖ್ಯೆ ನಮೂದಿಸಿ';

  @override
  String otpSentTo(Object phoneNumber) {
    return 'ಒಟಿಪಿ +91 $phoneNumber ಗೆ ಕಳುಹಿಸಲಾಗಿದೆ';
  }

  @override
  String get register => 'ನೋಂದಾಯಿಸಿ';

  @override
  String get login => 'ಲಾಗಿನ್';

  @override
  String get registerNow => 'ಈಗಲೇ ನೋಂದಾಯಿಸಿ';

  @override
  String get enterYourName => 'ನಿಮ್ಮ ಹೆಸರು ನಮೂದಿಸಿ';

  @override
  String get enterReferralCode => 'ರೆಫರಲ್ ಕೋಡ್ ನಮೂದಿಸಿ (ಐಚ್ಛಿಕ)';

  @override
  String get getOTP => 'ಒಟಿಪಿ ಪಡೆಯಿರಿ';

  @override
  String get alreadyHaveAccount => 'ಈಗಾಗಲೇ ಖಾತೆ ಇದೆಯೇ? ಸೈನ್ ಇನ್ ಮಾಡಿ';

  @override
  String get optional => 'ಐಚ್ಛಿಕ';

  @override
  String get nameIsRequired => 'ಹೆಸರು ಅಗತ್ಯವಿದೆ';

  @override
  String get nameMinLength => 'ಹೆಸರು ಕನಿಷ್ಠ 2 ಅಕ್ಷರಗಳಷ್ಟು ಇರಬೇಕು';

  @override
  String get failedToSendOTP =>
      'ಒಟಿಪಿ ಕಳುಹಿಸುವಲ್ಲಿ ವಿಫಲವಾಗಿದೆ. ದಯವಿಟ್ಟು ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.';

  @override
  String get enterOTP => 'ಒಟಿಪಿ ನಮೂದಿಸಿ';

  @override
  String otpSentMessage(Object phoneNumber) {
    return 'ನಾವು +91 $phoneNumber ಗೆ 6 ಅಂಕಿಯ ಒಟಿಪಿ ಕಳುಹಿಸಿದ್ದೇವೆ';
  }

  @override
  String get enterComplete6DigitOTP => 'ದಯವಿಟ್ಟು ಸಂಪೂರ್ಣ 6 ಅಂಕಿಯ ಒಟಿಪಿ ನಮೂದಿಸಿ';

  @override
  String get successfulLogin => 'ಯಶಸ್ವಿ ಲಾಗಿನ್';

  @override
  String get didntReceiveOTP => 'ಒಟಿಪಿ ಸಿಗಲಿಲ್ಲವೇ?';

  @override
  String resendIn(Object seconds) {
    return '$seconds ಸೆಕೆಂಡುಗಳಲ್ಲಿ ಮರುಕಳುಹಿಸಿ';
  }

  @override
  String get resendOTP => 'ಒಟಿಪಿ ಮರುಕಳುಹಿಸಿ';

  @override
  String get resending => 'ಮರುಕಳುಹಿಸುತ್ತಿದೆ...';

  @override
  String otpResentTo(Object phoneNumber) {
    return 'ಒಟಿಪಿ +91 $phoneNumber ಗೆ ಮರುಕಳುಹಿಸಲಾಗಿದೆ';
  }

  @override
  String get failedToResendOTP =>
      'ಒಟಿಪಿ ಮರುಕಳುಹಿಸುವಲ್ಲಿ ವಿಫಲವಾಗಿದೆ. ದಯವಿಟ್ಟು ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.';

  @override
  String get homeScreen => 'ಮುಖಪುಟ';

  @override
  String get welcomeToHomeScreen => 'ಮುಖ್ಯ ಪರದೆಗೆ ಸ್ವಾಗತ!';

  @override
  String get newBadge => 'ಹೊಸದು';

  @override
  String get logoutConfirmation =>
      'ನೀವು ಖಚಿತವಾಗಿಯೂ ನಿಮ್ಮ ಖಾತೆಯಿಂದ ಲಾಗ್ ಔಟ್ ಆಗಲು ಬಯಸುತ್ತೀರಾ?';

  @override
  String get cancel => 'ರದ್ದುಗೊಳಿಸಿ';

  @override
  String get failedToLoadProfile => 'ಪ್ರೊಫೈಲ್ ಲೋಡ್ ಮಾಡಲು ವಿಫಲವಾಗಿದೆ';

  @override
  String get uploadPashuImageOne => 'ನಿಮ್ಮ ಪಶು ಚಿತ್ರ ಒಂದು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ';

  @override
  String get selectPictureOne => 'ಚಿತ್ರ ಒಂದು ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get uploadPashuImageTwo => 'ನಿಮ್ಮ ಪಶು ಚಿತ್ರ ಎರಡು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ';

  @override
  String get selectPictureTwo => 'ಚಿತ್ರ ಎರಡು ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get paymentCompletedSuccessfully => 'ಪಾವತಿ ಯಶಸ್ವಿಯಾಗಿ ಪೂರ್ಣಗೊಂಡಿದೆ!';

  @override
  String get paymentVerificationFailed =>
      'ಪಾವತಿ ಪರಿಶೀಲನೆ ವಿಫಲವಾಗಿದೆ. ದಯವಿಟ್ಟು ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.';

  @override
  String get errorVerifyingPayment => 'ಪಾವತಿ ಪರಿಶೀಲಿಸುವಲ್ಲಿ ದೋಷವಾಗಿದೆ';

  @override
  String get insuranceApplication => 'ವಿಮೆ ಅರ್ಜಿ';

  @override
  String get responseReceived => 'ಪ್ರತಿಕ್ರಿಯೆ ದೊರೆತಿದೆ!';

  @override
  String get insuranceThankYouMessage =>
      'ನಿಮ್ಮ ಪಶು ವಿಮೆ ಅರ್ಜಿಯನ್ನು ಸಲ್ಲಿಸಿದಕ್ಕಾಗಿ ಧನ್ಯವಾದಗಳು. ನಮ್ಮ ತಂಡ ಶೀಘ್ರದಲ್ಲೇ ಹೆಚ್ಚಿನ ವಿವರಗಳೊಂದಿಗೆ ನಿಮ್ಮನ್ನು ಸಂಪರ್ಕಿಸುತ್ತದೆ.';

  @override
  String get selectLanguage => 'ಭಾಷೆ ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get ok => 'ಸರಿ';

  @override
  String get appTitle => 'ಪಶು ಕುಟುಂಬ';

  @override
  String get languageShort => 'हि/E/ತ';

  @override
  String get wishlist => 'ವಿಷ್‌ಲಿಸ್ಟ್';

  @override
  String get loanFormTitle => 'ಪಶು ಸಾಲ ಫಾರ್ಮ್';

  @override
  String get loanApplicationHeader => 'ಪಶು ಸಾಲ ಅರ್ಜಿ';

  @override
  String get loanApplicationSubheader =>
      'ನಿಮ್ಮ ಪಶು ಸಾಕಾಣಿಕೆ ಅಗತ್ಯಗಳಿಗೆ ಹಣಕಾಸು ಸಹಾಯವನ್ನು ಪಡೆಯಿರಿ';

  @override
  String get loanApplicationDetails => 'ಸಾಲ ಅರ್ಜಿ ವಿವರಗಳು';

  @override
  String get applicantInformation => 'ಅರ್ಜಿದಾರರ ಮಾಹಿತಿ';

  @override
  String get applicantName => 'ಅರ್ಜಿದಾರರ ಹೆಸರು';

  @override
  String get applicantNameRequired => 'ಅರ್ಜಿದಾರರ ಹೆಸರು ಅಗತ್ಯವಿದೆ';

  @override
  String get applicantAddress => 'ಅರ್ಜಿದಾರರ ವಿಳಾಸ';

  @override
  String get applicantAddressRequired => 'ಅರ್ಜಿದಾರರ ವಿಳಾಸ ಅಗತ್ಯವಿದೆ';

  @override
  String get contactNumber => 'ಸಂಪರ್ಕ ಸಂಖ್ಯೆ';

  @override
  String get contactNumberRequired => 'ಸಂಪರ್ಕ ಸಂಖ್ಯೆ ಅಗತ್ಯವಿದೆ';

  @override
  String get contactNumberInvalid =>
      'ದಯವಿಟ್ಟು ಮಾನ್ಯ ಸಂಪರ್ಕ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ';

  @override
  String get emailAddress => 'ಇಮೇಲ್ ವಿಳಾಸ';

  @override
  String get emailAddressRequired => 'ಇಮೇಲ್ ವಿಳಾಸ ಅಗತ್ಯವಿದೆ';

  @override
  String get emailAddressInvalid => 'ದಯವಿಟ್ಟು ಮಾನ್ಯ ಇಮೇಲ್ ವಿಳಾಸವನ್ನು ನಮೂದಿಸಿ';

  @override
  String get loanInformation => 'ಸಾಲ ಮಾಹಿತಿ';

  @override
  String get loanAmount => 'ಸಾಲದ ಮೊತ್ತ (₹)';

  @override
  String get loanAmountRequired => 'ಸಾಲದ ಮೊತ್ತ ಅಗತ್ಯವಿದೆ';

  @override
  String get loanAmountInvalid => 'ದಯವಿಟ್ಟು ಮಾನ್ಯ ಸಾಲದ ಮೊತ್ತವನ್ನು ನಮೂದಿಸಿ';

  @override
  String get repaymentPeriod => 'ಪಾವತಿ ಅವಧಿ';

  @override
  String get repaymentPeriodRequired => 'ಪಾವತಿ ಅವಧಿ ಅಗತ್ಯವಿದೆ';

  @override
  String get incomeSource => 'ಆದಾಯ ಮೂಲ';

  @override
  String get incomeSourceRequired => 'ಆದಾಯ ಮೂಲ ಅಗತ್ಯವಿದೆ';

  @override
  String get purposeOfLoan => 'ಸಾಲದ ಉದ್ದೇಶ';

  @override
  String get purposeOfLoanRequired => 'ಸಾಲದ ಉದ್ದೇಶ ಅಗತ್ಯವಿದೆ';

  @override
  String get additionalInformation => 'ಹೆಚ್ಚುವರಿ ಮಾಹಿತಿ';

  @override
  String get additionalRemarks => 'ಹೆಚ್ಚುವರಿ ಟಿಪ್ಪಣಿ';

  @override
  String get additionalRemarksRequired => 'ಹೆಚ್ಚುವರಿ ಟಿಪ್ಪಣಿ ಅಗತ್ಯವಿದೆ';

  @override
  String get submittingForm => 'ಫಾರ್ಮ್ ಸಲ್ಲಿಸಲಾಗುತ್ತಿದೆ...';

  @override
  String get submitForm => 'ಫಾರ್ಮ್ ಸಲ್ಲಿಸಿ';

  @override
  String get loanTermsNote =>
      'ಈ ಫಾರ್ಮ್ ಅನ್ನು ಸಲ್ಲಿಸುವ ಮೂಲಕ, ನೀವು ನಮ್ಮ ಸಾಲ ನಿಯಮಗಳು ಮತ್ತು ಷರತ್ತುಗಳನ್ನು ಒಪ್ಪಿಕೊಳ್ಳುತ್ತೀರಿ. ನಮ್ಮ ತಂಡ ನಿಮ್ಮ ಅರ್ಜಿಯನ್ನು ಪರಿಶೀಲಿಸಿ 3-5 ವ್ಯವಹಾರ ದಿನಗಳಲ್ಲಿ ಸಾಲ ಅನುಮೋದನೆ ಸ್ಥಿತಿಯನ್ನು ಸಂಪರ್ಕಿಸುತ್ತದೆ.';

  @override
  String get allFieldsRequired => 'ಎಲ್ಲಾ ಫೀಲ್ಡ್‌ಗಳು ಅಗತ್ಯವಿದೆ';

  @override
  String get animalInformation => 'ಪ್ರಾಣಿಯ ಮಾಹಿತಿ';

  @override
  String get animalAgeInvalid => 'ದಯವಿಟ್ಟು ಮಾನ್ಯ ಪಶು ವಯಸ್ಸನ್ನು ನಮೂದಿಸಿ';

  @override
  String get animalWeightInvalid => 'ದಯವಿಟ್ಟು ಮಾನ್ಯ ಪಶು ತೂಕವನ್ನು ನಮೂದಿಸಿ';

  @override
  String get allowLocationAccess => 'ಸ್ಥಳ ಪ್ರವೇಶವನ್ನು ಅನುಮತಿಸಿ';

  @override
  String get locationDescription =>
      'ನಿಮ್ಮ ಪ್ರದೇಶದ ಹತ್ತಿರದ ಪಶುಗಳು, ಈವೆಂಟ್‌ಗಳು ಮತ್ತು ವೈಯಕ್ತಿಕ ವಿಷಯವನ್ನು ತೋರಿಸಲು ನಿಮ್ಮ ಸ್ಥಳವನ್ನು ಅಗತ್ಯವಿದೆ.';

  @override
  String get locationPrivacyNote =>
      'ನಿಮ್ಮ ಸ್ಥಳದ ಡೇಟಾ ಸುರಕ್ಷಿತವಾಗಿದೆ ಮತ್ತು ನಿಮ್ಮ ಅನುಭವವನ್ನು ಹೆಚ್ಚಿಸಲು ಮಾತ್ರ ಬಳಸಲಾಗುತ್ತದೆ.';

  @override
  String get liveRaces => 'ಲೈವ್ ರೇಸ್';

  @override
  String get viewLive => 'ಲೈವ್ ನೋಡಿ';

  @override
  String get animalInsurance => 'ಪಶು ವಿಮೆ';

  @override
  String get insuranceFormTitle => 'ಪಶು ವಿಮೆ ಫಾರ್ಮ್';

  @override
  String get insuranceApplicationHeader => 'ಪಶು ವಿಮೆ ಅರ್ಜಿ';

  @override
  String get insuranceApplicationSubheader =>
      'ನಿಮ್ಮ ಪಶು ವಿಮೆ ಅಗತ್ಯಗಳಿಗೆ ಹಣಕಾಸು ಸಹಾಯವನ್ನು ಪಡೆಯಿರಿ';

  @override
  String get insuranceApplicationDetails => 'ವಿಮೆ ಅರ್ಜಿ ವಿವರಗಳು';

  @override
  String get ownerInformation => 'ಮಾಲೀಕರ ಮಾಹಿತಿ';

  @override
  String get ownerName => 'ಮಾಲೀಕರ ಹೆಸರು';

  @override
  String get ownerNameRequired => 'ಮಾಲೀಕರ ಹೆಸರು ಅಗತ್ಯವಿದೆ';

  @override
  String get ownerAddress => 'ಮಾಲೀಕರ ವಿಳಾಸ';

  @override
  String get ownerAddressRequired => 'ಮಾಲೀಕರ ವಿಳಾಸ ಅಗತ್ಯವಿದೆ';

  @override
  String get animalType => 'ಪಶು ಪ್ರಕಾರ';

  @override
  String get animalTypeRequired => 'ಪಶು ಪ್ರಕಾರ ಅಗತ್ಯವಿದೆ';

  @override
  String get animalBreed => 'ಪಶು ಜಾತಿ';

  @override
  String get animalBreedRequired => 'ಪಶು ಜಾತಿ ಅಗತ್ಯವಿದೆ';

  @override
  String get animalAge => 'ಪಶು ವಯಸ್ಸು';

  @override
  String get animalAgeRequired => 'ಪಶು ವಯಸ್ಸು ಅಗತ್ಯವಿದೆ';

  @override
  String get animalColor => 'ಪಶು ಬಣ್ಣ';

  @override
  String get animalColorRequired => 'ಪಶು ಬಣ್ಣ ಅಗತ್ಯವಿದೆ';

  @override
  String get animalWeight => 'ಪಶು ತೂಕ';

  @override
  String get animalWeightRequired => 'ಪಶು ತೂಕ ಅಗತ್ಯವಿದೆ';

  @override
  String get healthStatus => 'ಆರೋಗ್ಯ ಸ್ಥಿತಿ';

  @override
  String get healthStatusRequired => 'ಆರೋಗ್ಯ ಸ್ಥಿತಿ ಅಗತ್ಯವಿದೆ';

  @override
  String get insuranceTermsNote =>
      'ಈ ಫಾರ್ಮ್ ಅನ್ನು ಸಲ್ಲಿಸುವ ಮೂಲಕ, ನೀವು ನಮ್ಮ ವಿಮೆ ನಿಯಮಗಳು ಮತ್ತು ಷರತ್ತುಗಳನ್ನು ಒಪ್ಪಿಕೊಳ್ಳುತ್ತೀರಿ. ನಮ್ಮ ತಂಡ ನಿಮ್ಮ ಅರ್ಜಿಯನ್ನು ಪರಿಶೀಲಿಸಿ 3-5 ವ್ಯವಹಾರ ದಿನಗಳಲ್ಲಿ ವಿಮೆ ಅನುಮೋದನೆ ಸ್ಥಿತಿಯನ್ನು ಸಂಪರ್ಕಿಸುತ್ತದೆ.';

  @override
  String get liveRaceTitle => 'ಲೈವ್ ರೇಸ್';

  @override
  String get liveRaceHeader => 'ಲೈವ್ ರೇಸ್';

  @override
  String get chooseRaceCategory => 'ನಿಮ್ಮ ರೇಸ್ ವರ್ಗವನ್ನು ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get raceExperienceSubheader =>
      'ಪಾರಂಪರಿಕ ಪ್ರಾಣಿಗಳ ಓಟದ ರೋಮಾಂಚನವನ್ನು ಅನುಭವಿಸಿ';

  @override
  String get raceCategoryFallback => 'ರೇಸ್ ವರ್ಗ';

  @override
  String get raceCategoryDetailFallback =>
      'ರೋಚಕ ರೇಸ್‌ಗೆ ಸೇರಿ ಮತ್ತು ಪಾರಂಪರಿಕ ಪ್ರಾಣಿಗಳ ಓಟದ ರೋಮಾಂಚನವನ್ನು ಅನುಭವಿಸಿ';

  @override
  String get liveNow => 'ఇప్పుడు లైవ్';

  @override
  String get tapToJoin => 'ಸೇರಲು ಟ್ಯಾಪ್ ಮಾಡಿ';

  @override
  String get liveBadge => 'ಲೈವ್';

  @override
  String get failedToLoadCategories => 'ವರ್ಗಗಳನ್ನು ಲೋಡ್ ಮಾಡಲು ವಿಫಲವಾಗಿದೆ';

  @override
  String get somethingWentWrong => 'ಏನೋ ತಪ್ಪಾಗಿದೆ';

  @override
  String get retry => 'ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ';

  @override
  String get noLiveRacesAvailable => 'ಯಾವುದೇ ಲೈವ್ ರೇಸ್ ಲಭ್ಯವಿಲ್ಲ';

  @override
  String get checkBackLater => 'ರೋಚಕ ಲೈವ್ ರೇಸಿಂಗ್ ಈವೆಂಟ್‌ಗಳಿಗೆ ನಂತರ ಪರಿಶೀಲಿಸಿ';

  @override
  String get raceCategory => 'రేస్ వర్గం';

  @override
  String get traditionalRacingExperience => 'సాంప్రదాయ రేసింగ్ అనుభవం';

  @override
  String get raceInformation => 'రేస్ సమాచారం';

  @override
  String get category => 'ವರ್ಗ';

  @override
  String get status => 'స్థితి';

  @override
  String get participants => 'పాల్గొనేవారు';

  @override
  String get multipleEntries => 'అనేక ఎంట్రీలు';

  @override
  String get duration => 'ಅವಧಿ';

  @override
  String get ongoing => 'కొనసాగుతున్న';

  @override
  String get prize => 'బహుమతి';

  @override
  String get trophiesAndRecognition => 'ట్రోఫీలు మరియు గుర్తింపు';

  @override
  String get raceIsLiveNow => 'రేస్ ఇప్పుడు లైవ్!';

  @override
  String get watchExcitingCompetition => 'ఉత్తేజకరమైన పోటీని చూడండి';

  @override
  String get aboutThisRace => 'ఈ రేస్ గురించి';

  @override
  String get defaultRaceDescription =>
      'ఈ ఉత్తేజకరమైన లైవ్ ఈవెంట్‌లో సాంప్రదాయ జంతు రేసింగ్ యొక్క థ్రిల్‌ను అనుభవించండి. మనుషులు మరియు జంతువుల మధ్య బంధాన్ని ప్రదర్శించే ఈ కాలాతీత సంప్రదాయంలో నైపుణ్యం ఉన్న పాల్గొనేవారు పోటీ పడటం చూడండి.';

  @override
  String get liveStream => 'లైవ్ స్ట్రీమ్';

  @override
  String get liveStreamComingSoon => 'లైవ్ స్ట్రీమ్ త్వరలో వస్తుంది';

  @override
  String get youtubeLinksAvailable =>
      'స్ట్రీమింగ్ ప్రారంభమైనప్పుడు YouTube లింక్‌లు అందుబాటులో ఉంటాయి';

  @override
  String get getNotifiedWhenStreaming =>
      'ఈ రేస్ వర్గానికి లైవ్ స్ట్రీమింగ్ ప్రారంభమైనప్పుడు నోటిఫికేషన్ పొందండి';

  @override
  String get liveRace => 'లైవ్ రేస్';

  @override
  String get na => 'అందుబాటులోలేదు';

  @override
  String get regionalChampionship => 'ప్రాంతీయ ఛాంపియన్‌షిప్';

  @override
  String get districtFinals => 'జిల్లా ఫైనల్స్';

  @override
  String get stateCompetition => 'రాష్ట్ర పోటీ';

  @override
  String get tomorrowTenAM => 'రేపు ఉదయం 10:00 గంటలకు';

  @override
  String get nextWeek => 'వచ్చే వారం';

  @override
  String get sellPashu => 'ಪಶು ಮಾರಾಟ ಮಾಡಿ';

  @override
  String get youCanProceedWithListing => 'ನೀವು ಪಟ್ಟಿಯೊಂದಿಗೆ ಮುಂದುವರಿಯಬಹುದು';

  @override
  String get minimumRequiredToList =>
      'ನಿಮ್ಮ ಪ್ರಾಣಿಯನ್ನು ಪಟ್ಟಿ ಮಾಡಲು ಕನಿಷ್ಠ ₹15 ಅಗತ್ಯ';

  @override
  String get animalTypes => 'ಪ್ರಾಣಿ ಪ್ರಕಾರಗಳು';

  @override
  String get selectAnimalType => 'ಪ್ರಾಣಿ ಪ್ರಕಾರವನ್ನು ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get animalCategory => 'ಪ್ರಾಣಿ ವರ್ಗ';

  @override
  String get pleaseSelectAnimalTypeFirst =>
      'ದಯವಿಟ್ಟು ಮೊದಲು ಪ್ರಾಣಿ ಪ್ರಕಾರವನ್ನು ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get selectAnimalCategory => 'ಪ್ರಾಣಿ ವರ್ಗವನ್ನು ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get nameOfTheAnimal => 'ಪ್ರಾಣಿಯ ಹೆಸರು';

  @override
  String get enterAnimalAge => 'ಪ್ರಾಣಿಯ ವಯಸ್ಸನ್ನು ನಮೂದಿಸಿ';

  @override
  String get selectGenderOfAnimal => 'ಪ್ರಾಣಿಯ ಲಿಂಗವನ್ನು ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get price => 'ಬೆಲೆ';

  @override
  String get negotiable => 'ಮಾತುಕತೆ ಮಾಡಬಹುದಾದ';

  @override
  String get isPriceNegotiable => 'ಬೆಲೆ ಮಾತುಕತೆ ಮಾಡಬಹುದಾದದ್ದೇ?';

  @override
  String get yourPhoneNumber => 'ನಿಮ್ಮ ಫೋನ್ ನಂಬರ್';

  @override
  String get enterYourPhoneNumber => 'ನಿಮ್ಮ ಫೋನ್ ನಂಬರ್ ನಮೂದಿಸಿ';

  @override
  String get animalDescription => 'ಪ್ರಾಣಿಯ ವಿವರಣೆ';

  @override
  String get enterAnimalDescription => 'ಪ್ರಾಣಿಯ ವಿವರಣೆಯನ್ನು ನಮೂದಿಸಿ';

  @override
  String get getAddressForPashu => 'ಪಶುವಿಗಾಗಿ ವಿಳಾಸವನ್ನು ಪಡೆಯಿರಿ';

  @override
  String get submitAndPay => 'ಸಲ್ಲಿಸಿ ಮತ್ತು ₹15 ಪಾವತಿಸಿ';

  @override
  String get insufficientBalance =>
      'ಸಾಕಷ್ಟು ಬ್ಯಾಲೆನ್ಸ್ ಇಲ್ಲ. ದಯವಿಟ್ಟು ಹಣವನ್ನು ಸೇರಿಸಿ।';

  @override
  String get submitting => 'ಸಲ್ಲಿಸುತ್ತಿದ್ದೇವೆ...';

  @override
  String get locationServicesDisabled => 'ಸ್ಥಳ ಸೇವೆಗಳನ್ನು ನಿಷ್ಕ್ರಿಯಗೊಳಿಸಲಾಗಿದೆ';

  @override
  String get locationPermissionPermanentlyDenied =>
      'ಸ್ಥಳ ಅನುಮತಿಯನ್ನು ಶಾಶ್ವತವಾಗಿ ನಿರಾಕರಿಸಲಾಗಿದೆ';

  @override
  String get locationPermissionDenied => 'ಸ್ಥಳ ಅನುಮತಿ ನಿರಾಕರಿಸಲಾಗಿದೆ';

  @override
  String get unableToDetermineAddress =>
      'ವಿಳಾಸವನ್ನು ನಿರ್ಧರಿಸಲು ಸಾಧ್ಯವಾಗುತ್ತಿಲ್ಲ';

  @override
  String get error => 'ದೋಷ';

  @override
  String get missingRequiredFields => 'ಅಗತ್ಯವಿರುವ ಕ್ಷೇತ್ರಗಳು ಕಾಣೆಯಾಗಿವೆ';

  @override
  String get pleaseEnterValidPhoneNumber =>
      'ದಯವಿಟ್ಟು ಮಾನ್ಯವಾದ ಫೋನ್ ನಂಬರ್ ನಮೂದಿಸಿ';

  @override
  String get pleaseEnterValidAge => 'ದಯವಿಟ್ಟು ಮಾನ್ಯವಾದ ವಯಸ್ಸನ್ನು ನಮೂದಿಸಿ';

  @override
  String get pleaseEnterValidPrice => 'ದಯವಿಟ್ಟು ಮಾನ್ಯವಾದ ಬೆಲೆಯನ್ನು ನಮೂದಿಸಿ';

  @override
  String get pashuListedSuccessfully => 'ಪಶು ಯಶಸ್ವಿಯಾಗಿ ಪಟ್ಟಿ ಮಾಡಲಾಗಿದೆ!';

  @override
  String get errorOccurred => 'ಒಂದು ದೋಷ ಸಂಭವಿಸಿದೆ';

  @override
  String get selectCategory => 'ವರ್ಗವನ್ನು ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get selectGender => 'ಲಿಂಗವನ್ನು ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get male => 'ಪುರುಷ';

  @override
  String get female => 'ಸ್ತ್ರೀ';

  @override
  String get user => 'ಬಳಕೆದಾರ';

  @override
  String get other => 'ಇತರ';

  @override
  String get unknown => 'ಅಜ್ಞಾತ';

  @override
  String get traditionalSportsAnimal => 'ಸಾಂಪ್ರದಾಯಿಕ ಕ್ರೀಡಾ ಪ್ರಾಣಿ';

  @override
  String get livestockAnimal => 'ಜಾನುವಾರು ಪ್ರಾಣಿ';

  @override
  String get petAnimal => 'ಸಾಕುಪ್ರಾಣಿ';

  @override
  String get farmHouseAnimal => 'ಫಾರ್ಮ್ ಹೌಸ್ ಪ್ರಾಣಿ';

  @override
  String get bull => 'ಎತ್ತು';

  @override
  String get camel => 'ಒಂಟೆ';

  @override
  String get bird => 'ಪಕ್ಷಿ';

  @override
  String get pigeon => 'ಪಾರಿವಾಳ';

  @override
  String get cock => 'ಹುಂಡಿ';

  @override
  String get dog => 'ನಾಯಿ';

  @override
  String get goat => 'ಮೇಕೆ';

  @override
  String get horse => 'ಕುದುರೆ';

  @override
  String get buffalo => 'ಎಮ್ಮೆ';

  @override
  String get sheep => 'ಕುರಿ';

  @override
  String get pigs => 'ಹಂದಿಗಳು';

  @override
  String get cat => 'ಬೆಕ್ಕು';

  @override
  String get fishes => 'ಮೀನುಗಳು';

  @override
  String get smallMammals => 'ಸಣ್ಣ ಸಸ್ತನಿಗಳು';

  @override
  String get searchAnimalsBreeds => 'ಪ್ರಾಣಿಗಳು, ಜಾತಿಗಳನ್ನು ಹುಡುಕಿ...';

  @override
  String get unknownAnimal => 'ಅಜ್ಞಾತ ಪ್ರಾಣಿ';

  @override
  String get breed => 'ಜಾತಿ';

  @override
  String get owner => 'ಮಾಲೀಕ';

  @override
  String get callMe => 'ನನಗೆ ಕರೆ ಮಾಡಿ';

  @override
  String get buyNow => 'ಈಗ ಖರೀದಿಸಿ';

  @override
  String get addedToWishlist => 'ವಿಷ್‌ಲಿಸ್ಟ್‌ಗೆ ಸೇರಿಸಲಾಗಿದೆ';

  @override
  String get animal => 'ಪ್ರಾಣಿ';

  @override
  String get failedToAddToWishlist => 'ವಿಷ್‌ಲಿಸ್ಟ್‌ಗೆ ಸೇರಿಸುವಲ್ಲಿ ವಿಫಲವಾಗಿದೆ';

  @override
  String get noAnimalsFound => 'ಯಾವುದೇ ಪ್ರಾಣಿಗಳು ಕಂಡುಬಂದಿಲ್ಲ';

  @override
  String get trySelectingDifferentCategory =>
      'ವಿಭಿನ್ನ ವರ್ಗವನ್ನು ಆಯ್ಕೆಮಾಡಲು ಪ್ರಯತ್ನಿಸಿ';

  @override
  String get checkBackLaterForNewListings => 'ಹೊಸ ಪಟ್ಟಿಗಳಿಗಾಗಿ ನಂತರ ಪರಿಶೀಲಿಸಿ';

  @override
  String get purchaseRequestSent => 'ಖರೀದಿ ವಿನಂತಿಯನ್ನು ಕಳುಹಿಸಲಾಗಿದೆ';

  @override
  String get all => 'ಎಲ್ಲಾ';

  @override
  String get cow => 'ಗೋವು';

  @override
  String get cats => 'ಬೆಕ್ಕುಗಳು';

  @override
  String get animalDetails => 'ಪ್ರಾಣಿಯ ವಿವರಗಳು';

  @override
  String get photos => 'ಫೋಟೋಗಳು';

  @override
  String get type => 'ಪ್ರಕಾರ';

  @override
  String get age => 'ವಯಸ್ಸು';

  @override
  String get gender => 'ಲಿಂಗ';

  @override
  String get years => 'ವರ್ಷಗಳು';

  @override
  String get pricingInformation => 'ಬೆಲೆ ಮಾಹಿತಿ';

  @override
  String get fixedPrice => 'ನಿಗದಿತ ಬೆಲೆ';

  @override
  String get ownerAndLocation => 'ಮಾಲೀಕ ಮತ್ತು ಸ್ಥಳ';

  @override
  String get location => 'ಸ್ಥಳ';

  @override
  String get distance => 'ದೂರ';

  @override
  String get notSpecified => 'ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿಲ್ಲ';

  @override
  String get meters => 'ಮೀಟರ್‌ಗಳು';

  @override
  String get km => 'ಕಿಮೀ';

  @override
  String get description => 'ವಿವರಣೆ';

  @override
  String get contactSeller => 'ಮಾರಾಟಗಾರನನ್ನು ಸಂಪರ್ಕಿಸಿ';

  @override
  String get unlockContactDetails =>
      'ಮಾರಾಟಗಾರನೊಂದಿಗೆ ಸಂಪರ್ಕಿಸಲು ₹2ಗೆ ಸಂಪರ್ಕ ವಿವರಗಳನ್ನು ಅನ್‌ಲಾಕ್ ಮಾಡಿ';

  @override
  String get unlocking => 'ಅನ್‌ಲಾಕ್ ಮಾಡುತ್ತಿದ್ದೇವೆ...';

  @override
  String get unlockContact => 'ಸಂಪರ್ಕವನ್ನು ಅನ್‌ಲಾಕ್ ಮಾಡಿ (₹2)';

  @override
  String get contactOptions => 'ಸಂಪರ್ಕ ಆಯ್ಕೆಗಳು';

  @override
  String get call => 'ಕರೆ';

  @override
  String get whatsApp => 'ವಾಟ್ಸ್‌ಆಪ್';

  @override
  String get contact => 'ಸಂಪರ್ಕ';

  @override
  String get notAvailable => 'ಲಭ್ಯವಿಲ್ಲ';

  @override
  String get userNotLoggedIn => 'ಬಳಕೆದಾರ ಲಾಗಿನ್ ಆಗಿಲ್ಲ';

  @override
  String get userDataNotFound => 'ಬಳಕೆದಾರ ಡೇಟಾ ಕಂಡುಬಂದಿಲ್ಲ';

  @override
  String get contactAlreadyUnlocked =>
      'ಈ ಸಂಪರ್ಕವನ್ನು ಈಗಾಗಲೇ ಅನ್‌ಲಾಕ್ ಮಾಡಲಾಗಿದೆ.';

  @override
  String get contactUnlockedSuccessfully =>
      'ಸಂಪರ್ಕವನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಅನ್‌ಲಾಕ್ ಮಾಡಲಾಗಿದೆ!';

  @override
  String get couldNotLaunchPhoneApp =>
      'ಫೋನ್ ಆಪ್ ಅನ್ನು ಲಾಂಚ್ ಮಾಡಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ';

  @override
  String get phoneNumberNotAvailable => 'ಫೋನ್ ನಂಬರ್ ಲಭ್ಯವಿಲ್ಲ';

  @override
  String get couldNotOpenWhatsApp => 'ವಾಟ್ಸ್‌ಆಪ್ ತೆರೆಯಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ';

  @override
  String whatsAppMessageTemplate(Object animalName) {
    return 'ನಮಸ್ತೆ, ಪಶು ಪರಿವಾರದಲ್ಲಿ ಪಟ್ಟಿ ಮಾಡಲಾದ ನಿಮ್ಮ $animalNameನಲ್ಲಿ ನನಗೆ ಆಸಕ್ತಿ ಇದೆ.';
  }

  @override
  String get locationNotAvailable => 'ಸ್ಥಳ ಲಭ್ಯವಿಲ್ಲ';

  @override
  String get remove => 'ತೆಗೆದುಹಾಕಿ';

  @override
  String get removedFromWishlist => 'ವಿಷ್‌ಲಿಸ್ಟ್‌ನಿಂದ ತೆಗೆದುಹಾಕಲಾಗಿದೆ';

  @override
  String get failedToRemove => 'ತೆಗೆದುಹಾಕುವಲ್ಲಿ ವಿಫಲವಾಗಿದೆ';

  @override
  String get animalDetailsComingSoon => 'ಪ್ರಾಣಿಯ ವಿವರಗಳು ಶೀಘ್ರದಲ್ಲೇ ಬರುತ್ತಿವೆ';

  @override
  String get fullAnimalDetailsModal =>
      'ಪೂರ್ಣ ಪ್ರಾಣಿ ವಿವರಗಳ ಮಾಡಲ್ ಇಲ್ಲಿ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗುವುದು';

  @override
  String get noWishlistAnimalsFound =>
      'ಯಾವುದೇ ವಿಷ್‌ಲಿಸ್ಟ್ ಪ್ರಾಣಿಗಳು ಕಂಡುಬಂದಿಲ್ಲ';

  @override
  String get tryAddingAnimalsToWishlist =>
      'ನಿಮ್ಮ ವಿಷ್‌ಲಿಸ್ಟ್‌ಗೆ ಕೆಲವು ಪ್ರಾಣಿಗಳನ್ನು ಸೇರಿಸಲು ಪ್ರಯತ್ನಿಸಿ!';

  @override
  String get investmentProject => 'ಹೂಡಿಕೆ ಯೋಜನೆ';

  @override
  String get upcomingProjects => 'ಮುಂಬರುವ ಯೋಜನೆಗಳು';

  @override
  String get liveProjects => 'ಲೈವ್ ಯೋಜನೆಗಳು';

  @override
  String get completedProjects => 'ಪೂರ್ಣಗೊಂಡ ಯೋಜನೆಗಳು';

  @override
  String get mvpForAquacultureInvestment => 'ಅಕ್ವಾಕಲ್ಚರ್ ಹೂಡಿಕೆಗಾಗಿ MVP';

  @override
  String get longTerm => 'ದೀರ್ಘಾವಧಿ';

  @override
  String get amount => 'ಮೊತ್ತ';

  @override
  String get startDate => 'ಪ್ರಾರಂಭ ದಿನಾಂಕ';

  @override
  String get sixToEightMonths => '6 ರಿಂದ 8 ತಿಂಗಳುಗಳು';

  @override
  String get lotsBooked => 'ಲಾಟ್‌ಗಳನ್ನು ಬುಕ್ ಮಾಡಲಾಗಿದೆ';

  @override
  String get noProjectsAvailable => 'ಯಾವುದೇ ಯೋಜನೆಗಳು ಲಭ್ಯವಿಲ್ಲ।';

  @override
  String get firstAugust2025 => '1 ಆಗಸ್ಟ್ 2025';

  @override
  String get addAmountAndGetPlans =>
      'ಮೊತ್ತವನ್ನು ಸೇರಿಸಿ ಮತ್ತು ಯೋಜನೆಗಳನ್ನು ಪಡೆಯಿರಿ';

  @override
  String get getVerifiedYourPashu => 'ನಿಮ್ಮ ಪಶುವನ್ನು ಪರಿಶೀಲಿಸಿ';

  @override
  String get termsAndPrivacy => 'ನಿಯಮಗಳು ಮತ್ತು ಗೌಪ್ಯತೆ';

  @override
  String get newA => 'ಹೊಸ';

  @override
  String get areYouSureLogout =>
      'ನೀವು ನಿಮ್ಮ ಖಾತೆಯಿಂದ ಲಾಗೌಟ್ ಮಾಡಲು ಖಚಿತವಾಗಿ ಬಯಸುವಿರಾ?';

  @override
  String get noProfileFound => 'ಪ್ರೊಫೈಲ್ ಕಂಡುಬಂದಿಲ್ಲ';

  @override
  String get profileInformationNotAvailable => 'ಪ್ರೊಫೈಲ್ ಮಾಹಿತಿ ಲಭ್ಯವಿಲ್ಲ';

  @override
  String get subscriptionPlans => 'ಸಬ್‌ಸ್ಕ್ರಿಪ್‌ಷನ್ ಪ್ಲಾನ್‌ಗಳು';

  @override
  String get chooseYourPlan => 'ನಿಮ್ಮ ಪ್ಲಾನ್ ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get unlockPremiumFeatures =>
      'ಪ್ರೀಮಿಯಂ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಅನ್‌ಲಾಕ್ ಮಾಡಿ ಮತ್ತು ನಮ್ಮ ಸಬ್‌ಸ್ಕ್ರಿಪ್‌ಷನ್ ಪ್ಲಾನ್‌ಗಳೊಂದಿಗೆ ನಿಮ್ಮ ಜಾನುವಾರು ವ್ಯಾಪಾರವನ್ನು ಬೆಳೆಸಿ';

  @override
  String get diamondPlan => 'ಡೈಮಂಡ್ ಪ್ಲಾನ್';

  @override
  String get goldPlan => 'ಗೋಲ್ಡ್ ಪ್ಲಾನ್';

  @override
  String get silverPlan => 'ಸಿಲ್ವರ್ ಪ್ಲಾನ್';

  @override
  String get year => 'ವರ್ಷ';

  @override
  String get months3 => '3 ತಿಂಗಳುಗಳು';

  @override
  String get month => 'ತಿಂಗಳು';

  @override
  String get choosePlan => 'ಪ್ಲಾನ್ ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get unlimitedPashuProfileContact => 'ಅನ್‌ಲಿಮಿಟೆಡ್ ಪಶು ಪ್ರೊಫೈಲ್ ಸಂಪರ್ಕ';

  @override
  String get unlimitedFreePashuListings => 'ಅನ್‌ಲಿಮಿಟೆಡ್ ಉಚಿತ ಪಶು ಪಟ್ಟಿಗಳು';

  @override
  String get priorityCustomerSupport => 'ಆದ್ಯತೆ ಗ್ರಾಹಕ ಬೆಂಬಲ';

  @override
  String get advancedAnalytics => 'ಸುಧಾರಿತ ವಿಶ್ಲೇಷಣೆ';

  @override
  String get premiumBadge => 'ಪ್ರೀಮಿಯಂ ಬ್ಯಾಡ್ಜ್';

  @override
  String get freePashuListings10 => '10 ಉಚಿತ ಪಶು ಪಟ್ಟಿಗಳು';

  @override
  String get standardCustomerSupport => 'ಪ್ರಮಾಣಿತ ಗ್ರಾಹಕ ಬೆಂಬಲ';

  @override
  String get basicAnalytics => 'ಮೂಲಭೂತ ವಿಶ್ಲೇಷಣೆ';

  @override
  String get freePashuListings2 => '2 ಉಚಿತ ಪಶು ಪಟ್ಟಿಗಳು';

  @override
  String get emailSupport => 'ಇಮೇಲ್ ಬೆಂಬಲ';

  @override
  String get addMoneyToYourWallet => 'ನಿಮ್ಮ ವಾಲೆಟ್‌ಗೆ ಹಣವನ್ನು ಸೇರಿಸಿ';

  @override
  String get addFundsToWallet =>
      'ನಿಮ್ಮ ವಾಲೆಟ್‌ಗೆ ಹಣವನ್ನು ಸೇರಿಸಿ ಮತ್ತು ಸಬ್‌ಸ್ಕ್ರಿಪ್‌ಷನ್‌ಗಳಿಗೆ ಸುಲಭವಾಗಿ ಪಾವತಿಸಿ. ನಿಮ್ಮ ವಾಲೆಟ್ ನಮ್ಮ ಎಲ್ಲಾ ಸೇವೆಗಳಲ್ಲಿ ಬಳಸಬಹುದು.';

  @override
  String get enterAmountEg500 => 'ಮೊತ್ತವನ್ನು ನಮೂದಿಸಿ (ಉದಾ. 500)';

  @override
  String addAmount(String amount) {
    return '₹$amount ಸೇರಿಸಿ';
  }

  @override
  String get tipWalletContact =>
      'ಸಲಹೆ: ಸಂಪರ್ಕ ವಿವರಗಳನ್ನು ತಕ್ಷಣ ನೋಡಲು ನಿಮ್ಮ ವಾಲೆಟ್ ಅನ್ನು ಬಳಸಬಹುದು.';

  @override
  String subscribeToPlan(String planName) {
    return 'Subscribe to $planName';
  }

  @override
  String chargedForSubscription(String price, String period) {
    return 'ಈ $period ಸಬ್‌ಸ್ಕ್ರಿಪ್‌ಷನ್‌ಗಾಗಿ ನಿಮ್ಮಿಂದ ₹$price ಚಾರ್ಜ್ ಮಾಡಲಾಗುತ್ತದೆ.';
  }

  @override
  String get confirmSubscription => 'ಸಬ್‌ಸ್ಕ್ರಿಪ್‌ಷನ್ ದೃಢೀಕರಿಸಿ';

  @override
  String get subscriptionSuccessful => 'ಸಬ್‌ಸ್ಕ್ರಿಪ್‌ಷನ್ ಯಶಸ್ವಿ!';

  @override
  String subscriptionSuccessMessage(String planName) {
    return 'ನೀವು ಯಶಸ್ವಿಯಾಗಿ $planNameಗೆ ಸಬ್‌ಸ್ಕ್ರೈಬ್ ಮಾಡಿದ್ದೀರಿ. ಎಲ್ಲಾ ಪ್ರೀಮಿಯಂ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಆನಂದಿಸಿ!';
  }

  @override
  String get continueA => 'ಮುಂದುವರಿಸಿ';

  @override
  String get subscriptionHelp => 'ಸಬ್‌ಸ್ಕ್ರಿಪ್‌ಷನ್ ಸಹಾಯ';

  @override
  String get helpContent =>
      '• ಡೈಮಂಡ್ ಪ್ಲಾನ್: ₹365/ವರ್ಷ\n• ಗೋಲ್ಡ್ ಪ್ಲಾನ್: ₹140/3 ತಿಂಗಳುಗಳು\n• ಸಿಲ್ವರ್ ಪ್ಲಾನ್: ₹49/ತಿಂಗಳು\n• ನಿಮ್ಮ ಪ್ರೊಫೈಲ್‌ನಿಂದ ಯಾವುದೇ ಸಮಯದಲ್ಲಿ ರದ್ದುಗೊಳಿಸಿ\n• ಎಲ್ಲಾ ವೈಶಿಷ್ಟ್ಯಗಳು ತಕ್ಷಣ ಅನ್‌ಲಾಕ್ ಆಗುತ್ತವೆ\n• 24/7 ಗ್ರಾಹಕ ಬೆಂಬಲ ಸೇರಿಸಲಾಗಿದೆ';

  @override
  String get gotIt => 'ಅರ್ಥವಾಯಿತು';

  @override
  String get pleaseEnterValidAmount => 'ದಯವಿಟ್ಟು ಮಾನ್ಯವಾದ ಮೊತ್ತವನ್ನು ನಮೂದಿಸಿ';

  @override
  String get couldNotInitiatePayment => 'ಪಾವತಿಯನ್ನು ಪ್ರಾರಂಭಿಸಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ';

  @override
  String get somethingWentWrongPayment => 'ಪಾವತಿಯಲ್ಲಿ ಏನೋ ತಪ್ಪಾಗಿದೆ.';

  @override
  String get paymentCancelled =>
      'ಪಾವತಿಯನ್ನು ರದ್ದುಗೊಳಿಸಲಾಗಿದೆ ಅಥವಾ ಸಮಯಕ್ಕೆ ಪೂರ್ಣಗೊಳಿಸಲಿಲ್ಲ.';

  @override
  String get paymentFailed => 'ಪಾವತಿ ವಿಫಲವಾಗಿದೆ';

  @override
  String get externalWalletSelected => 'ಬಾಹ್ಯ ವಾಲೆಟ್ ಆಯ್ಕೆಮಾಡಲಾಗಿದೆ';

  @override
  String get getInTouch => 'ಸಂಪರ್ಕದಲ್ಲಿರಿ';

  @override
  String get contactUsDescription =>
      'ನಾವು ಸಹಾಯ ಮಾಡಲು ಇಲ್ಲಿದ್ದೇವೆ! ಯಾವುದೇ ಸಮಯದಲ್ಲಿ ನಮ್ಮನ್ನು ಸಂಪರ್ಕಿಸಿ ಮತ್ತು ನಾವು ಸಾಧ್ಯವಾದಷ್ಟು ಬೇಗ ನಿಮ್ಮ ಬಳಿಗೆ ಹಿಂತಿರುಗುತ್ತೇವೆ.';

  @override
  String get contactInformation => 'ಸಂಪರ್ಕ ಮಾಹಿತಿ';

  @override
  String get officeAddress => 'ಕಚೇರಿ ವಿಳಾಸ';

  @override
  String get pashuParivarHeadquarters =>
      'ಪಶು ಪರಿವಾರ್ ಮುಖ್ಯ ಕಚೇರಿ\nಭೋಪಾಲ್, ಮಧ್ಯ ಪ್ರದೇಶ\nಭಾರತ';

  @override
  String get sendUsAMessage => 'ನಮಗೆ ಸಂದೇಶ ಕಳುಹಿಸಿ';

  @override
  String get fullName => 'ಪೂರ್ಣ ಹೆಸರು';

  @override
  String get enterYourFullName => 'ನಿಮ್ಮ ಪೂರ್ಣ ಹೆಸರನ್ನು ನಮೂದಿಸಿ';

  @override
  String get enterYourEmailAddress => 'ನಿಮ್ಮ ಇಮೇಲ್ ವಿಳಾಸವನ್ನು ನಮೂದಿಸಿ';

  @override
  String get message => 'ಸಂದೇಶ';

  @override
  String get tellUsHowWeCanHelp => 'ನಾವು ನಿಮಗೆ ಹೇಗೆ ಸಹಾಯ ಮಾಡಬಹುದೆಂದು ಹೇಳಿ...';

  @override
  String get sendingMessage => 'ಸಂದೇಶ ಕಳುಹಿಸಲಾಗುತ್ತಿದೆ...';

  @override
  String get sendMessage => 'ಸಂದೇಶ ಕಳುಹಿಸಿ';

  @override
  String get responseTimeNote =>
      'ನಾವು ಸಾಮಾನ್ಯವಾಗಿ ವ್ಯಾಪಾರದ ದಿನಗಳಲ್ಲಿ 24 ಗಂಟೆಗಳಲ್ಲಿ ಪ್ರತಿಕ್ರಿಯಿಸುತ್ತೇವೆ.';

  @override
  String get followUs => 'ನಮ್ಮನ್ನು ಅನುಸರಿಸಿ';

  @override
  String get stayUpdatedWithNews =>
      'ನಮ್ಮ ಇತ್ತೀಚಿನ ಸುದ್ದಿ ಮತ್ತು ಅಪ್‌ಡೇಟ್‌ಗಳೊಂದಿಗೆ ಅಪ್‌ಡೇಟ್ ಆಗಿರಿ';

  @override
  String get facebook => 'ಫೇಸ್‌ಬುಕ್';

  @override
  String get instagram => 'ಇನ್‌ಸ್ಟಾಗ್ರಾಮ್';

  @override
  String get twitter => 'ಟ್ವಿಟ್ಟರ್';

  @override
  String get youtube => 'ಯೂಟ್ಯೂಬ್';

  @override
  String get copiedToClipboard => 'ಕ್ಲಿಪ್‌ಬೋರ್ಡ್‌ಗೆ ನಕಲಿಸಲಾಗಿದೆ!';

  @override
  String get messageSentSuccessfully => 'ಸಂದೇಶವನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಕಳುಹಿಸಲಾಗಿದೆ!';

  @override
  String get thankYouForContacting =>
      'ನಮ್ಮನ್ನು ಸಂಪರ್ಕಿಸಿದ್ದಕ್ಕಾಗಿ ಧನ್ಯವಾದಗಳು. ನಾವು 24 ಗಂಟೆಗಳಲ್ಲಿ ನಿಮ್ಮ ಬಳಿಗೆ ಹಿಂತಿರುಗುತ್ತೇವೆ.';

  @override
  String get nameMustBeAtLeast2Characters => 'ಹೆಸರು ಕನಿಷ್ಠ 2 ಅಕ್ಷರಗಳಾಗಿರಬೇಕು';

  @override
  String get emailIsRequired => 'ಇಮೇಲ್ ಅಗತ್ಯವಿದೆ';

  @override
  String get pleaseEnterValidEmail =>
      'ದಯವಿಟ್ಟು ಮಾನ್ಯವಾದ ಇಮೇಲ್ ವಿಳಾಸವನ್ನು ನಮೂದಿಸಿ';

  @override
  String get messageIsRequired => 'ಸಂದೇಶ ಅಗತ್ಯವಿದೆ';

  @override
  String get messageMustBeAtLeast10Characters =>
      'ಸಂದೇಶ ಕನಿಷ್ಠ 10 ಅಕ್ಷರಗಳಾಗಿರಬೇಕು';

  @override
  String get invest => 'ಕೃಷಿ-ಪಶುಸಂಗೋಪನೆಯಲ್ಲಿ ಹೂಡಿಕೆ ಮಾಡಿ';

  @override
  String get total => 'ಒಟ್ಟು';

  @override
  String get active => 'ಸಕ್ರಿಯ';

  @override
  String get pending => 'ಬಾಕಿ';

  @override
  String get edit => 'ಸಂಪಾದಿಸಿ';

  @override
  String get delete => 'ತೆಗೆದುಹಾಕಿ';

  @override
  String get pendingStatus => 'ಬಾಕಿ';

  @override
  String get failedToLoadListings => 'ಪಟ್ಟಿಗಳನ್ನು ಲೋಡ್ ಮಾಡುವಲ್ಲಿ ವಿಫಲವಾಗಿದೆ';

  @override
  String get noListedAnimals => 'ಪಟ್ಟಿ ಮಾಡಿದ ಪ್ರಾಣಿಗಳು ಇಲ್ಲ';

  @override
  String get noListedAnimalsDescription =>
      'ನೀವು ಇನ್ನೂ ಯಾವುದೇ ಪ್ರಾಣಿಗಳನ್ನು ಪಟ್ಟಿ ಮಾಡಿಲ್ಲ. ನಿಮ್ಮ ಮೊದಲ ಪಟ್ಟಿಯನ್ನು ಸೇರಿಸುವ ಮೂಲಕ ಪ್ರಾರಂಭಿಸಿ!';

  @override
  String get addNewListing => 'ಹೊಸ ಪಟ್ಟಿ ಸೇರಿಸಿ';

  @override
  String get deleteListing => 'ಪಟ್ಟಿಯನ್ನು ತೆಗೆದುಹಾಕಿ';

  @override
  String deleteConfirmation(String animalName) {
    return 'ನೀವು ನಿಜವಾಗಿಯೂ \"$animalName\"ನ್ನು ತೆಗೆದುಹಾಕಲು ಬಯಸುವಿರಾ? ಈ ಕ್ರಿಯೆಯನ್ನು ರದ್ದುಗೊಳಿಸಲಾಗುವುದಿಲ್ಲ.';
  }

  @override
  String deleteSuccessMessage(String animalName) {
    return '$animalName ಯಶಸ್ವಿಯಾಗಿ ತೆಗೆದುಹಾಕಲಾಗಿದೆ';
  }

  @override
  String get withdrawFromWallet => 'ವಾಲೆಟ್‌ನಿಂದ ಹಿಂಪಡೆಯಿರಿ';

  @override
  String get availableBalance => 'ಲಭ್ಯವಿರುವ ಬ್ಯಾಲೆನ್ಸ್';

  @override
  String get withdrawalEligible => 'ಹಿಂಪಡೆಯುವ ಅರ್ಹತೆ';

  @override
  String get withdrawalRequirements => 'ಹಿಂಪಡೆಯುವ ಅವಶ್ಯಕತೆಗಳು';

  @override
  String youHaveSpentAndCanWithdraw(String counter) {
    return 'ನೀವು ₹$counter ಖರ್ಚು ಮಾಡಿದ್ದೀರಿ ಮತ್ತು ಹಣವನ್ನು ಹಿಂಪಡೆಯಬಹುದು';
  }

  @override
  String spendMoreToEnableWithdrawal(String amount, String counter) {
    return 'ಹಿಂಪಡೆಯುವುದನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಲು ₹$amount ಹೆಚ್ಚು ಖರ್ಚು ಮಾಡಿ (ಪ್ರಸ್ತುತ: ₹$counter)';
  }

  @override
  String get withdrawalDetails => 'ಹಿಂಪಡೆಯುವ ವಿವರಗಳು';

  @override
  String get enterAmountEg => 'ಮೊತ್ತವನ್ನು ನಮೂದಿಸಿ ಉದಾ. 500';

  @override
  String get enterUpiIdEg => 'UPI ID ನಮೂದಿಸಿ (ಉದಾ. example@upi)';

  @override
  String get enterUpiIdEgPlaceholder => 'UPI ID ನಮೂದಿಸಿ ಉದಾ. example@upi';

  @override
  String get processing => 'ಪ್ರಕ್ರಿಯೆಗೊಳಿಸಲಾಗುತ್ತಿದೆ...';

  @override
  String withdrawAmount(String amount) {
    return '₹$amount ಹಿಂಪಡೆಯಿರಿ';
  }

  @override
  String get withdrawalRequirementsLabel => 'ಹಿಂಪಡೆಯುವ ಅವಶ್ಯಕತೆಗಳು:';

  @override
  String get minimumSpendingRequired => '• ಕನಿಷ್ಠ ₹50 ಖರ್ಚು ಅಗತ್ಯ';

  @override
  String get walletBalanceRequired => '• ವಾಲೆಟ್ ಬ್ಯಾಲೆನ್ಸ್ ≥ ₹100 ಇರಬೇಕು';

  @override
  String currentSpending(String counter, String status) {
    return '• ಪ್ರಸ್ತುತ ಖರ್ಚು: ₹$counter ($status)';
  }

  @override
  String walletBalanceStatus(String balance, String status) {
    return '• ವಾಲೆಟ್ ಬ್ಯಾಲೆನ್ಸ್: ₹$balance ($status)';
  }

  @override
  String get verified => '✓';

  @override
  String needMoreAmount(String amount) {
    return '₹$amount ಹೆಚ್ಚು ಅಗತ್ಯ';
  }

  @override
  String get tipWithdrawProcessingTime =>
      'ಸಲಹೆ: ಹಿಂಪಡೆಯುವಿಕೆಗಳನ್ನು ನಿಮ್ಮ UPI ಖಾತೆಗೆ 24-48 ಗಂಟೆಗಳಲ್ಲಿ ಪ್ರಕ್ರಿಯೆಗೊಳಿಸಲಾಗುತ್ತದೆ.';

  @override
  String get withdrawalRequestSubmitted => 'ಹಿಂಪಡೆಯುವ ಕೋರಿಕೆ ಸಲ್ಲಿಸಲಾಗಿದೆ!';

  @override
  String withdrawalRequestSuccessMessage(String amount) {
    return '₹$amount ನಿಮ್ಮ ಹಿಂಪಡೆಯುವ ಕೋರಿಕೆಯನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಸಲ್ಲಿಸಲಾಗಿದೆ. ನೀವು 24-48 ಗಂಟೆಗಳಲ್ಲಿ ನಿಮ್ಮ UPI ಖಾತೆಯಲ್ಲಿ ಮೊತ್ತವನ್ನು ಪಡೆಯುತ್ತೀರಿ.';
  }

  @override
  String get failedToLoadData => 'ಡೇಟಾ ಲೋಡ್ ಮಾಡುವಲ್ಲಿ ವಿಫಲವಾಗಿದೆ';

  @override
  String get amountCannotBeEmpty => 'ಮೊತ್ತ ಖಾಲಿ ಇರಲು ಸಾಧ್ಯವಿಲ್ಲ';

  @override
  String amountCannotExceedBalance(String balance) {
    return 'ಮೊತ್ತ ವಾಲೆಟ್ ಬ್ಯಾಲೆನ್ಸ್ ಮೀರಲು ಸಾಧ್ಯವಿಲ್ಲ (₹$balance)';
  }

  @override
  String get minimumWalletBalanceRequired =>
      'ಕನಿಷ್ಠ ₹100 ವಾಲೆಟ್ ಬ್ಯಾಲೆನ್ಸ್ ಅಗತ್ಯ';

  @override
  String get upiIdCannotBeEmpty => 'UPI ID ಖಾಲಿ ಇರಲು ಸಾಧ್ಯವಿಲ್ಲ';

  @override
  String get pleaseEnterValidUpiId => 'ದಯವಿಟ್ಟು ಮಾನ್ಯವಾದ UPI ID ಅನ್ನು ನಮೂದಿಸಿ';

  @override
  String get transactionHistory => 'ವಹಿವಾಟು ಇತಿಹಾಸ';

  @override
  String get noTransactions => 'ವಹಿವಾಟುಗಳಿಲ್ಲ';

  @override
  String get transactionSummary => 'ವಹಿವಾಟು ಸಾರಾಂಶ';

  @override
  String get totalCredit => 'ಒಟ್ಟು ಕ್ರೆಡಿಟ್';

  @override
  String get totalDebit => 'ಒಟ್ಟು ಡೆಬಿಟ್';

  @override
  String get successful => 'ಯಶಸ್ವಿ';

  @override
  String get today => 'ಇಂದು';

  @override
  String get yesterday => 'ನಿನ್ನೆ';

  @override
  String daysAgo(String days) {
    return '$days ದಿನಗಳ ಹಿಂದೆ';
  }

  @override
  String get paymentId => 'ಪೇಮೆಂಟ್ ID';

  @override
  String get fullDate => 'ಪೂರ್ಣ ದಿನಾಂಕ';

  @override
  String get utrNumber => 'UTR ಸಂಖ್ಯೆ';

  @override
  String get failedToLoadTransactions =>
      'ವಹಿವಾಟುಗಳನ್ನು ಲೋಡ್ ಮಾಡುವಲ್ಲಿ ವಿಫಲವಾಗಿದೆ';

  @override
  String get noTransactionsFound => 'ವಹಿವಾಟುಗಳು ಕಂಡುಬಂದಿಲ್ಲ';

  @override
  String get transactionHistoryDescription =>
      'ನಿಮ್ಮ ಮೊದಲ ವಹಿವಾಟು ಮಾಡಿದ ನಂತರ ನಿಮ್ಮ ವಹಿವಾಟು ಇತಿಹಾಸ ಇಲ್ಲಿ ಕಾಣಿಸುತ್ತದೆ';

  @override
  String get goBack => 'ಹಿಂತಿರುಗಿ';

  @override
  String get success => 'ಯಶಸ್ಸು';

  @override
  String get failed => 'ವಿಫಲವಾಗಿದೆ';

  @override
  String get credit => 'ಕ್ರೆಡಿಟ್';

  @override
  String get debit => 'ಡೆಬಿಟ್';

  @override
  String get profileDetails => 'ಪ್ರೊಫೈಲ್ ವಿವರಗಳು';

  @override
  String get address => 'ವಿಳಾಸ';

  @override
  String get notProvided => 'ನೀಡಲಾಗಿಲ್ಲ';

  @override
  String get profileDetailsSectionHeader => 'ಪ್ರೊಫೈಲ್ ವಿವರಗಳು';

  @override
  String get editProfileInformation => 'ಪ್ರೊಫೈಲ್ ಮಾಹಿತಿಯನ್ನು ಸಂಪಾದಿಸಿ';

  @override
  String get nameCannotBeEmpty => 'ಹೆಸರು ಖಾಲಿಯಾಗಿರಬಾರದು';

  @override
  String get nameMinimumCharacters => 'ಹೆಸರು ಕನಿಷ್ಠ 2 ಅಕ್ಷರಗಳಾಗಿರಬೇಕು';

  @override
  String get addressCannotBeEmpty => 'ವಿಳಾಸ ಖಾಲಿಯಾಗಿರಬಾರದು';

  @override
  String get pleaseEnterCompleteAddress =>
      'ದಯವಿಟ್ಟು ಸಂಪೂರ್ಣ ವಿಳಾಸವನ್ನು ನಮೂದಿಸಿ';

  @override
  String get phoneAndReferralNotChangeable =>
      'ಟಿಪ್ಪಣಿ: ದೂರವಾಣಿ ಸಂಖ್ಯೆ ಮತ್ತು ರೆಫರಲ್ ಕೋಡ್ ಅನ್ನು ಬದಲಾಯಿಸಲಾಗದು. ಹೆಸರು, ಇಮೇಲ್ ಮತ್ತು ವಿಳಾಸವನ್ನು ಮಾತ್ರ ನವೀಕರಿಸಬಹುದಾಗಿದೆ.';

  @override
  String get updatingProfile => 'ಪ್ರೊಫೈಲ್ ನವೀಕರಿಸಲಾಗುತ್ತಿದೆ...';

  @override
  String get updateProfile => 'ಪ್ರೊಫೈಲ್ ನವೀಕರಿಸಿ';

  @override
  String get profileUpdatedSuccessfully => 'ಪ್ರೊಫೈಲ್ ಯಶಸ್ವಿಯಾಗಿ ನವೀಕರಿಸಲಾಗಿದೆ!';

  @override
  String get profileUpdateSuccessMessage =>
      'ನಿಮ್ಮ ಪ್ರೊಫೈಲ್ ಮಾಹಿತಿಯನ್ನು ಯಶಸ್ವಿಯಾಗಿ ನವೀಕರಿಸಲಾಗಿದೆ.';

  @override
  String get updateFailed => 'ನವೀಕರಣ ವಿಫಲವಾಯಿತು';

  @override
  String get inviteEarnRewards => 'ಆಹ್ವಾನಿಸಿ ಮತ್ತು ಬಹುಮಾನಗಳನ್ನು ಗೆಲ್ಲಿ';

  @override
  String get shareReferralDescription =>
      'ನಿಮ್ಮ ರೆಫರಲ್ ಕೋಡ್ ಅನ್ನು ಸ್ನೇಹಿತರು ಮತ್ತು ಕುಟುಂಬದವರೊಂದಿಗೆ ಹಂಚಿಕೊಳ್ಳಿ ಮತ್ತು ಅವರು ಪಶು ಪರಿವಾರ್‌ನಲ್ಲಿ ಸೇರಿದಾಗ ವಿಶೇಷ ಬಹುಮಾನಗಳನ್ನು ಪಡೆಯಿರಿ';

  @override
  String get yourReferralCode => 'ನಿಮ್ಮ ರೆಫರಲ್ ಕೋಡ್';

  @override
  String get shareWithFriends => 'ಸ್ನೇಹಿತರೊಂದಿಗೆ ಹಂಚಿಕೊಳ್ಳಿ';

  @override
  String get shareLink => 'ಲಿಂಕ್ ಹಂಚಿಕೊಳ್ಳಿ';

  @override
  String get copyLink => 'ಲಿಂಕ್ ಕಾಪಿ ಮಾಡಿ';

  @override
  String get moreOptions => 'ಇನ್ನಷ್ಟು ಆಯ್ಕೆಗಳು';

  @override
  String get referralBenefits => 'ರೆಫರಲ್ ಪ್ರಯೋಜನಗಳು';

  @override
  String get earnRewards => 'ಬಹುಮಾನಗಳನ್ನು ಗೆಲ್ಲಿ';

  @override
  String get earnRewardsDescription =>
      'ನಿಮ್ಮ ಸ್ನೇಹಿತರು ನಿಮ್ಮ ಕೋಡ್ ಬಳಸಿ ಸೇರಿದಾಗ ವಿಶೇಷ ಬಹುಮಾನಗಳನ್ನು ಪಡೆಯಿರಿ';

  @override
  String get helpFriends => 'ಸ್ನೇಹಿತರಿಗೆ ಸಹಾಯ ಮಾಡಿ';

  @override
  String get helpFriendsDescription =>
      'ನಿಮ್ಮ ಸ್ನೇಹಿತರು ಸೈನ್ ಅಪ್ ಮಾಡಿದಾಗ ವಿಶೇಷ ಬೋನಸ್ ಪಡೆಯುತ್ತಾರೆ';

  @override
  String get unlimitedSharing => 'ಅಪರಿಮಿತ ಹಂಚಿಕೆ';

  @override
  String get unlimitedSharingDescription =>
      'ನಿಮ್ಮ ಕೋಡ್ ಅನ್ನು ಯಾರೊಂದಿಗಾದರೂ ಎಷ್ಟು ಬಾರಿ ಬೇಕಾದರೂ ಹಂಚಿಕೊಳ್ಳಿ';

  @override
  String get trackProgress => 'ಪ್ರಗತಿಯನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಿ';

  @override
  String get trackProgressDescription =>
      'ನಿಮ್ಮ ಪ್ರೊಫೈಲ್‌ನಲ್ಲಿ ನಿಮ್ಮ ರೆಫರಲ್ ಯಶಸ್ಸು ಮತ್ತು ಬಹುಮಾನಗಳನ್ನು ಮಾನಿಟರ್ ಮಾಡಿ';

  @override
  String get howItWorks => 'ಇದು ಹೇಗೆ ಕೆಲಸ ಮಾಡುತ್ತದೆ';

  @override
  String get shareYourCode => 'ನಿಮ್ಮ ಕೋಡ್ ಹಂಚಿಕೊಳ್ಳಿ';

  @override
  String get shareYourCodeDescription =>
      'ನಿಮ್ಮ ರೆಫರಲ್ ಕೋಡ್ ಅಥವಾ ಲಿಂಕ್ ಅನ್ನು ಸ್ನೇಹಿತರು ಮತ್ತು ಕುಟುಂಬದವರಿಗೆ ಕಳುಹಿಸಿ';

  @override
  String get friendSignsUp => 'ಸ್ನೇಹಿತ ಸೈನ್ ಅಪ್ ಮಾಡುತ್ತಾನೆ';

  @override
  String get friendSignsUpDescription =>
      'ಅವರು ನಿಮ್ಮ ರೆಫರಲ್ ಕೋಡ್ ಬಳಸಿ ಖಾತೆ ರಚಿಸುತ್ತಾರೆ';

  @override
  String get bothGetRewards => 'ಇಬ್ಬರೂ ಬಹುಮಾನಗಳನ್ನು ಪಡೆಯುತ್ತಾರೆ';

  @override
  String get bothGetRewardsDescription =>
      'ನೀವು ಮತ್ತು ನಿಮ್ಮ ಸ್ನೇಹಿತ ವಿಶೇಷ ಬೋನಸ್‌ಗಳನ್ನು ಪಡೆಯುತ್ತೀರಿ';

  @override
  String get linkCopiedToClipboard => 'ಲಿಂಕ್ ಕ್ಲಿಪ್‌ಬೋರ್ಡ್‌ಗೆ ಕಾಪಿ ಮಾಡಲಾಗಿದೆ!';

  @override
  String get codeCopiedToClipboard => 'ಕೋಡ್ ಕ್ಲಿಪ್‌ಬೋರ್ಡ್‌ಗೆ ಕಾಪಿ ಮಾಡಲಾಗಿದೆ!';

  @override
  String get referralHelp => 'ರೆಫರಲ್ ಸಹಾಯ';

  @override
  String get referralHelpContent =>
      '• ನಿಮ್ಮ ಅನನ್ಯ ರೆಫರಲ್ ಕೋಡ್ ಅನ್ನು ಸ್ನೇಹಿತರೊಂದಿಗೆ ಹಂಚಿಕೊಳ್ಳಿ\n• ನೀವು ಮತ್ತು ನಿಮ್ಮ ಸ್ನೇಹಿತ ಇಬ್ಬರೂ ಬಹುಮಾನಗಳನ್ನು ಪಡೆಯುತ್ತೀರಿ\n• ನೀವು ಎಷ್ಟು ಸ್ನೇಹಿತರನ್ನು ರೆಫರ್ ಮಾಡಬಹುದು ಎಂಬುದಕ್ಕೆ ಮಿತಿಯಿಲ್ಲ\n• ನಿಮ್ಮ ಪ್ರೊಫೈಲ್‌ನಲ್ಲಿ ನಿಮ್ಮ ರೆಫರಲ್‌ಗಳನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಿ\n• ಬಹುಮಾನಗಳು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಕ್ರೆಡಿಟ್ ಆಗುತ್ತವೆ';

  @override
  String shareMessage(String referralCode, String referralUrl) {
    return '🐄 ನನ್ನೊಂದಿಗೆ ಪಶು ಪರಿವಾರ್‌ನಲ್ಲಿ ಸೇರಿ - ಭಾರತದ ವಿಶ್ವಾಸಾರ್ಹ ಜಾನುವಾರು ಮಾರುಕಟ್ಟೆ! 🐄\n\nಗುಣಮಟ್ಟದ ಪ್ರಾಣಿಗಳನ್ನು ಹುಡುಕಿ, ಪರಿಶೀಲಿತ ಮಾರಾಟಗಾರರೊಂದಿಗೆ ಸಂಪರ್ಕಿಸಿ ಮತ್ತು ಪ್ರೀಮಿಯಂ ವೈಶಿಷ್ಟ್ಯಗಳೊಂದಿಗೆ ನಿಮ್ಮ ಜಾನುವಾರು ವ್ಯಾಪಾರವನ್ನು ಬೆಳೆಸಿ.\n\n✨ ನನ್ನ ರೆಫರಲ್ ಕೋಡ್ ಬಳಸಿ: $referralCode\n🎁 ನಮ್ಮಿಬ್ಬರಿಗೂ ವಿಶೇಷ ಬಹುಮಾನಗಳನ್ನು ಪಡೆಯಿರಿ!\n\nಈಗೇ ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ: $referralUrl\n\n#ಪಶುಪರಿವಾರ್ #ಜಾನುವಾರು #ಕೃಷಿ #ಪ್ರಾಣಿವ್ಯಾಪಾರ';
  }

  @override
  String get termsOfService => 'ಸೇವಾ ನಿಯಮಗಳು';

  @override
  String get privacyPolicy => 'ಗೌಪ್ಯತಾ ನೀತಿ';

  @override
  String get lastUpdated => 'ಕೊನೆಗೆ ನವೀಕರಿಸಲಾಗಿದೆ: ಜುಲೈ 27, 2025';

  @override
  String get acceptanceOfTerms => 'ನಿಯಮಗಳ ಅಂಗೀಕಾರ';

  @override
  String get acceptanceOfTermsContent =>
      'ಪಶು ಕುಟುಂಬವನ್ನು ಪ್ರವೇಶಿಸಿ ಉಪಯೋಗಿಸುವ ಮೂಲಕ, ನೀವು ಈ ಒಪ್ಪಂದದ ನಿಯಮಗಳು ಮತ್ತು ಷರತ್ತುಗಳನ್ನು ಅಂಗೀಕರಿಸುತ್ತೀರಿ ಮತ್ತು ಬದ್ಧರಾಗುತ್ತೀರಿ.';

  @override
  String get useLicense => 'ಬಳಕೆಯ ಪರವಾನಗಿ';

  @override
  String get useLicenseContent =>
      'ವೈಯಕ್ತಿಕ, ವಾಣಿಜ್ಯೇತರ ತಾತ್ಕಾಲಿಕ ವೀಕ್ಷಣೆಗೆ ಪ್ರತಿ ಸಾಧನಕ್ಕೊಂದಷ್ಟು ಪಶು ಕುಟುಂಬವನ್ನು ತಾತ್ಕಾಲಿಕವಾಗಿ ಡೌನ್‌ಲೋಡ್ ಮಾಡುವ ಪರವಾನಗಿ ನೀಡಲಾಗಿದೆ.';

  @override
  String get userResponsibilities => 'ಬಳಕೆದಾರರ ಹೊಣೆಗಾರಿಕೆಗಳು';

  @override
  String get userResponsibilitiesContent =>
      '• ಜಾಹೀರಾತುಗಳನ್ನು ಸೃಷ್ಟಿಸುವಾಗ ಖಚಿತ ಮಾಹಿತಿಯನ್ನು ಒದಗಿಸಿ\n• ಇತರ ಬಳಕೆದಾರರನ್ನು ಗೌರವಿಸಿ ಮತ್ತು ವೃತ್ತಿಪರ ವರ್ತನೆ ಕಾಪಾಡಿ\n• ಎಲ್ಲಾ ಅನ್ವಯಿಸುವ ಕಾನೂನುಗಳು ಮತ್ತು ನಿಯಮಗಳನ್ನು ಪಾಲಿಸಿ\n• ಮೋಸಕಾರಿ ಚಟುವಟಿಕೆಗಳಿಗೆ ವೇದಿಕೆಯನ್ನು ದುರುಪಯೋಗಪಡಿಸಿಕೊಳ್ಳಬೇಡಿ';

  @override
  String get platformServices => 'ವೇದಿಕೆ ಸೇವೆಗಳು';

  @override
  String get platformServicesContent =>
      'ಪಶು ಕುಟುಂಬವು ಖರೀದಿದಾರರು ಮತ್ತು ಮಾರಾಟದವರನ್ನು ಸಂಪರ್ಕಿಸುವ ಪಶು ವ್ಯಾಪಾರದ ವೇದಿಕೆಯನ್ನು ಒದಗಿಸುತ್ತದೆ. ನಾವು ವ್ಯವಹಾರಗಳನ್ನು ಸೌಲಭ್ಯಗೊಳಿಸುತ್ತೇವೆ ಆದರೆ ನೇರವಾಗಿ ಖರೀದಿ/ಮಾರಾಟದಲ್ಲಿ ಭಾಗವಹಿಸದು.';

  @override
  String get accountSecurity => 'ಖಾತೆಯ ಭದ್ರತೆ';

  @override
  String get accountSecurityContent =>
      'ಬಳಕೆದಾರರು ತಮ್ಮ ಖಾತೆ ಮಾಹಿತಿ ಮತ್ತು ಪಾಸ್ವರ್ಡ್‌ನ ರಹಸ್ಯತೆಯನ್ನು ಕಾಪಾಡಲು ಹೊಣೆಗಾರರಾಗಿರುತ್ತಾರೆ. ಯಾವುದೇ ಅನಧಿಕೃತ ಬಳಕೆ ಸಂಭವಿಸಿದರೆ ತಕ್ಷಣ ನಮಗೆ ತಿಳಿಸಿ.';

  @override
  String get paymentTerms => 'ಪಾವತಿ ಷರತ್ತುಗಳು';

  @override
  String get paymentTermsContent =>
      'ಪ್ರೀಮಿಯಂ ಸೇವೆಗಳ ಪಾವತಿಗಳು ಸುರಕ್ಷಿತವಾಗಿ ಪ್ರಕ್ರಿಯೆಗೊಳಿಸಲಾಗುತ್ತವೆ. ಚಂದಾದಾರಿಕೆ ಶುಲ್ಕಗಳು ಹಿಂಪಡೆಯಲಾಗದು, ಹೊರತು ಬೇರೆ ರೀತಿಯಲ್ಲಿ ನಿರ್ಧರಿಸಿದ್ದರೆ.';

  @override
  String get contentGuidelines => 'ವಿಷಯದ ಮಾರ್ಗಸೂಚಿಗಳು';

  @override
  String get contentGuidelinesContent =>
      'ಅಪ್ಲೋಡ್ ಮಾಡಲಾಗುವ ಎಲ್ಲಾ ವಿಷಯವು ಯೋಗ್ಯವಾಗಿರಬೇಕು, ಖಚಿತವಾಗಿರಬೇಕು ಮತ್ತು ನಮ್ಮ ಸಮುದಾಯ ಮಾರ್ಗಸೂಚಿಗಳಿಗೆ ಅನುಗುಣವಾಗಿರಬೇಕು. ಅನರ್ಹ ವಿಷಯವನ್ನು ತೆಗೆದುಹಾಕುವ ಹಕ್ಕುವನ್ನು ನಾವು ಕಾಯ್ದಿರಿಸುತ್ತೇವೆ.';

  @override
  String get limitationOfLiability => 'ಉತ್ತರದಾಯಕತೆಯ ಮಿತಿ';

  @override
  String get limitationOfLiabilityContent =>
      'ಪಶು ಕುಟುಂಬ ಸೇವೆಯ ಬಳಕೆಯಿಂದ ಉಂಟಾಗುವ ಯಾವುದೇ ಪರೋಕ್ಷ, ಆಕಸ್ಮಿಕ, ವಿಶೇಷ, ಅನುಸರಣೆ ಅಥವಾ ದಂಡಾತ್ಮಕ ಹಾನಿಗಳಿಗಾಗಿ ಜವಾಬ್ದಾರಿಯಾಗಿರುವುದಿಲ್ಲ.';

  @override
  String get modifications => 'ಬದಲಾವಣೆಗಳು';

  @override
  String get modificationsContent =>
      'ಈ ನಿಯಮಗಳನ್ನು ಯಾವುದೇ ಸಮಯದಲ್ಲಾದರೂ ನಾವು ಬದಲಾಯಿಸುವ ಹಕ್ಕನ್ನು ಕಾಯ್ದಿರಿಸುತ್ತೇವೆ. ಪ್ರಮುಖ ಬದಲಾವಣೆಗಳನ್ನು ಬಳಕೆದಾರರಿಗೆ ತಿಳಿಸಲಾಗುತ್ತದೆ.';

  @override
  String get contactInformationContent =>
      'ಈ ಸೇವಾ ನಿಯಮಗಳ ಬಗ್ಗೆ ಪ್ರಶ್ನೆಗಳಿದ್ದರೆ, ದಯವಿಟ್ಟು support@pashuparivar.com ಗೆ ಸಂಪರ್ಕಿಸಿ';

  @override
  String get informationWeCollect => 'ನಾವು ಸಂಗ್ರಹಿಸುವ ಮಾಹಿತಿ';

  @override
  String get informationWeCollectContent =>
      '• ವೈಯಕ್ತಿಕ ಮಾಹಿತಿ: ಹೆಸರು, ಫೋನ್ ಸಂಖ್ಯೆ, ಇಮೇಲ್ ವಿಳಾಸ\n• ಪ್ರೊಫೈಲ್ ಮಾಹಿತಿ: ವಿಳಾಸ, ಇಚ್ಛೆಗಳು, ಬಳಕೆದಾರ ಡೇಟಾ\n• ಸಾಧನ ಮಾಹಿತಿ: ಐಪಿ ವಿಳಾಸ, ಬ್ರೌಸರ್ ಪ್ರಕಾರ, ಆಪರೇಟಿಂಗ್ ಸಿಸ್ಟಮ್\n• ಬಳಕೆ ಡೇಟಾ: ಆಪ್ ಸಂವಹನಗಳು, ಉಪಯೋಗಿಸಲಾದ ವೈಶಿಷ್ಟ್ಯಗಳು, ಸೆಷನ್ ಅವಧಿ';

  @override
  String get howWeUseYourInformation =>
      'ನಾವು ನಿಮ್ಮ ಮಾಹಿತಿಯನ್ನು ಹೇಗೆ ಉಪಯೋಗಿಸುತ್ತೇವೆ';

  @override
  String get howWeUseYourInformationContent =>
      'ನಾವು ಸಂಗ್ರಹಿಸಿದ ಮಾಹಿತಿಯನ್ನು ಉಪಯೋಗಿಸುತ್ತೇವೆ:\n• ನಮ್ಮ ಸೇವೆಗಳನ್ನು ಒದಗಿಸಲು ಮತ್ತು ನಿರ್ವಹಿಸಲು\n• ವ್ಯವಹಾರಗಳನ್ನು ಪ್ರಕ್ರಿಯೆಗೊಳಿಸಿ ಮತ್ತು ಅಧಿಸೂಚನೆಗಳನ್ನು ಕಳುಹಿಸಲು\n• ಬಳಕೆದಾರ ಅನುಭವ ಮತ್ತು ಆಪ್ ಕಾರ್ಯಕ್ಷಮತೆಯನ್ನು ಸುಧಾರಿಸಲು\n• ನವೀಕರಣಗಳು ಮತ್ತು ಕೊಡುಗೆಗಳ ಬಗ್ಗೆ ಸಂಪರ್ಕಿಸಲು';

  @override
  String get informationSharing => 'ಮಾಹಿತಿಯ ಹಂಚಿಕೆ';

  @override
  String get informationSharingContent =>
      'ನಾವು ನಿಮ್ಮ ಮಾಹಿತಿಯನ್ನು ಹಂಚಬಹುದು:\n• ಇತರ ಬಳಕೆದಾರರೊಂದಿಗೆ (ಜಾಹೀರಾತುಗಳಲ್ಲಿ ಪ್ರೊಫೈಲ್ ಮಾಹಿತಿ)\n• ನಮ್ಮ ಕಾರ್ಯಾಚರಣೆಗಳಿಗೆ ಸಹಾಯ ಮಾಡುವ ಸೇವಾ ಒದಗونکوೊಂದಿಗೆ\n• ಕಾನೂನು ಪ್ರಕಾರ ಅಥವಾ ನಮ್ಮ ಹಕ್ಕುಗಳನ್ನು ರಕ್ಷಿಸಲು ಬೇಕಾದಾಗ\n• ನಿಮಗೆ ನಿರ್ದಿಷ್ಟ ಉದ್ದೇಶಗಳಿಗಾಗಿ ಸಮ್ಮತಿ ನೀಡಿದಾಗ';

  @override
  String get dataSecurity => 'ಡೇಟಾ ಭದ್ರತೆ';

  @override
  String get dataSecurityContent =>
      'ನಾವು ನಿಮ್ಮ ವೈಯಕ್ತಿಕ ಮಾಹಿತಿಯನ್ನು ಅನಧಿಕೃತ ಪ್ರವೇಶ, ಬದಲಾವಣೆ, ಬಹಿರಂಗಪಡಿಕೆ ಅಥವಾ ನಾಶದಿಂದ ರಕ್ಷಿಸಲು ಸೂಕ್ತ ಭದ್ರತಾ ಕ್ರಮಗಳನ್ನು ಅನುಸರಿಸುತ್ತೇವೆ.';

  @override
  String get dataRetention => 'ಡೇಟಾ ನಿರ್ವಹಣೆ';

  @override
  String get dataRetentionContent =>
      'ಈ ನೀತಿಯಲ್ಲಿರುವ ಉದ್ದೇಶಗಳಿಗೆ ಅಥವಾ ಕಾನೂನುಬದ್ಧ ಅವಶ್ಯಕತೆಗಳಿಗಾಗಿ ಅಗತ್ಯವಿರುವವರೆಗೆ ಮಾತ್ರ ನಿಮ್ಮ ವೈಯಕ್ತಿಕ ಮಾಹಿತಿಯನ್ನು ನಾವು ನಿರ್ವಹಿಸುತ್ತೇವೆ.';

  @override
  String get yourRights => 'ನಿಮ್ಮ ಹಕ್ಕುಗಳು';

  @override
  String get yourRightsContent =>
      'ನೀವು ಹಕ್ಕು ಹೊಂದಿರುವುದು:\n• ನಿಮ್ಮ ವೈಯಕ್ತಿಕ ಮಾಹಿತಿಯನ್ನು ಪ್ರವೇಶಿಸಲು\n• ತಪ್ಪಾದ ಮಾಹಿತಿಯನ್ನು ಸರಿಪಡಿಸಲು\n• ನಿಮ್ಮ ಖಾತೆ ಮತ್ತು ಡೇಟಾವನ್ನು ಅಳಿಸಲು\n• ಮಾರ್ಕೆಟಿಂಗ್ ಸಂವಹನಗಳಿಂದ ಹೊರಹೊಮ್ಮಲು';

  @override
  String get cookiesAndTracking => 'ಕುಕಿಗಳು ಮತ್ತು ಟ್ರ್ಯಾಕಿಂಗ್';

  @override
  String get cookiesAndTrackingContent =>
      'ನಾವು ನಿಮ್ಮ ಅನುಭವವನ್ನು ಹೆಚ್ಚಿಸಲು, ಉಪಯೋಗದ ನಮೂನೆಗಳನ್ನು ವಿಶ್ಲೇಷಿಸಲು ಮತ್ತು ವೈಯಕ್ತಿಕಗೊಳಿಸಿದ ವಿಷಯವನ್ನು ಒದಗಿಸಲು ಕುಕಿಗಳು ಮತ್ತು ಸಮಾನ ತಂತ್ರಜ್ಞಾನಗಳನ್ನು ಬಳಸುತ್ತೇವೆ.';

  @override
  String get thirdPartyServices => 'ಮೂರನೇ ಪಕ್ಷದ ಸೇವೆಗಳು';

  @override
  String get thirdPartyServicesContent =>
      'ನಮ್ಮ ಆಪ್‌ನಲ್ಲಿ ಮೂರನೇ ಪಕ್ಷದ ಸೇವೆಗಳಿಗೆ ಲಿಂಕುಗಳು ಇರಬಹುದು. ಅವರ ಗೌಪ್ಯತಾ ಕ್ರಮಗಳಿಗೆ ನಾವು ಜವಾಬ್ದಾರರಾಗಿರುವುದಿಲ್ಲ.';

  @override
  String get childrensPrivacy => 'ಮಕ್ಕಳ ಗೌಪ್ಯತೆ';

  @override
  String get childrensPrivacyContent =>
      'ನಮ್ಮ ಸೇವೆ 13 ವರ್ಷಕ್ಕಿಂತ ಕಡಿಮೆ ವಯಸ್ಸಿನ ಮಕ್ಕಳಿಗಾಗಿ ಉದ್ದೇಶಿತವಲ್ಲ. ನಾವು ಆ ವಯಸ್ಸಿನ ಮಕ್ಕಳಿಂದ ವೈಯಕ್ತಿಕ ಮಾಹಿತಿಯನ್ನು ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿ ಸಂಗ್ರಹಿಸುವುದಿಲ್ಲ.';

  @override
  String get changesToThisPolicy => 'ಈ ನೀತಿಯಲ್ಲಿ ಬದಲಾವಣೆಗಳು';

  @override
  String get changesToThisPolicyContent =>
      'ನಾವು ಈ ಗೌಪ್ಯತಾ ನೀತಿಯನ್ನು ಸಮಯಮಾನಕ್ಕೆ ಅನುಗುಣವಾಗಿ ನವೀಕರಿಸಬಹುದು. ಯಾವುದೇ ಬದಲಾವಣೆಗಳ ಬಗ್ಗೆ ನಾವು ಈ ಪುಟದಲ್ಲಿ ಹೊಸ ನೀತಿಯನ್ನು ಪೋಸ್ಟ್ ಮಾಡುವ ಮೂಲಕ ನಿಮಗೆ ತಿಳಿಸುತ್ತೇವೆ.';

  @override
  String get privacyContactContent =>
      'ಈ ಗೌಪ್ಯತಾ ನೀತಿಯ ಬಗ್ಗೆ ಪ್ರಶ್ನೆಗಳಿದ್ದರೆ, ದಯವಿಟ್ಟು ಈ ವಿಳಾಸಕ್ಕೆ ಸಂಪರ್ಕಿಸಿ:\nಇಮೇಲ್: privacy@pashuparivar.com\nದೂರವಾಣಿ: +91-XXXXXXXXXX';
}
