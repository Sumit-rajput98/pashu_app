// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Malayalam (`ml`).
class AppLocalizationsMl extends AppLocalizations {
  AppLocalizationsMl([String locale = 'ml']) : super(locale);

  @override
  String get welcome => 'പശു പരിവാരത്തിലേക്ക് സ്വാഗതം';

  @override
  String get locationPermissionTitle => 'സ്ഥലം അനുമതി';

  @override
  String get locationPermissionMessage =>
      'ആപ്പിനും നിങ്ങളുടെ സ്ഥലവും ലഭ്യമാക്കണം.';

  @override
  String get permissionDenied => 'അനുമതി നിഷേധിച്ചു';

  @override
  String get permissionRetryMessage =>
      'സ്ഥലത്തിന്റെ അനുമതി ആവശ്യമാണ്. വീണ്ടും ശ്രമിക്കണോ?';

  @override
  String get yes => 'അതെ';

  @override
  String get no => 'ഇല്ല';

  @override
  String get hi => 'ഹലോ';

  @override
  String get newAnimal => 'പുതിയ കന്നുകാലി';

  @override
  String get newBuyers => 'പുതിയ വാങ്ങുന്നവർ';

  @override
  String get buyAnimal => 'കന്നുകാലി വാങ്ങുക';

  @override
  String get sellAnimal => 'കന്നുകാലി വിൽക്കുക';

  @override
  String get otherServices => 'മറ്റു സേവനങ്ങൾ';

  @override
  String get knowMore => 'കൂടുതൽ അറിയുക';

  @override
  String get clicklive => 'ലൈവിൽ കാണുക';

  @override
  String get insurance => 'ഇൻഷുറൻസ്';

  @override
  String get health => 'ആരോഗ്യം';

  @override
  String get liverace => 'ലൈവ് റേസുകൾ';

  @override
  String get feed => 'തീവനം';

  @override
  String get getLocation => 'സ്ഥലം നേടുക';

  @override
  String get getLocationMessage => 'നിങ്ങളുടെ പശുവിനായി സ്ഥലം നേടുക 📍';

  @override
  String get comingSoon => 'ಶೀಘ್ರದಲ್ಲೇ ಬರುತ್ತಿದೆ';

  @override
  String get firstUsers => 'ആദ്യ 10,000 ഉപയോക്താക്കൾക്ക് ലഭിക്കും';

  @override
  String get referralBonusOnly => 'റഫറൽ ബോണസ് – വെറും';

  @override
  String slotsLeft(Object slot) {
    return 'സ്ഥലങ്ങൾ ശേഷിക്കുന്നു!';
  }

  @override
  String get applyNow => 'ഇപ്പോൾ അപേക്ഷിക്കുക';

  @override
  String get pashuLoan => 'പശു വായ്പ';

  @override
  String get pashuInsurance => 'പശു ഇൻഷുറൻസ്';

  @override
  String get investInFarming => 'കൃഷിയിൽ നിക്ഷേപിക്കുക';

  @override
  String get growWealth => 'പ്രകൃതിയോടൊപ്പം നിങ്ങളുടെ സമ്പത്ത് വളർത്തുക';

  @override
  String get startInvesting => 'നിക്ഷേപിക്കാൻ ആരംഭിക്കുക';

  @override
  String get editProfile => 'പ്രൊഫൈൽ എഡിറ്റ് ചെയ്യുക';

  @override
  String get animalHistory => 'മൃഗ പട്ടിക ചരിത്രം';

  @override
  String get referralCode => 'റഫറൽ കോഡ്';

  @override
  String get logout => 'ലോഗൗട്ട്';

  @override
  String get yourListedPashu => 'നിങ്ങളുടെ ലിസ്റ്റ് ചെയ്ത പശുക്കൾ';

  @override
  String get termsPrivacy => 'നിബന്ധനകളും സ്വകാര്യതയും';

  @override
  String get contactUs => 'ഞങ്ങളെ ബന്ധപ്പെടുക';

  @override
  String get account => 'അക്കൗണ്ട്';

  @override
  String get soldOutPashuHistory => 'വിറ്റുതീർന്ന പശു ചരിത്രം';

  @override
  String get walletBalance => 'വാലറ്റ് ബാലൻസ്';

  @override
  String get addAmountInWallet => 'വാലറ്റിൽ തുക ചേർക്കുക';

  @override
  String get myTransaction => 'എന്റെ ഇടപാട്';

  @override
  String get addMoneyToWallet => 'നിങ്ങളുടെ വാലറ്റിലേക്ക് പണം ചേർക്കുക';

  @override
  String get enterAmount => 'തുക നൽകുക';

  @override
  String get enterAmountExample => 'ഉദാഹരണം: 500 നൽകുക';

  @override
  String get add => 'ചേർക്കുക';

  @override
  String get walletTip =>
      'സൂചന: നിങ്ങളുടെ വാലറ്റ് ഉടനടി കോൺടാക്റ്റ് വിവരങ്ങൾ കാണാൻ ഉപയോഗിക്കാം.';

  @override
  String get getVerifiedPashu => 'നിങ്ങളുടെ പശുവിനെ സ്ഥിരീകരിക്കുക';

  @override
  String get withdrawBalance => 'ബാലൻസ് പിൻവലിക്കുക';

  @override
  String get signIn => 'സൈൻ ഇൻ';

  @override
  String get enterPhoneNumberToContinue =>
      'തുടരുന്നതിന് നിങ്ങളുടെ ഫോൺ നമ്പർ നൽകുക';

  @override
  String get phoneNumber => 'ഫോൺ നമ്പർ';

  @override
  String get enterPhoneNumber => 'ഫോൺ നമ്പർ നൽകുക';

  @override
  String get sendOTP => 'ഒടിപി അയയ്ക്കുക';

  @override
  String get or => 'അല്ലെങ്കിൽ';

  @override
  String get dontHaveAccount => 'അക്കൗണ്ട് ഇല്ലേ? ഇപ്പോൾ രജിസ്റ്റർ ചെയ്യുക';

  @override
  String get phoneNumberRequired => 'ഫോൺ നമ്പർ ആവശ്യമാണ്';

  @override
  String get enterValidPhoneNumber => 'സാധുവായ 10 അക്ക ഇന്ത്യൻ ഫോൺ നമ്പർ നൽകുക';

  @override
  String otpSentTo(Object phoneNumber) {
    return 'ഒടിപി +91 $phoneNumber ലേക്ക് അയച്ചു';
  }

  @override
  String get register => 'രജിസ്റ്റർ';

  @override
  String get login => 'ലോഗിൻ';

  @override
  String get registerNow => 'ഇപ്പോൾ രജിസ്റ്റർ ചെയ്യുക';

  @override
  String get enterYourName => 'നിങ്ങളുടെ പേര് നൽകുക';

  @override
  String get enterReferralCode => 'റഫറൽ കോഡ് നൽകുക (ഓപ്ഷണൽ)';

  @override
  String get getOTP => 'ഒടിപി നേടുക';

  @override
  String get alreadyHaveAccount => 'ഇതിനകം അക്കൗണ്ട് ഉണ്ടോ? സൈൻ ഇൻ ചെയ്യുക';

  @override
  String get optional => 'ഓപ്ഷണൽ';

  @override
  String get nameIsRequired => 'പേര് ആവശ്യമാണ്';

  @override
  String get nameMinLength => 'പേര് കുറഞ്ഞത് 2 അക്ഷരങ്ങൾ ആയിരിക്കണം';

  @override
  String get failedToSendOTP =>
      'ഒടിപി അയയ്ക്കുന്നതിൽ പരാജയപ്പെട്ടു. വീണ്ടും ശ്രമിക്കുക.';

  @override
  String get enterOTP => 'ഒടിപി നൽകുക';

  @override
  String otpSentMessage(Object phoneNumber) {
    return 'ഞങ്ങൾ +91 $phoneNumber ലേക്ക് 6 അക്ക ഒടിപി അയച്ചിട്ടുണ്ട്';
  }

  @override
  String get enterComplete6DigitOTP => 'ദയവായി പൂർണ്ണമായ 6 അക്ക ഒടിപി നൽകുക';

  @override
  String get successfulLogin => 'വിജയകരമായ ലോഗിൻ';

  @override
  String get didntReceiveOTP => 'ഒടിപി കിട്ടിയില്ലേ?';

  @override
  String resendIn(Object seconds) {
    return '$seconds സെക്കൻഡിൽ വീണ്ടും അയയ്ക്കുക';
  }

  @override
  String get resendOTP => 'ഒടിപി വീണ്ടും അയയ്ക്കുക';

  @override
  String get resending => 'വീണ്ടും അയയ്ക്കുന്നു...';

  @override
  String otpResentTo(Object phoneNumber) {
    return 'ഒടിപി +91 $phoneNumber ലേക്ക് വീണ്ടും അയച്ചു';
  }

  @override
  String get failedToResendOTP =>
      'ഒടിപി വീണ്ടും അയയ്ക്കുന്നതിൽ പരാജയപ്പെട്ടു. വീണ്ടും ശ്രമിക്കുക.';

  @override
  String get homeScreen => 'ഹോം';

  @override
  String get welcomeToHomeScreen => 'ഹോം സ്ക്രീനിലേക്ക് സ്വാഗതം!';

  @override
  String get newBadge => 'പുതിയത്';

  @override
  String get logoutConfirmation =>
      'നിങ്ങൾക്ക് നിങ്ങളുടെ അക്കൗണ്ടിൽ നിന്ന് ലോഗ് ഔട്ട് ചെയ്യാൻ ഉറപ്പാണോ?';

  @override
  String get cancel => 'റദ്ദാക്കുക';

  @override
  String get failedToLoadProfile => 'പ്രൊഫൈൽ ലോഡ് ചെയ്യുന്നതിൽ പരാജയപ്പെട്ടു';

  @override
  String get uploadPashuImageOne =>
      'നിങ്ങളുടെ പശു ചിത്രം ഒന്ന് അപ്‌ലോഡ് ചെയ്യുക';

  @override
  String get selectPictureOne => 'ചിത്രം ഒന്ന് തിരഞ്ഞെടുക്കുക';

  @override
  String get uploadPashuImageTwo =>
      'നിങ്ങളുടെ പശു ചിത്രം രണ്ട് അപ്‌ലോഡ് ചെയ്യുക';

  @override
  String get selectPictureTwo => 'ചിത്രം രണ്ട് തിരഞ്ഞെടുക്കുക';

  @override
  String get paymentCompletedSuccessfully =>
      'പേയ്‌മെന്റ് വിജയകരമായി പൂർത്തിയായി!';

  @override
  String get paymentVerificationFailed =>
      'പേയ്‌മെന്റ് സ്ഥിരീകരണം പരാജയപ്പെട്ടു. ദയവായി വീണ്ടും ശ്രമിക്കുക.';

  @override
  String get errorVerifyingPayment => 'പേയ്മെന്റ് സ്ഥിരീകരിക്കുന്നതിൽ പിശക്';

  @override
  String get insuranceApplication => 'ഇൻഷുറൻസ് അപേക്ഷ';

  @override
  String get responseReceived => 'പ്രതികരണം ലഭിച്ചു!';

  @override
  String get insuranceThankYouMessage =>
      'നിങ്ങളുടെ പശു ഇൻഷുറൻസ് അപേക്ഷ സമർപ്പിച്ചതിന് നന്ദി. കൂടുതൽ വിവരങ്ങൾക്കായി ഞങ്ങളുടെ ടീം ഉടൻ തന്നെ നിങ്ങളുമായി ബന്ധപ്പെടും.';

  @override
  String get selectLanguage => 'ഭാഷ തിരഞ്ഞെടുക്കുക';

  @override
  String get ok => 'ശരി';

  @override
  String get appTitle => 'പശു കുടുംബം';

  @override
  String get languageShort => 'हि/E/ತ';

  @override
  String get wishlist => 'വിഷ്‌ലിസ്റ്റ്';

  @override
  String get loanFormTitle => 'പശു വായ്പ ഫോം';

  @override
  String get loanApplicationHeader => 'പശു വായ്പ അപേക്ഷ';

  @override
  String get loanApplicationSubheader =>
      'നിങ്ങളുടെ കന്നുകാലി കൃഷി ആവശ്യങ്ങൾക്കായി സാമ്പത്തിക സഹായം നേടുക';

  @override
  String get loanApplicationDetails => 'വായ്പ അപേക്ഷ വിശദാംശങ്ങൾ';

  @override
  String get applicantInformation => 'അപേക്ഷകന്റെ വിവരങ്ങൾ';

  @override
  String get applicantName => 'അപേക്ഷകന്റെ പേര്';

  @override
  String get applicantNameRequired => 'അപേക്ഷകന്റെ പേര് ആവശ്യമാണ്';

  @override
  String get applicantAddress => 'അപേക്ഷകന്റെ വിലാസം';

  @override
  String get applicantAddressRequired => 'അപേക്ഷകന്റെ വിലാസം ആവശ്യമാണ്';

  @override
  String get contactNumber => 'ബന്ധപ്പെടാനുള്ള നമ്പർ';

  @override
  String get contactNumberRequired => 'ബന്ധപ്പെടാനുള്ള നമ്പർ ആവശ്യമാണ്';

  @override
  String get contactNumberInvalid => 'ദയവായി സാധുവായ നമ്പർ നൽകുക';

  @override
  String get emailAddress => 'ഇമെയിൽ വിലാസം';

  @override
  String get emailAddressRequired => 'ഇമെയിൽ വിലാസം ആവശ്യമാണ്';

  @override
  String get emailAddressInvalid => 'ദയവായി സാധുവായ ഇമെയിൽ വിലാസം നൽകുക';

  @override
  String get loanInformation => 'വായ്പ വിവരങ്ങൾ';

  @override
  String get loanAmount => 'വായ്പ തുക (₹)';

  @override
  String get loanAmountRequired => 'വായ്പ തുക ആവശ്യമാണ്';

  @override
  String get loanAmountInvalid => 'ദയവായി സാധുവായ വായ്പ തുക നൽകുക';

  @override
  String get repaymentPeriod => 'തിരികെ നൽകുന്ന കാലയളവ്';

  @override
  String get repaymentPeriodRequired => 'തിരികെ നൽകുന്ന കാലയളവ് ആവശ്യമാണ്';

  @override
  String get incomeSource => 'വരുമാന ഉറവിടം';

  @override
  String get incomeSourceRequired => 'വരുമാന ഉറവിടം ആവശ്യമാണ്';

  @override
  String get purposeOfLoan => 'വായ്പയുടെ ഉദ്ദേശ്യം';

  @override
  String get purposeOfLoanRequired => 'വായ്പയുടെ ഉദ്ദേശ്യം ആവശ്യമാണ്';

  @override
  String get additionalInformation => 'കൂടുതൽ വിവരങ്ങൾ';

  @override
  String get additionalRemarks => 'കൂടുതൽ അഭിപ്രായങ്ങൾ';

  @override
  String get additionalRemarksRequired => 'കൂടുതൽ അഭിപ്രായങ്ങൾ ആവശ്യമാണ്';

  @override
  String get submittingForm => 'ഫോം സമർപ്പിക്കുന്നു...';

  @override
  String get submitForm => 'ഫോം സമർപ്പിക്കുക';

  @override
  String get loanTermsNote =>
      'ഈ ഫോം സമർപ്പിക്കുന്നതിലൂടെ, നിങ്ങൾ ഞങ്ങളുടെ വായ്പ നിബന്ധനകൾ അംഗീകരിക്കുന്നു. ഞങ്ങളുടെ ടീം നിങ്ങളുടെ അപേക്ഷ പരിശോധിച്ച് 3-5 ബിസിനസ് ദിവസങ്ങളിൽ വായ്പ അംഗീകൃത നിലയുമായി ബന്ധപ്പെടും.';

  @override
  String get allFieldsRequired => 'എല്ലാ ഫീൽഡുകളും ആവശ്യമാണ്';

  @override
  String get animalInformation => 'മൃഗത്തിന്റെ വിവരങ്ങൾ';

  @override
  String get animalAgeInvalid => 'ദയവായി സാധുവായ മൃഗ പ്രായം നൽകുക';

  @override
  String get animalWeightInvalid => 'ദയവായി സാധുവായ മൃഗ ഭാരം നൽകുക';

  @override
  String get allowLocationAccess => 'സ്ഥലത്തേക്ക് പ്രവേശനം അനുവദിക്കുക';

  @override
  String get locationDescription =>
      'നിങ്ങളുടെ പ്രദേശത്തെ സമീപമുള്ള കന്നുകാലികൾ, ഇവന്റുകൾ, വ്യക്തിഗത ഉള്ളടക്കം എന്നിവ കാണിക്കാൻ നിങ്ങളുടെ സ്ഥലം ആവശ്യമാണ്.';

  @override
  String get locationPrivacyNote =>
      'നിങ്ങളുടെ സ്ഥലം ഡാറ്റ സുരക്ഷിതമാണ്, നിങ്ങളുടെ അനുഭവം മെച്ചപ്പെടുത്താൻ മാത്രം ഉപയോഗിക്കുന്നു.';

  @override
  String get liveRaces => 'ലൈവ് റേസുകൾ';

  @override
  String get viewLive => 'ലൈവ് കാണുക';

  @override
  String get animalInsurance => 'കന്നുകാലി ഇൻഷുറൻസ്';

  @override
  String get insuranceFormTitle => 'കന്നുകാലി ഇൻഷുറൻസ് ഫോം';

  @override
  String get insuranceApplicationHeader => 'കന്നുകാലി ഇൻഷുറൻസ് അപേക്ഷ';

  @override
  String get insuranceApplicationSubheader =>
      'നിങ്ങളുടെ കന്നുകാലി ഇൻഷുറൻസ് ആവശ്യങ്ങൾക്കായി സാമ്പത്തിക സഹായം നേടുക';

  @override
  String get insuranceApplicationDetails => 'ഇൻഷുറൻസ് അപേക്ഷ വിശദാംശങ്ങൾ';

  @override
  String get ownerInformation => 'ഉടമയുടെ വിവരം';

  @override
  String get ownerName => 'ഉടമയുടെ പേര്';

  @override
  String get ownerNameRequired => 'ഉടമയുടെ പേര് ആവശ്യമാണ്';

  @override
  String get ownerAddress => 'ഉടമയുടെ വിലാസം';

  @override
  String get ownerAddressRequired => 'ഉടമയുടെ വിലാസം ആവശ്യമാണ്';

  @override
  String get animalType => 'കന്നുകാലി തരം';

  @override
  String get animalTypeRequired => 'കന്നുകാലി തരം ആവശ്യമാണ്';

  @override
  String get animalBreed => 'കന്നുകാലി ഇനം';

  @override
  String get animalBreedRequired => 'കന്നുകാലി ഇനം ആവശ്യമാണ്';

  @override
  String get animalAge => 'കന്നുകാലി പ്രായം';

  @override
  String get animalAgeRequired => 'കന്നുകാലി പ്രായം ആവശ്യമാണ്';

  @override
  String get animalColor => 'കന്നുകാലി നിറം';

  @override
  String get animalColorRequired => 'കന്നുകാലി നിറം ആവശ്യമാണ്';

  @override
  String get animalWeight => 'കന്നുകാലി ഭാരം';

  @override
  String get animalWeightRequired => 'കന്നുകാലി ഭാരം ആവശ്യമാണ്';

  @override
  String get healthStatus => 'ആരോഗ്യ നില';

  @override
  String get healthStatusRequired => 'ആരോഗ്യ നില ആവശ്യമാണ്';

  @override
  String get insuranceTermsNote =>
      'ഈ ഫോം സമർപ്പിക്കുന്നതിലൂടെ, നിങ്ങൾ ഞങ്ങളുടെ ഇൻഷുറൻസ് നിബന്ധനകൾ അംഗീകരിക്കുന്നു. ഞങ്ങളുടെ ടീം നിങ്ങളുടെ അപേക്ഷ പരിശോധിച്ച് 3-5 ബിസിനസ് ദിവസങ്ങളിൽ ഇൻഷുറൻസ് അംഗീകൃത നിലയുമായി ബന്ധപ്പെടും.';

  @override
  String get liveRaceTitle => 'ലൈവ് റേസ്';

  @override
  String get liveRaceHeader => 'ലൈവ് റേസ്';

  @override
  String get chooseRaceCategory => 'നിങ്ങളുടെ റേസ് വിഭാഗം തിരഞ്ഞെടുക്കുക';

  @override
  String get raceExperienceSubheader =>
      'പരമ്പരാഗത മൃഗ ഓട്ടത്തിന്റെ ആവേശം അനുഭവിക്കുക';

  @override
  String get raceCategoryFallback => 'റേസ് വിഭാഗം';

  @override
  String get raceCategoryDetailFallback =>
      'ഉത്സാഹകരമായ റേസിൽ ചേരുക, പരമ്പരാഗത മൃഗ ഓട്ടത്തിന്റെ ആവേശം അനുഭവിക്കുക';

  @override
  String get liveNow => 'ಈಗ ಲೈವ್';

  @override
  String get tapToJoin => 'ചേരാൻ ടാപ്പ് ചെയ്യുക';

  @override
  String get liveBadge => 'ലൈവ്';

  @override
  String get failedToLoadCategories =>
      'വിഭാഗങ്ങൾ ലോഡ് ചെയ്യുന്നതിൽ പരാജയപ്പെട്ടു';

  @override
  String get somethingWentWrong => 'എന്തോ തെറ്റ് സംഭവിച്ചു';

  @override
  String get retry => 'വീണ്ടും ശ്രമിക്കുക';

  @override
  String get noLiveRacesAvailable => 'ലൈവ് റേസുകൾ ലഭ്യമല്ല';

  @override
  String get checkBackLater =>
      'ഉത്സാഹകരമായ ലൈവ് റേസിംഗ് ഇവന്റുകൾക്കായി പിന്നീട് പരിശോധിക്കുക';

  @override
  String get raceCategory => 'ರೇಸ್ ವರ್ಗ';

  @override
  String get traditionalRacingExperience => 'ಸಾಂಪ್ರದಾಯಿಕ ರೇಸಿಂಗ್ ಅನುಭವ';

  @override
  String get raceInformation => 'ರೇಸ್ ಮಾಹಿತಿ';

  @override
  String get category => 'വിഭാഗം';

  @override
  String get status => 'ಸ್ಥಿತಿ';

  @override
  String get participants => 'ಭಾಗವಹಿಸುವವರು';

  @override
  String get multipleEntries => 'ಅನೇಕ ನಮೂದುಗಳು';

  @override
  String get duration => 'കാലയളവ്';

  @override
  String get ongoing => 'ನಡೆಯುತ್ತಿರುವ';

  @override
  String get prize => 'ಬಹುಮಾನ';

  @override
  String get trophiesAndRecognition => 'ಟ್ರೋಫಿಗಳು ಮತ್ತು ಗುರುತಿಸುವಿಕೆ';

  @override
  String get raceIsLiveNow => 'ರೇಸ್ ಈಗ ಲೈವ್!';

  @override
  String get watchExcitingCompetition => 'ಉತ್ತೇಜಕ ಸ್ಪರ್ಧೆಯನ್ನು ವೀಕ್ಷಿಸಿ';

  @override
  String get aboutThisRace => 'ಈ ರೇಸ್ ಬಗ್ಗೆ';

  @override
  String get defaultRaceDescription =>
      'ಈ ಉತ್ತೇಜಕ ಲೈವ್ ಈವೆಂಟ್‌ನಲ್ಲಿ ಸಾಂಪ್ರದಾಯಿಕ ಪ್ರಾಣಿ ರೇಸಿಂಗ್‌ನ ರೋಮಾಂಚನವನ್ನು ಅನುಭವಿಸಿ. ಮನುಷ್ಯರು ಮತ್ತು ಪ್ರಾಣಿಗಳ ನಡುವಿನ ಬಂಧವನ್ನು ತೋರಿಸುವ ಈ ಕಾಲಾತೀತ ಸಂಪ್ರದಾಯದಲ್ಲಿ ಕುಶಲ ಭಾಗವಹಿಸುವವರು ಸ್ಪರ್ಧಿಸುವುದನ್ನು ವೀಕ್ಷಿಸಿ.';

  @override
  String get liveStream => 'ಲೈವ್ ಸ್ಟ್ರೀಮ್';

  @override
  String get liveStreamComingSoon => 'ಲೈವ್ ಸ್ಟ್ರೀಮ್ ಶೀಘ್ರದಲ್ಲೇ ಬರುತ್ತಿದೆ';

  @override
  String get youtubeLinksAvailable =>
      'ಸ್ಟ್ರೀಮಿಂಗ್ ಪ್ರಾರಂಭವಾದಾಗ YouTube ಲಿಂಕ್‌ಗಳು ಲಭ್ಯವಿರುತ್ತವೆ';

  @override
  String get getNotifiedWhenStreaming =>
      'ಈ ರೇಸ್ ವರ್ಗಕ್ಕಾಗಿ ಲೈವ್ ಸ್ಟ್ರೀಮಿಂಗ್ ಪ್ರಾರಂಭವಾದಾಗ ಅಧಿಸೂಚನೆ ಪಡೆಯಿರಿ';

  @override
  String get liveRace => 'ಲೈವ್ ರೇಸ್';

  @override
  String get na => 'ಲಭ್ಯವಿಲ್ಲ';

  @override
  String get regionalChampionship => 'ಪ್ರಾದೇಶಿಕ ಚಾಂಪಿಯನ್‌ಶಿಪ್';

  @override
  String get districtFinals => 'ಜಿಲ್ಲಾ ಫೈನಲ್‌ಗಳು';

  @override
  String get stateCompetition => 'ರಾಜ್ಯ ಸ್ಪರ್ಧೆ';

  @override
  String get tomorrowTenAM => 'ನಾಳೆ ಬೆಳಿಗ್ಗೆ 10:00 ಗಂಟೆಗೆ';

  @override
  String get nextWeek => 'ಮುಂದಿನ ವಾರ';

  @override
  String get sellPashu => 'പശു വിൽക്കുക';

  @override
  String get youCanProceedWithListing =>
      'നിങ്ങൾക്ക് ലിസ്റ്റിംഗുമായി മുന്നോട്ട് പോകാം';

  @override
  String get minimumRequiredToList =>
      'നിങ്ങളുടെ മൃഗത്തെ ലിസ്റ്റ് ചെയ്യാൻ കുറഞ്ഞത് ₹15 ആവശ്യമാണ്';

  @override
  String get animalTypes => 'മൃഗങ്ങളുടെ തരങ്ങൾ';

  @override
  String get selectAnimalType => 'മൃഗത്തിന്റെ തരം തിരഞ്ഞെടുക്കുക';

  @override
  String get animalCategory => 'മൃഗ വിഭാഗം';

  @override
  String get pleaseSelectAnimalTypeFirst =>
      'ദയവായി ആദ്യം മൃഗത്തിന്റെ തരം തിരഞ്ഞെടുക്കുക';

  @override
  String get selectAnimalCategory => 'മൃഗ വിഭാഗം തിരഞ്ഞെടുക്കുക';

  @override
  String get nameOfTheAnimal => 'മൃഗത്തിന്റെ പേര്';

  @override
  String get enterAnimalAge => 'മൃഗത്തിന്റെ പ്രായം നൽകുക';

  @override
  String get selectGenderOfAnimal => 'മൃഗത്തിന്റെ ലിംഗം തിരഞ്ഞെടുക്കുക';

  @override
  String get price => 'വില';

  @override
  String get negotiable => 'വിലപേശാവുന്ന';

  @override
  String get isPriceNegotiable => 'വില വിലപേശാവുന്നതാണോ?';

  @override
  String get yourPhoneNumber => 'നിങ്ങളുടെ ഫോൺ നമ്പർ';

  @override
  String get enterYourPhoneNumber => 'നിങ്ങളുടെ ഫോൺ നമ്പർ നൽകുക';

  @override
  String get animalDescription => 'മൃഗത്തിന്റെ വിവരണം';

  @override
  String get enterAnimalDescription => 'മൃഗത്തിന്റെ വിവരണം നൽകുക';

  @override
  String get getAddressForPashu => 'പശുവിനുള്ള വിലാസം നേടുക';

  @override
  String get submitAndPay => 'സമർപ്പിച്ച് ₹15 പേയ് ചെയ്യുക';

  @override
  String get insufficientBalance =>
      'അപര്യാപ്തമായ ബാലൻസ്. ദയവായി ഫണ്ട് ചേർക്കുക.';

  @override
  String get submitting => 'സമർപ്പിക്കുന്നു...';

  @override
  String get locationServicesDisabled =>
      'ലൊക്കേഷൻ സേവനങ്ങൾ പ്രവർത്തനരഹിതമാക്കിയിരിക്കുന്നു';

  @override
  String get locationPermissionPermanentlyDenied =>
      'ലൊക്കേഷൻ അനുമതി സ്ഥിരമായി നിഷേധിച്ചു';

  @override
  String get locationPermissionDenied => 'ലൊക്കേഷൻ അനുമതി നിഷേധിച്ചു';

  @override
  String get unableToDetermineAddress => 'വിലാസം നിർണ്ണയിക്കാൻ കഴിയുന്നില്ല';

  @override
  String get error => 'പിശക്';

  @override
  String get missingRequiredFields => 'ആവശ്യമായ ഫീൽഡുകൾ കാണുന്നില്ല';

  @override
  String get pleaseEnterValidPhoneNumber => 'ദയവായി സാധുവായ ഫോൺ നമ്പർ നൽകുക';

  @override
  String get pleaseEnterValidAge => 'ദയവായി സാധുവായ പ്രായം നൽകുക';

  @override
  String get pleaseEnterValidPrice => 'ദയവായി സാധുവായ വില നൽകുക';

  @override
  String get pashuListedSuccessfully => 'പശു വിജയകരമായി ലിസ്റ്റ് ചെയ്തു!';

  @override
  String get errorOccurred => 'ഒരു പിശക് സംഭവിച്ചു';

  @override
  String get selectCategory => 'വിഭാഗം തിരഞ്ഞെടുക്കുക';

  @override
  String get selectGender => 'ലിംഗം തിരഞ്ഞെടുക്കുക';

  @override
  String get male => 'ആൺ';

  @override
  String get female => 'പെൺ';

  @override
  String get user => 'ഉപയോക്താവ്';

  @override
  String get other => 'മറ്റുള്ളവ';

  @override
  String get unknown => 'അജ്ഞാതം';

  @override
  String get traditionalSportsAnimal => 'പരമ്പരാഗത കായിക മൃഗം';

  @override
  String get livestockAnimal => 'കന്നുകാലി മൃഗം';

  @override
  String get petAnimal => 'വളർത്തുമൃഗം';

  @override
  String get farmHouseAnimal => 'ഫാം ഹൗസ് മൃഗം';

  @override
  String get bull => 'കാള';

  @override
  String get camel => 'ഒട്ടകം';

  @override
  String get bird => 'പക്ഷി';

  @override
  String get pigeon => 'പ്രാവ്';

  @override
  String get cock => 'കോഴി';

  @override
  String get dog => 'നായ്';

  @override
  String get goat => 'ആട്';

  @override
  String get horse => 'കുതിര';

  @override
  String get buffalo => 'എരുമ';

  @override
  String get sheep => 'ആട്';

  @override
  String get pigs => 'പന്നികൾ';

  @override
  String get cat => 'പൂച്ച';

  @override
  String get fishes => 'മത്സ്യങ്ങൾ';

  @override
  String get smallMammals => 'ചെറിയ സസ്തനികൾ';

  @override
  String get searchAnimalsBreeds => 'മൃഗങ്ങളെ, ഇനങ്ങളെ തിരയുക...';

  @override
  String get unknownAnimal => 'അജ്ഞാത മൃഗം';

  @override
  String get breed => 'ഇനം';

  @override
  String get owner => 'ഉടമ';

  @override
  String get callMe => 'എന്നെ വിളിക്കൂ';

  @override
  String get buyNow => 'ഇപ്പോൾ വാങ്ങുക';

  @override
  String get addedToWishlist => 'വിഷ്‌ലിസ്റ്റിൽ ചേർത്തു';

  @override
  String get animal => 'മൃഗം';

  @override
  String get failedToAddToWishlist =>
      'വിഷ്‌ലിസ്റ്റിൽ ചേർക്കുന്നതിൽ പരാജയപ്പെട്ടു';

  @override
  String get noAnimalsFound => 'മൃഗങ്ങളെ കണ്ടെത്തിയില്ല';

  @override
  String get trySelectingDifferentCategory =>
      'മറ്റൊരു വിഭാഗം തിരഞ്ഞെടുക്കാൻ ശ്രമിക്കുക';

  @override
  String get checkBackLaterForNewListings =>
      'പുതിയ ലിസ്റ്റിംഗുകൾക്കായി പിന്നീട് പരിശോധിക്കുക';

  @override
  String get purchaseRequestSent => 'വാങ്ങൽ അഭ്യർത്ഥന അയച്ചു';

  @override
  String get all => 'എല്ലാം';

  @override
  String get cow => 'പശു';

  @override
  String get cats => 'പൂച്ചകൾ';

  @override
  String get animalDetails => 'മൃഗത്തിന്റെ വിശദാംശങ്ങൾ';

  @override
  String get photos => 'ഫോട്ടോകൾ';

  @override
  String get type => 'തരം';

  @override
  String get age => 'പ്രായം';

  @override
  String get gender => 'ലിംഗം';

  @override
  String get years => 'വർഷങ്ങൾ';

  @override
  String get pricingInformation => 'വില വിവരങ്ങൾ';

  @override
  String get fixedPrice => 'നിശ്ചിത വില';

  @override
  String get ownerAndLocation => 'ഉടമ്പയും സ്ഥലവും';

  @override
  String get location => 'സ്ഥലം';

  @override
  String get distance => 'ദൂരം';

  @override
  String get notSpecified => 'വ്യക്തമാക്കിയിട്ടില്ല';

  @override
  String get meters => 'മീറ്റർ';

  @override
  String get km => 'കിമീ';

  @override
  String get description => 'വിവരണം';

  @override
  String get contactSeller => 'വിൽപ്പനക്കാരനെ ബന്ധപ്പെടുക';

  @override
  String get unlockContactDetails =>
      'വിൽപ്പനക്കാരനുമായി ബന്ധപ്പെടാൻ ₹2ന് ബന്ധപ്പെടൽ വിശദാംശങ്ങൾ അൺലോക്ക് ചെയ്യുക';

  @override
  String get unlocking => 'അൺലോക്ക് ചെയ്യുന്നു...';

  @override
  String get unlockContact => 'ബന്ധപ്പെടൽ അൺലോക്ക് ചെയ്യുക (₹2)';

  @override
  String get contactOptions => 'ബന്ധപ്പെടൽ ഓപ്ഷനുകൾ';

  @override
  String get call => 'കോൾ';

  @override
  String get whatsApp => 'വാട്സാപ്പ്';

  @override
  String get contact => 'ബന്ധപ്പെടുക';

  @override
  String get notAvailable => 'ലഭ്യമല്ല';

  @override
  String get userNotLoggedIn => 'ഉപയോക്താവ് ലോഗിൻ ചെയ്തിട്ടില്ല';

  @override
  String get userDataNotFound => 'ഉപയോക്താവിന്റെ ഡാറ്റ കണ്ടെത്തിയില്ല';

  @override
  String get contactAlreadyUnlocked =>
      'ഈ ബന്ധപ്പെടൽ ഇതിനകം അൺലോക്ക് ചെയ്തിട്ടുണ്ട്.';

  @override
  String get contactUnlockedSuccessfully =>
      'ബന്ധപ്പെടൽ വിജയകരമായി അൺലോക്ക് ചെയ്തു!';

  @override
  String get couldNotLaunchPhoneApp => 'ഫോൺ ആപ്പ് ലോഞ്ച് ചെയ്യാൻ കഴിഞ്ഞില്ല';

  @override
  String get phoneNumberNotAvailable => 'ഫോൺ നമ്പർ ലഭ്യമല്ല';

  @override
  String get couldNotOpenWhatsApp => 'വാട്ട്സ്ആപ്പ് തുറക്കാൻ കഴിഞ്ഞില്ല';

  @override
  String whatsAppMessageTemplate(Object animalName) {
    return 'ഹായ്, പശു പരിവാറിൽ ലിസ്റ്റ് ചെയ്ത നിങ്ങളുടെ $animalNameൽ എനിക്ക് താൽപ്പര്യമുണ്ട്.';
  }

  @override
  String get locationNotAvailable => 'ലൊക്കേഷൻ ലഭ്യമല്ല';

  @override
  String get remove => 'നീക്കം ചെയ്യുക';

  @override
  String get removedFromWishlist => 'വിഷ്‌ലിസ്റ്റിൽ നിന്ന് നീക്കം ചെയ്തു';

  @override
  String get failedToRemove => 'നീക്കം ചെയ്യുന്നതിൽ പരാജയപ്പെട്ടു';

  @override
  String get animalDetailsComingSoon => 'മൃഗത്തിന്റെ വിശദാംശങ്ങൾ ഉടൻ വരുന്നു';

  @override
  String get fullAnimalDetailsModal =>
      'പൂർണ്ണ മൃഗ വിശദാംശങ്ങളുടെ മോഡൽ ഇവിടെ നടപ്പിലാക്കും';

  @override
  String get noWishlistAnimalsFound => 'വിഷ്‌ലിസ്റ്റ് മൃഗങ്ങളെ കണ്ടെത്തിയില്ല';

  @override
  String get tryAddingAnimalsToWishlist =>
      'നിങ്ങളുടെ വിഷ്‌ലിസ്റ്റിൽ കുറച്ച് മൃഗങ്ങളെ ചേർക്കാൻ ശ്രമിക്കുക!';

  @override
  String get investmentProject => 'നിക്ഷേപ പദ്ധതി';

  @override
  String get upcomingProjects => 'വരാനിരിക്കുന്ന പദ്ധതികൾ';

  @override
  String get liveProjects => 'ലൈവ് പദ്ധതികൾ';

  @override
  String get completedProjects => 'പൂർത്തിയാക്കിയ പദ്ധതികൾ';

  @override
  String get mvpForAquacultureInvestment => 'അക്വാകൾച്ചർ നിക്ഷേപത്തിനുള്ള MVP';

  @override
  String get longTerm => 'ദീർഘകാലിക';

  @override
  String get amount => 'തുക';

  @override
  String get startDate => 'ആരംഭ തീയതി';

  @override
  String get sixToEightMonths => '6 മുതൽ 8 മാസം വരെ';

  @override
  String get lotsBooked => 'ലോട്ടുകൾ ബുക്ക് ചെയ്തു';

  @override
  String get noProjectsAvailable => 'പദ്ധതികളൊന്നും ലഭ്യമല്ല।';

  @override
  String get firstAugust2025 => '1 ഓഗസ്റ്റ് 2025';

  @override
  String get addAmountAndGetPlans => 'തുക ചേർത്ത് പ്ലാനുകൾ നേടുക';

  @override
  String get getVerifiedYourPashu => 'നിങ്ങളുടെ പശുവിനെ പരിശോധിപ്പിക്കുക';

  @override
  String get termsAndPrivacy => 'നിബന്ധനകളും സ്വകാര്യതയും';

  @override
  String get newA => 'പുതിയത്';

  @override
  String get areYouSureLogout =>
      'നിങ്ങൾ നിങ്ങളുടെ അക്കൗണ്ടിൽ നിന്ന് ലോഗൗട്ട് ചെയ്യാൻ ആഗ്രഹിക്കുന്നുണ്ടോ?';

  @override
  String get noProfileFound => 'പ്രൊഫൈൽ കണ്ടെത്തിയില്ല';

  @override
  String get profileInformationNotAvailable => 'പ്രൊഫൈൽ വിവരങ്ങൾ ലഭ്യമല്ല';

  @override
  String get subscriptionPlans => 'സബ്‌സ്‌ക്രിപ്‌ഷൻ പ്ലാനുകൾ';

  @override
  String get chooseYourPlan => 'നിങ്ങളുടെ പ്ലാൻ തിരഞ്ഞെടുക്കുക';

  @override
  String get unlockPremiumFeatures =>
      'പ്രീമിയം ഫീച്ചറുകൾ അൺലോക്ക് ചെയ്ത് ഞങ്ങളുടെ സബ്‌സ്‌ക്രിപ്‌ഷൻ പ്ലാനുകൾ ഉപയോഗിച്ച് നിങ്ങളുടെ കന്നുകാലി ബിസിനസ്സ് വളർത്തുക';

  @override
  String get diamondPlan => 'ഡയമണ്ട് പ്ലാൻ';

  @override
  String get goldPlan => 'ഗോൾഡ് പ്ലാൻ';

  @override
  String get silverPlan => 'സിൽവർ പ്ലാൻ';

  @override
  String get year => 'വർഷം';

  @override
  String get months3 => '3 മാസം';

  @override
  String get month => 'മാസം';

  @override
  String get choosePlan => 'പ്ലാൻ തിരഞ്ഞെടുക്കുക';

  @override
  String get unlimitedPashuProfileContact =>
      'അൺലിമിറ്റഡ് പശു പ്രൊഫൈൽ കോൺടാക്ട്';

  @override
  String get unlimitedFreePashuListings => 'അൺലിമിറ്റഡ് ഫ്രീ പശു ലിസ്റ്റിംഗുകൾ';

  @override
  String get priorityCustomerSupport => 'മുൻഗണന കസ്റ്റമർ സപ്പോർട്ട്';

  @override
  String get advancedAnalytics => 'അഡ്വാൻസ്ഡ് അനലിറ്റിക്സ്';

  @override
  String get premiumBadge => 'പ്രീമിയം ബാഡ്ജ്';

  @override
  String get freePashuListings10 => '10 ഫ്രീ പശു ലിസ്റ്റിംഗുകൾ';

  @override
  String get standardCustomerSupport => 'സ്റ്റാൻഡേർഡ് കസ്റ്റമർ സപ്പോർട്ട്';

  @override
  String get basicAnalytics => 'ബേസിക് അനലിറ്റിക്സ്';

  @override
  String get freePashuListings2 => '2 ഫ്രീ പശു ലിസ്റ്റിംഗുകൾ';

  @override
  String get emailSupport => 'ഇമെയിൽ സപ്പോർട്ട്';

  @override
  String get addMoneyToYourWallet => 'നിങ്ങളുടെ വാലറ്റിലേക്ക് പണം ചേർക്കുക';

  @override
  String get addFundsToWallet =>
      'നിങ്ങളുടെ വാലറ്റിലേക്ക് ഫണ്ട് ചേർക്കുകയും സബ്‌സ്‌ക്രിപ്‌ഷനുകൾക്കായി എളുപ്പത്തിൽ പണമടയ്ക്കുകയും ചെയ്യുക. നിങ്ങളുടെ വാലറ്റ് ഞങ്ങളുടെ എല്ലാ സേവനങ്ങളിലും ഉപയോഗിക്കാൻ കഴിയും.';

  @override
  String get enterAmountEg500 => 'തുക നൽകുക (ഉദാ. 500)';

  @override
  String addAmount(String amount) {
    return '₹$amount ചേർക്കുക';
  }

  @override
  String get tipWalletContact =>
      'ടിപ്പ്: കോൺടാക്ട് വിശദാംശങ്ങൾ തൽക്ഷണം കാണാൻ നിങ്ങളുടെ വാലറ്റ് ഉപയോഗിക്കാം.';

  @override
  String subscribeToPlan(String planName) {
    return 'Subscribe to $planName';
  }

  @override
  String chargedForSubscription(String price, String period) {
    return 'ഈ $period സബ്‌സ്‌ക്രിപ്‌ഷനുവേണ്ടി നിങ്ങളിൽ നിന്ന് ₹$price ചാർജ് ചെയ്യപ്പെടും.';
  }

  @override
  String get confirmSubscription => 'സബ്‌സ്‌ക്രിപ്‌ഷൻ സ്ഥിരീകരിക്കുക';

  @override
  String get subscriptionSuccessful => 'സബ്‌സ്‌ക്രിപ്‌ഷൻ വിജയകരം!';

  @override
  String subscriptionSuccessMessage(String planName) {
    return 'നിങ്ങൾ വിജയകരമായി $planNameലേക്ക് സബ്‌സ്‌ക്രൈബ് ചെയ്തു. എല്ലാ പ്രീമിയം ഫീച്ചറുകളും ആസ്വദിക്കുക!';
  }

  @override
  String get continueA => 'തുടരുക';

  @override
  String get subscriptionHelp => 'സബ്‌സ്‌ക്രിപ്‌ഷൻ സഹായം';

  @override
  String get helpContent =>
      '• ഡയമണ്ട് പ്ലാൻ: ₹365/വർഷം\n• ഗോൾഡ് പ്ലാൻ: ₹140/3 മാസം\n• സിൽവർ പ്ലാൻ: ₹49/മാസം\n• നിങ്ങളുടെ പ്രൊഫൈലിൽ നിന്ന് എപ്പോൾ വേണമെങ്കിലും റദ്ദാക്കുക\n• എല്ലാ ഫീച്ചറുകളും ഉടൻ അൺലോക്ക് ആകും\n• 24/7 കസ്റ്റമർ സപ്പോർട്ട് ഉൾപ്പെടുത്തിയിട്ടുണ്ട്';

  @override
  String get gotIt => 'മനസ്സിലായി';

  @override
  String get pleaseEnterValidAmount => 'ദയവായി സാധുവായ തുക നൽകുക';

  @override
  String get couldNotInitiatePayment => 'പേയ്‌മെന്റ് ആരംഭിക്കാൻ കഴിഞ്ഞില്ല';

  @override
  String get somethingWentWrongPayment => 'പേയ്‌മെന്റിൽ എന്തോ പിഴവ് സംഭവിച്ചു.';

  @override
  String get paymentCancelled =>
      'പേയ്‌മെന്റ് റദ്ദാക്കുകയോ സമയത്തിനുള്ളിൽ പൂർത്തിയാക്കാതിരിക്കുകയോ ചെയ്തു.';

  @override
  String get paymentFailed => 'പേയ്‌മെന്റ് പരാജയപ്പെട്ടു';

  @override
  String get externalWalletSelected => 'ബാഹ്യ വാലറ്റ് തിരഞ്ഞെടുത്തു';

  @override
  String get getInTouch => 'ബന്ധപ്പെടുക';

  @override
  String get contactUsDescription =>
      'ഞങ്ങൾ സഹായിക്കാൻ ഇവിടെയുണ്ട്! എപ്പോൾ വേണമെങ്കിലും ഞങ്ങളെ ബന്ധപ്പെടുക, കഴിയുന്നത്ര വേഗത്തിൽ ഞങ്ങൾ നിങ്ങളിലേക്ക് തിരികെ വരാം.';

  @override
  String get contactInformation => 'ബന്ധപ്പെടാനുള്ള വിവരങ്ങൾ';

  @override
  String get officeAddress => 'ഓഫീസ് വിലാസം';

  @override
  String get pashuParivarHeadquarters =>
      'പശു പരിവാർ ആസ്ഥാനം\nഭോപ്പാൽ, മധ്യപ്രദേശ്\nഇന്ത്യ';

  @override
  String get sendUsAMessage => 'ഞങ്ങൾക്ക് ഒരു സന്ദേശം അയയ്ക്കുക';

  @override
  String get fullName => 'പൂർണ്ണ നാമം';

  @override
  String get enterYourFullName => 'നിങ്ങളുടെ പൂർണ്ണ നാമം നൽകുക';

  @override
  String get enterYourEmailAddress => 'നിങ്ങളുടെ ഇമെയിൽ വിലാസം നൽകുക';

  @override
  String get message => 'സന്ദേശം';

  @override
  String get tellUsHowWeCanHelp =>
      'ഞങ്ങൾക്ക് നിങ്ങളെ എങ്ങനെ സഹായിക്കാൻ കഴിയുമെന്ന് പറയുക...';

  @override
  String get sendingMessage => 'സന്ദേശം അയയ്ക്കുന്നു...';

  @override
  String get sendMessage => 'സന്ദേശം അയയ്ക്കുക';

  @override
  String get responseTimeNote =>
      'ഞങ്ങൾ സാധാരണയായി ബിസിനസ്സ് ദിവസങ്ങളിൽ 24 മണിക്കൂറിനുള്ളിൽ പ്രതികരിക്കുന്നു.';

  @override
  String get followUs => 'ഞങ്ങളെ പിന്തുടരുക';

  @override
  String get stayUpdatedWithNews =>
      'ഞങ്ങളുടെ ഏറ്റവും പുതിയ വാർത്തകളും അപ്ഡേറ്റുകളും ഉപയോഗിച്ച് അപ്ഡേറ്റായി തുടരുക';

  @override
  String get facebook => 'ഫേസ്ബുക്ക്';

  @override
  String get instagram => 'ഇൻസ്റ്റാഗ്രാം';

  @override
  String get twitter => 'ട്വിറ്റർ';

  @override
  String get youtube => 'യൂട്യൂബ്';

  @override
  String get copiedToClipboard => 'ക്ലിപ്പ്ബോർഡിലേക്ക് പകർത്തി!';

  @override
  String get messageSentSuccessfully => 'സന്ദേശം വിജയകരമായി അയച്ചു!';

  @override
  String get thankYouForContacting =>
      'ഞങ്ങളെ ബന്ധപ്പെട്ടതിന് നന്ദി. ഞങ്ങൾ 24 മണിക്കൂറിനുള്ളിൽ നിങ്ങളിലേക്ക് തിരികെ വരാം.';

  @override
  String get nameMustBeAtLeast2Characters =>
      'പേര് കുറഞ്ഞത് 2 അക്ഷരങ്ങൾ ആയിരിക്കണം';

  @override
  String get emailIsRequired => 'ഇമെയിൽ ആവശ്യമാണ്';

  @override
  String get pleaseEnterValidEmail => 'ദയവായി സാധുവായ ഇമെയിൽ വിലാസം നൽകുക';

  @override
  String get messageIsRequired => 'സന്ദേശം ആവശ്യമാണ്';

  @override
  String get messageMustBeAtLeast10Characters =>
      'സന്ദേശം കുറഞ്ഞത് 10 അക്ഷരങ്ങൾ ആയിരിക്കണം';

  @override
  String get invest => 'കാർഷിക-മൃഗपालനത്തിൽ നിക്ഷേപിക്കുക';

  @override
  String get total => 'മൊത്തം';

  @override
  String get active => 'സജീവം';

  @override
  String get pending => 'കാത്തിരിപ്പിൽ';

  @override
  String get edit => 'എഡിറ്റ് ചെയ്യുക';

  @override
  String get delete => 'നീക്കം ചെയ്യുക';

  @override
  String get pendingStatus => 'കാത്തിരിപ്പിൽ';

  @override
  String get failedToLoadListings =>
      'ലിസ്റ്റിങ്ങുകൾ ലോഡ് ചെയ്യുന്നതിൽ പരാജയപ്പെട്ടു';

  @override
  String get noListedAnimals => 'ലിസ്റ്റ് ചെയ്ത മൃഗങ്ങളില്ല';

  @override
  String get noListedAnimalsDescription =>
      'നിങ്ങൾ ഇതുവരെ മൃഗങ്ങളെ ലിസ്റ്റ് ചെയ്തിട്ടില്ല. നിങ്ങളുടെ ആദ്യത്തെ ലിസ്റ്റിംഗ് ചേർത്തുകൊണ്ട് ആരംഭിക്കുക!';

  @override
  String get addNewListing => 'പുതിയ ലിസ്റ്റിംഗ് ചേർക്കുക';

  @override
  String get deleteListing => 'ലിസ്റ്റിംഗ് നീക്കം ചെയ്യുക';

  @override
  String deleteConfirmation(String animalName) {
    return 'നിങ്ങൾക്ക് \"$animalName\" നീക്കം ചെയ്യണമെന്ന് ഉറപ്പാണോ? ഈ പ്രവർത്തനം പഴയപടിയാക്കാൻ കഴിയില്ല.';
  }

  @override
  String deleteSuccessMessage(String animalName) {
    return '$animalName വിജയകരമായി നീക്കം ചെയ്തു';
  }

  @override
  String get withdrawFromWallet => 'വാലറ്റിൽ നിന്ന് പിൻവലിക്കുക';

  @override
  String get availableBalance => 'ലഭ്യമായ ബാലൻസ്';

  @override
  String get withdrawalEligible => 'പിൻവലിക്കൽ യോഗ്യത';

  @override
  String get withdrawalRequirements => 'പിൻവലിക്കൽ ആവശ്യകതകൾ';

  @override
  String youHaveSpentAndCanWithdraw(String counter) {
    return 'നിങ്ങൾ ₹$counter ചെലവഴിച്ചു, ഫണ്ട് പിൻവലിക്കാം';
  }

  @override
  String spendMoreToEnableWithdrawal(String amount, String counter) {
    return 'പിൻവലിക്കൽ പ്രാപ്തമാക്കാൻ ₹$amount കൂടുതൽ ചെലവഴിക്കുക (നിലവിൽ: ₹$counter)';
  }

  @override
  String get withdrawalDetails => 'പിൻവലിക്കൽ വിശദാംശങ്ങൾ';

  @override
  String get enterAmountEg => 'തുക നൽകുക ഉദാ. 500';

  @override
  String get enterUpiIdEg => 'UPI ID നൽകുക (ഉദാ. example@upi)';

  @override
  String get enterUpiIdEgPlaceholder => 'UPI ID നൽകുക ഉദാ. example@upi';

  @override
  String get processing => 'പ്രോസസ്സിംഗ്...';

  @override
  String withdrawAmount(String amount) {
    return '₹$amount പിൻവലിക്കുക';
  }

  @override
  String get withdrawalRequirementsLabel => 'പിൻവലിക്കൽ ആവശ്യകതകൾ:';

  @override
  String get minimumSpendingRequired => '• കുറഞ്ഞത് ₹50 ചെലവ് ആവശ്യം';

  @override
  String get walletBalanceRequired => '• വാലറ്റ് ബാലൻസ് ≥ ₹100 ആയിരിക്കണം';

  @override
  String currentSpending(String counter, String status) {
    return '• നിലവിലെ ചെലവ്: ₹$counter ($status)';
  }

  @override
  String walletBalanceStatus(String balance, String status) {
    return '• വാലറ്റ് ബാലൻസ്: ₹$balance ($status)';
  }

  @override
  String get verified => '✓';

  @override
  String needMoreAmount(String amount) {
    return '₹$amount കൂടുതൽ ആവശ്യം';
  }

  @override
  String get tipWithdrawProcessingTime =>
      'ടിപ്പ്: പിൻവലിക്കലുകൾ നിങ്ങളുടെ UPI അക്കൗണ്ടിലേക്ക് 24-48 മണിക്കൂറിനുള്ളിൽ പ്രോസസ്സ് ചെയ്യപ്പെടും.';

  @override
  String get withdrawalRequestSubmitted => 'പിൻവലിക്കൽ അഭ്യർത്ഥന സമർപ്പിച്ചു!';

  @override
  String withdrawalRequestSuccessMessage(String amount) {
    return '₹$amount നിങ്ങളുടെ പിൻവലിക്കൽ അഭ്യർത്ഥന വിജയകരമായി സമർപ്പിച്ചു. നിങ്ങൾക്ക് 24-48 മണിക്കൂറിനുള്ളിൽ UPI അക്കൗണ്ടിൽ തുക ലഭിക്കും.';
  }

  @override
  String get failedToLoadData => 'ഡാറ്റ ലോഡ് ചെയ്യുന്നതിൽ പരാജയപ്പെട്ടു';

  @override
  String get amountCannotBeEmpty => 'തുക ശൂന്യമായിരിക്കാൻ പാടില്ല';

  @override
  String amountCannotExceedBalance(String balance) {
    return 'തുക വാലറ്റ് ബാലൻസ് കവിയാൻ പാടില്ല (₹$balance)';
  }

  @override
  String get minimumWalletBalanceRequired =>
      'കുറഞ്ഞത് ₹100 വാലറ്റ് ബാലൻസ് ആവശ്യം';

  @override
  String get upiIdCannotBeEmpty => 'UPI ID ശൂന്യമായിരിക്കാൻ പാടില്ല';

  @override
  String get pleaseEnterValidUpiId => 'ദയവായി സാധുവായ UPI ID നൽകുക';

  @override
  String get transactionHistory => 'ഇടപാട് ചരിത്രം';

  @override
  String get noTransactions => 'ഇടപാടുകളില്ല';

  @override
  String get transactionSummary => 'ഇടപാട് സംഗ്രഹം';

  @override
  String get totalCredit => 'മൊത്തം ക്രെഡിറ്റ്';

  @override
  String get totalDebit => 'മൊത്തം ഡെബിറ്റ്';

  @override
  String get successful => 'വിജയകരം';

  @override
  String get today => 'ഇന്ന്';

  @override
  String get yesterday => 'ഇന്നലെ';

  @override
  String daysAgo(String days) {
    return '$days ദിവസങ്ങൾക്ക് മുമ്പ്';
  }

  @override
  String get paymentId => 'പേമെന്റ് ID';

  @override
  String get fullDate => 'പൂർണ്ണ തീയതി';

  @override
  String get utrNumber => 'UTR നമ്പർ';

  @override
  String get failedToLoadTransactions =>
      'ഇടപാടുകൾ ലോഡ് ചെയ്യുന്നതിൽ പരാജയപ്പെട്ടു';

  @override
  String get noTransactionsFound => 'ഇടപാടുകൾ കണ്ടെത്തിയില്ല';

  @override
  String get transactionHistoryDescription =>
      'നിങ്ങളുടെ ആദ്യ ഇടപാട് നടത്തിയ ശേഷം നിങ്ങളുടെ ഇടപാട് ചരിത്രം ഇവിടെ പ്രത്യക്ഷപ്പെടും';

  @override
  String get goBack => 'തിരികെ പോകുക';

  @override
  String get success => 'വിജയം';

  @override
  String get failed => 'പരാജയപ്പെട്ടു';

  @override
  String get credit => 'ക്രെഡിറ്റ്';

  @override
  String get debit => 'ഡെബിറ്റ്';

  @override
  String get profileDetails => 'പ്രൊഫൈൽ വിശദാംശങ്ങൾ';

  @override
  String get address => 'വിലാസം';

  @override
  String get notProvided => 'നൽകിയില്ല';

  @override
  String get profileDetailsSectionHeader => 'പ്രൊഫൈൽ വിശദാംശങ്ങൾ';

  @override
  String get editProfileInformation => 'പ്രൊഫൈൽ വിവരങ്ങൾ എഡിറ്റ് ചെയ്യുക';

  @override
  String get nameCannotBeEmpty => 'പേര് ഒഴിവാക്കാൻ കഴിയില്ല';

  @override
  String get nameMinimumCharacters => 'പേര് കുറഞ്ഞത് 2 അക്ഷരങ്ങളായിരിക്കണം';

  @override
  String get addressCannotBeEmpty => 'വിലാസം ഒഴിവാകരുത്';

  @override
  String get pleaseEnterCompleteAddress => 'ദയവായി മുഴുവൻ വിലാസവും നൽകുക';

  @override
  String get phoneAndReferralNotChangeable =>
      'കുറിപ്പ്: ഫോൺ നമ്പറും റഫറൽ കോഡും മാറ്റാനാവില്ല. പേര്, ഇമെയിൽ, വിലാസം എന്നിവ മാത്രമേ അപ്‌ഡേറ്റ് ചെയ്യാനാകൂ.';

  @override
  String get updatingProfile => 'പ്രൊഫൈൽ അപ്‌ഡേറ്റ് ചെയ്യുന്നു...';

  @override
  String get updateProfile => 'പ്രൊഫൈൽ അപ്‌ഡേറ്റ് ചെയ്യുക';

  @override
  String get profileUpdatedSuccessfully =>
      'പ്രൊഫൈൽ വിജയകരമായി അപ്‌ഡേറ്റ് ചെയ്തു!';

  @override
  String get profileUpdateSuccessMessage =>
      'നിങ്ങളുടെ പ്രൊഫൈൽ വിവരങ്ങൾ വിജയകരമായി അപ്‌ഡേറ്റ് ചെയ്തു.';

  @override
  String get updateFailed => 'അപ്‌ഡേറ്റ് പരാജയപ്പെട്ടു';

  @override
  String get inviteEarnRewards => 'ക്ഷണിച്ച് റിവാർഡുകൾ നേടുക';

  @override
  String get shareReferralDescription =>
      'നിങ്ങളുടെ റഫറൽ കോഡ് സുഹൃത്തുക്കളുമായും കുടുംബാംഗങ്ങളുമായും പങ്കിടുകയും അവർ പശു പരിവാറിൽ ചേരുമ്പോൾ പ്രത്യേക റിവാർഡുകൾ നേടുകയും ചെയ്യുക';

  @override
  String get yourReferralCode => 'നിങ്ങളുടെ റഫറൽ കോഡ്';

  @override
  String get shareWithFriends => 'സുഹൃത്തുക്കളുമായി പങ്കിടുക';

  @override
  String get shareLink => 'ലിങ്ക് പങ്കിടുക';

  @override
  String get copyLink => 'ലിങ്ക് കോപ്പി ചെയ്യുക';

  @override
  String get moreOptions => 'കൂടുതൽ ഓപ്ഷനുകൾ';

  @override
  String get referralBenefits => 'റഫറൽ ആനുകൂല്യങ്ങൾ';

  @override
  String get earnRewards => 'റിവാർഡുകൾ നേടുക';

  @override
  String get earnRewardsDescription =>
      'നിങ്ങളുടെ കോഡ് ഉപയോഗിച്ച് സുഹൃത്തുക്കൾ ചേരുമ്പോൾ പ്രത്യേക റിവാർഡുകൾ നേടുക';

  @override
  String get helpFriends => 'സുഹൃത്തുക്കളെ സഹായിക്കുക';

  @override
  String get helpFriendsDescription =>
      'നിങ്ങളുടെ സുഹൃത്തുക്കൾക്കും സൈൻ അപ്പ് ചെയ്യുമ്പോൾ പ്രത്യേക ബോണസ് ലഭിക്കുന്നു';

  @override
  String get unlimitedSharing => 'പരിധിയില്ലാത്ത പങ്കിടൽ';

  @override
  String get unlimitedSharingDescription =>
      'ആരുമായും എത്ര തവണ വേണമെങ്കിലും നിങ്ങളുടെ കോഡ് പങ്കിടുക';

  @override
  String get trackProgress => 'പുരോഗതി ട്രാക്ക് ചെയ്യുക';

  @override
  String get trackProgressDescription =>
      'നിങ്ങളുടെ പ്രൊഫൈലിൽ നിങ്ങളുടെ റഫറൽ വിജയവും റിവാർഡുകളും നിരീക്ഷിക്കുക';

  @override
  String get howItWorks => 'ഇത് എങ്ങനെ പ്രവർത്തിക്കുന്നു';

  @override
  String get shareYourCode => 'നിങ്ങളുടെ കോഡ് പങ്കിടുക';

  @override
  String get shareYourCodeDescription =>
      'നിങ്ങളുടെ റഫറൽ കോഡ് അല്ലെങ്കിൽ ലിങ്ക് സുഹൃത്തുക്കൾക്കും കുടുംബാംഗങ്ങൾക്കും അയയ്ക്കുക';

  @override
  String get friendSignsUp => 'സുഹൃത്ത് സൈൻ അപ്പ് ചെയ്യുന്നു';

  @override
  String get friendSignsUpDescription =>
      'അവർ നിങ്ങളുടെ റഫറൽ കോഡ് ഉപയോഗിച്ച് അക്കൗണ്ട് സൃഷ്ടിക്കുന്നു';

  @override
  String get bothGetRewards => 'ഇരുവർക്കും റിവാർഡുകൾ ലഭിക്കുന്നു';

  @override
  String get bothGetRewardsDescription =>
      'നിങ്ങൾക്കും നിങ്ങളുടെ സുഹൃത്തിനും പ്രത്യേക ബോണസുകൾ ലഭിക്കുന്നു';

  @override
  String get linkCopiedToClipboard =>
      'ലിങ്ക് ക്ലിപ്പ്ബോർഡിലേക്ക് കോപ്പി ചെയ്തു!';

  @override
  String get codeCopiedToClipboard => 'കോഡ് ക്ലിപ്പ്ബോർഡിലേക്ക് കോപ്പി ചെയ്തു!';

  @override
  String get referralHelp => 'റഫറൽ സഹായം';

  @override
  String get referralHelpContent =>
      '• നിങ്ങളുടെ അതുല്യമായ റഫറൽ കോഡ് സുഹൃത്തുക്കളുമായി പങ്കിടുക\n• നിങ്ങൾക്കും നിങ്ങളുടെ സുഹൃത്തിനും റിവാർഡുകൾ ലഭിക്കുന്നു\n• എത്ര സുഹൃത്തുക്കളെ റഫർ ചെയ്യാം എന്നതിന് പരിധിയില്ല\n• നിങ്ങളുടെ പ്രൊഫൈലിൽ നിങ്ങളുടെ റഫറലുകൾ ട്രാക്ക് ചെയ്യുക\n• റിവാർഡുകൾ സ്വയമേവ ക്രെഡിറ്റ് ചെയ്യപ്പെടുന്നു';

  @override
  String shareMessage(String referralCode, String referralUrl) {
    return '🐄 പശു പരിവാറിൽ എന്നോടൊപ്പം ചേരുക - ഇന്ത്യയുടെ വിശ്വസനീയ കന്നുകാലി മാർക്കറ്റ്പ്ലേസ്! 🐄\n\nഗുണമേന്മയുള്ള മൃഗങ്ങളെ കണ്ടെത്തുക, സാക്ഷ്യപ്പെടുത്തിയ വിൽപ്പനക്കാരുമായി ബന്ധപ്പെടുക, പ്രീമിയം ഫീച്ചറുകൾ ഉപയോഗിച്ച് നിങ്ങളുടെ കന്നുകാലി ബിസിനസ്സ് വളർത്തുക.\n\n✨ എന്റെ റഫറൽ കോഡ് ഉപയോഗിക്കുക: $referralCode\n🎁 ഞങ്ങൾ രണ്ടുപേർക്കും പ്രത്യേക റിവാർഡുകൾ നേടുക!\n\nഇപ്പോൾ ഡൗൺലോഡ് ചെയ്യുക: $referralUrl\n\n#പശുപരിവാർ #കന്നുകാലികൾ #കൃഷി #മൃഗവ്യാപാരം';
  }

  @override
  String get termsOfService => 'സേവന നിബന്ധനകൾ';

  @override
  String get privacyPolicy => 'സ്വകാര്യതാ നയം';

  @override
  String get lastUpdated => 'അവസാനം അപ്‌ഡേറ്റ് ചെയ്തത്: ജൂലൈ 27, 2025';

  @override
  String get acceptanceOfTerms => 'നിബന്ധനകളുടെ സ്വീകാര്യത';

  @override
  String get acceptanceOfTermsContent =>
      'പശു പരിവാർ ആക്സസ്സ് ചെയ്യുകയും ഉപയോഗിക്കുകയും ചെയ്യുന്നതിലൂടെ, ഈ കരാറിന്റെ നിബന്ധനകളും വ്യവസ്ഥകളും അനുസരിച്ച് പ്രവർത്തിക്കാൻ നിങ്ങൾ സ്വീകരിക്കുകയും സമ്മതിക്കുകയും ചെയ്യുന്നു.';

  @override
  String get useLicense => 'ഉപയോഗ ലൈസൻസ്';

  @override
  String get useLicenseContent =>
      'വ്യക്തിപരവും വാണിജ്യേതരവുമായ താത്കാലിക കാഴ്ചയ്‌ക്കായി മാത്രം ഓരോ ഉപകരണത്തിനും പശു പരിവാറിന്റെ ഒരു കോപ്പി താത്കാലികമായി ഡൗൺലോഡ് ചെയ്യാൻ അനുമതി നൽകിയിരിക്കുന്നു.';

  @override
  String get userResponsibilities => 'ഉപയോക്താവിന്റെ ഉത്തരവാദിത്തങ്ങൾ';

  @override
  String get userResponsibilitiesContent =>
      '• ലിസ്റ്റിംഗുകൾ സൃഷ്ടിക്കുമ്പോൾ കൃത്യമായ വിവരങ്ങൾ നൽകുക\n• മറ്റ് ഉപയോക്താക്കളെ ബഹുമാനിക്കുകയും പ്രൊഫഷണൽ പെരുമാറ്റം നിലനിർത്തുകയും ചെയ്യുക\n• ബാധകമായ എല്ലാ നിയമങ്ങളും നിയന്ത്രണങ്ങളും അനുസരിക്കുക\n• വഞ്ചനാപരമായ പ്രവർത്തനങ്ങൾക്കായി പ്ലാറ്റ്‌ഫോം ദുരുപയോഗം ചെയ്യരുത്';

  @override
  String get platformServices => 'പ്ലാറ്റ്‌ഫോം സേവനങ്ങൾ';

  @override
  String get platformServicesContent =>
      'പശു പരിവാർ കന്നുകാലി വ്യാപാരത്തിനായി ഒരു പ്ലാറ്റ്‌ഫോം നൽകുന്നു, വാങ്ങുന്നവരെയും വിൽക്കുന്നവരെയും ബന്ധിപ്പിക്കുന്നു. ഞങ്ങൾ ഇടപാടുകൾ സുഗമമാക്കുന്നു, എന്നാൽ വാങ്ങൽ/വിൽപ്പന പ്രക്രിയയിൽ നേരിട്ട് ഉൾപ്പെട്ടിട്ടില്ല.';

  @override
  String get accountSecurity => 'അക്കൗണ്ട് സുരക്ഷ';

  @override
  String get accountSecurityContent =>
      'അവരുടെ അക്കൗണ്ട് വിവരങ്ങളുടെയും പാസ്‌വേഡിന്റെയും രഹസ്യസ്വഭാവം നിലനിർത്തുന്നതിന് ഉപയോക്താക്കൾ ഉത്തരവാദികളാണ്. ഏതെങ്കിലും അനധികൃത ഉപയോഗം ഉടൻ ഞങ്ങളെ അറിയിക്കുക.';

  @override
  String get paymentTerms => 'പേയ്‌മെന്റ് നിബന്ധനകൾ';

  @override
  String get paymentTermsContent =>
      'പ്രീമിയം സേവനങ്ങൾക്കുള്ള എല്ലാ പേയ്‌മെന്റുകളും സുരക്ഷിതമായി പ്രോസസ്സ് ചെയ്യപ്പെടുന്നു. വേറെ വ്യക്തമാക്കിയിട്ടില്ലെങ്കിൽ സബ്‌സ്‌ക്രിപ്ഷൻ ഫീസ് റീഫണ്ട് ചെയ്യാൻ കഴിയില്ല.';

  @override
  String get contentGuidelines => 'ഉള്ളടക്ക മാർഗ്ഗനിർദ്ദേശങ്ങൾ';

  @override
  String get contentGuidelinesContent =>
      'അപ്‌ലോഡ് ചെയ്യുന്ന എല്ലാ ഉള്ളടക്കവും ഉചിതവും കൃത്യവും ആയിരിക്കുകയും ഞങ്ങളുടെ കമ്മ്യൂണിറ്റി മാർഗ്ഗനിർദ്ദേശങ്ങൾ പാലിക്കുകയും വേണം. അനുചിതമായ ഉള്ളടക്കം നീക്കം ചെയ്യാൻ ഞങ്ങൾക്ക് അവകാശം സംവരണം ചെയ്യുന്നു.';

  @override
  String get limitationOfLiability => 'ബാധ്യതയുടെ പരിമിതി';

  @override
  String get limitationOfLiabilityContent =>
      'സേവനത്തിന്റെ നിങ്ങളുടെ ഉപയോഗത്തിന്റെ ഫലമായുണ്ടാകുന്ന എന്തെങ്കിലും പരോക്ഷമായ, ആകസ്മികമായ, പ്രത്യേക, അനന്തരഫലമായ അല്ലെങ്കിൽ ശിക്ഷാപരമായ നാശനഷ്ടങ്ങൾക്ക് പശു പരിവാർ ബാധ്യസ്ഥനാകില്ല.';

  @override
  String get modifications => 'പരിഷ്‌ക്കരണങ്ങൾ';

  @override
  String get modificationsContent =>
      'ഈ നിബന്ധനകൾ ഏത് സമയത്തും പരിഷ്‌ക്കരിക്കാനുള്ള അവകാശം ഞങ്ങൾ സംവരണം ചെയ്യുന്നു. പ്രധാനപ്പെട്ട മാറ്റങ്ങളെക്കുറിച്ച് ഉപയോക്താക്കൾക്ക് അറിയിക്കും.';

  @override
  String get contactInformationContent =>
      'ഈ സേവന നിബന്ധനകളെക്കുറിച്ചുള്ള ചോദ്യങ്ങൾക്ക്, ദയവായി support@pashuparivar.com ൽ ഞങ്ങളെ ബന്ധപ്പെടുക';

  @override
  String get informationWeCollect => 'ഞങ്ങൾ ശേഖരിക്കുന്ന വിവരങ്ങൾ';

  @override
  String get informationWeCollectContent =>
      '• വ്യക്തിഗത വിവരങ്ങൾ: പേര്, ഫോൺ നമ്പർ, ഇമെയിൽ വിലാസം\n• പ്രൊഫൈൽ വിവരങ്ങൾ: വിലാസം, മുൻഗണനകൾ, ഉപയോഗ ഡാറ്റ\n• ഉപകരണ വിവരങ്ങൾ: IP വിലാസം, ബ്രൗസർ തരം, ഓപ്പറേറ്റിംഗ് സിസ്റ്റം\n• ഉപയോഗ ഡാറ്റ: ആപ്പ് ഇന്റർঅാക്ഷനുകൾ, ഉപയോഗിച്ച ഫീച്ചറുകൾ, സെഷൻ ദൈർഘ്യം';

  @override
  String get howWeUseYourInformation =>
      'നിങ്ങളുടെ വിവരങ്ങൾ ഞങ്ങൾ എങ്ങനെ ഉപയോഗിക്കുന്നു';

  @override
  String get howWeUseYourInformationContent =>
      'ശേഖരിച്ച വിവരങ്ങൾ ഞങ്ങൾ ഉപയോഗിക്കുന്നത്:\n• ഞങ്ങളുടെ സേവനങ്ങൾ നൽകാനും നിലനിർത്താനും\n• ഇടപാടുകൾ പ്രോസസ്സ് ചെയ്യാനും അറിയിപ്പുകൾ അയയ്‌ക്കാനും\n• ഉപയോക്തൃ അനുഭവവും ആപ്പ് പ്രവർത്തനവും മെച്ചപ്പെടുത്താൻ\n• അപ്ഡേറ്റുകളെയും ഓഫറുകളെയും കുറിച്ച് നിങ്ങളുമായി ആശയവിനിമയം നടത്താൻ';

  @override
  String get informationSharing => 'വിവര പങ്കിടൽ';

  @override
  String get informationSharingContent =>
      'ഞങ്ങൾ നിങ്ങളുടെ വിവരങ്ങൾ പങ്കിടാം:\n• മറ്റ് ഉപയോക്താക്കളുമായി (ലിസ്റ്റിംഗുകളിലെ പ്രൊഫൈൽ വിവരങ്ങൾ)\n• ഞങ്ങളുടെ പ്രവർത്തനങ്ങളെ സഹായിക്കുന്ന സേവന ദാതാക്കളുമായി\n• നിയമപ്രകാരം ആവശ്യമാണെങ്കിൽ അല്ലെങ്കിൽ ഞങ്ങളുടെ അവകാശങ്ങൾ സംരക്ഷിക്കാൻ\n• നിർദ്ദിഷ്ട ആവശ്യങ്ങൾക്കായി നിങ്ങളുടെ സമ്മതത്തോടെ';

  @override
  String get dataSecurity => 'ഡാറ്റ സുരക്ഷ';

  @override
  String get dataSecurityContent =>
      'അനധികൃത ആക്സസ്, മാറ്റം, വെളിപ്പെടുത്തൽ അല്ലെങ്കിൽ നാശം എന്നിവയ്‌ക്കെതിരെ നിങ്ങളുടെ വ്യക്തിഗത വിവരങ്ങൾ സംരക്ഷിക്കുന്നതിന് ഞങ്ങൾ ഉചിതമായ സുരക്ഷാ നടപടികൾ നടപ്പിലാക്കുന്നു.';

  @override
  String get dataRetention => 'ഡാറ്റ നിലനിർത്തൽ';

  @override
  String get dataRetentionContent =>
      'ഈ നയത്തിൽ വിശദീകരിച്ചിരിക്കുന്ന ഉദ്ദേശ്യങ്ങൾക്ക് ആവശ്യമായ കാലയളവിലോ നിയമപ്രകാരം ആവശ്യമായ കാലയളവിലോ മാത്രമേ നിങ്ങളുടെ വ്യക്തിഗത വിവരങ്ങൾ ഞങ്ങൾ സൂക്ഷിക്കുകയുള്ളൂ.';

  @override
  String get yourRights => 'നിങ്ങളുടെ അവകാശങ്ങൾ';

  @override
  String get yourRightsContent =>
      'നിങ്ങൾക്ക് അവകാശമുണ്ട്:\n• നിങ്ങളുടെ വ്യക്തിഗത വിവരങ്ങൾ ആക്സസ് ചെയ്യാൻ\n• തെറ്റായ വിവരങ്ങൾ ശരിയാക്കാൻ\n• നിങ്ങളുടെ അക്കൗണ്ടും ഡാറ്റയും ഇല്ലാതാക്കാൻ\n• മാർക്കറ്റിംഗ് കമ്മ്യൂണിക്കേഷനുകളിൽ നിന്ന് പുറത്തുകടക്കാൻ';

  @override
  String get cookiesAndTracking => 'കുക്കികളും ട്രാക്കിംഗും';

  @override
  String get cookiesAndTrackingContent =>
      'നിങ്ങളുടെ അനുഭവം മെച്ചപ്പെടുത്തുന്നതിനും ഉപയോഗ പാറ്റേണുകൾ വിശകലനം ചെയ്യുന്നതിനും വ്യക്തിഗതമാക്കിയ ഉള്ളടക്കം നൽകുന്നതിനും ഞങ്ങൾ കുക്കികളും സമാന സാങ്കേതികവിദ്യകളും ഉപയോഗിക്കുന്നു.';

  @override
  String get thirdPartyServices => 'മൂന്നാം കക്ഷി സേവനങ്ങൾ';

  @override
  String get thirdPartyServicesContent =>
      'ഞങ്ങളുടെ ആപ്പിൽ മൂന്നാം കക്ഷി സേവനങ്ങളിലേക്കുള്ള ലിങ്കുകൾ അടങ്ങിയിരിക്കാം. അവരുടെ സ്വകാര്യതാ രീതികൾക്ക് ഞങ്ങൾ ഉത്തരവാദികളല്ല.';

  @override
  String get childrensPrivacy => 'കുട്ടികളുടെ സ്വകാര്യത';

  @override
  String get childrensPrivacyContent =>
      'ഞങ്ങളുടെ സേവനം 13 വയസ്സിൽ താഴെയുള്ള കുട്ടികൾക്കുള്ളതല്ല. 13 വയസ്സിൽ താഴെയുള്ള കുട്ടികളിൽ നിന്ന് വ്യക്തിഗത വിവരങ്ങൾ അറിഞ്ഞുകൊണ്ട് ശേഖരിക്കുന്നില്ല.';

  @override
  String get changesToThisPolicy => 'ഈ നയത്തിലെ മാറ്റങ്ങൾ';

  @override
  String get changesToThisPolicyContent =>
      'ഞങ്ങൾ ഇക്കാലാക്കാലം ഈ സ്വകാര്യതാ നയം അപ്ഡേറ്റ് ചെയ്യാം. ഈ പേജിൽ പുതിയ നയം പോസ്റ്റ് ചെയ്തുകൊണ്ട് ഏതെങ്കിലും മാറ്റങ്ങൾ നിങ്ങളെ അറിയിക്കും.';

  @override
  String get privacyContactContent =>
      'ഈ സ്വകാര്യതാ നയത്തെക്കുറിച്ച് നിങ്ങൾക്ക് ചോദ്യങ്ങളുണ്ടെങ്കിൽ, ദയവായി ഞങ്ങളെ ബന്ധപ്പെടുക:\nഇമെയിൽ: privacy@pashuparivar.com\nഫോൺ: +91-XXXXXXXXXX';
}
