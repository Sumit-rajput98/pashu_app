// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Tamil (`ta`).
class AppLocalizationsTa extends AppLocalizations {
  AppLocalizationsTa([String locale = 'ta']) : super(locale);

  @override
  String get welcome => 'பசு குடும்பத்திற்கு வரவேற்கிறோம்';

  @override
  String get locationPermissionTitle => 'இருப்பிடம் அனுமதி';

  @override
  String get locationPermissionMessage =>
      'ஆப்பிற்கு உங்கள் இருப்பிடத்தை அணுக அனுமதி தேவை.';

  @override
  String get permissionDenied => 'அனுமதி மறுக்கப்பட்டது';

  @override
  String get permissionRetryMessage =>
      'இந்த அம்சத்தைப் பயன்படுத்த இருப்பிடம் அனுமதி தேவை. மீண்டும் முயற்சிக்க விரும்புகிறீர்களா?';

  @override
  String get yes => 'ஆம்';

  @override
  String get no => 'இல்லை';

  @override
  String get hi => 'வணக்கம்';

  @override
  String get newAnimal => 'புதிய கால்நடை';

  @override
  String get newBuyers => 'புதிய வாங்குபவர்கள்';

  @override
  String get buyAnimal => 'கால்நடை வாங்கவும்';

  @override
  String get sellAnimal => 'கால்நடை விற்கவும்';

  @override
  String get otherServices => 'மற்ற சேவைகள்';

  @override
  String get knowMore => 'மேலும் தெரிந்துகொள்';

  @override
  String get clicklive => 'நேரலை பார்வை';

  @override
  String get insurance => 'காப்பீடு';

  @override
  String get health => 'சுகாதாரம்';

  @override
  String get liverace => 'நேரலை பந்தயங்கள்';

  @override
  String get feed => 'மேய்ச்சல்';

  @override
  String get getLocation => 'இருப்பிடத்தைப் பெறுக';

  @override
  String get getLocationMessage => 'உங்கள் பசுவிற்கு இருப்பிடத்தைப் பெறுக 📍';

  @override
  String get comingSoon => 'விரைவில் வருகிறது';

  @override
  String get firstUsers => 'முதல் 10,000 பயனர்களுக்கு கிடைக்கும்';

  @override
  String get referralBonusOnly => 'பரிந்துரை போனஸ் – மட்டும்';

  @override
  String slotsLeft(Object slot) {
    return 'இடங்கள் மீதமுள்ளது!';
  }

  @override
  String get applyNow => 'இப்போது விண்ணப்பிக்கவும்';

  @override
  String get pashuLoan => 'பசு கடன்';

  @override
  String get pashuInsurance => 'பசு காப்பீடு';

  @override
  String get investInFarming => 'விவசாயத்தில் முதலீடு செய்க';

  @override
  String get growWealth =>
      'இயற்கையுடன் உங்கள் செல்வத்தை வளர்த்துக் கொள்ளுங்கள்';

  @override
  String get startInvesting => 'முதலீடு செய்ய தொடங்குங்கள்';

  @override
  String get editProfile => 'சுயவிவரத்தைத் திருத்து';

  @override
  String get animalHistory => 'விலங்கு பட்டியல் வரலாறு';

  @override
  String get referralCode => 'பரிந்துரை குறியீடு';

  @override
  String get logout => 'வெளியேறு';

  @override
  String get yourListedPashu => 'உங்கள் பட்டியலிடப்பட்ட பசுக்கள்';

  @override
  String get termsPrivacy => 'விதிமுறைகள் மற்றும் தனியுரிமை';

  @override
  String get contactUs => 'எங்களை தொடர்பு கொள்ளுங்கள்';

  @override
  String get account => 'கணக்கு';

  @override
  String get soldOutPashuHistory => 'விற்பனையான பசு வரலாறு';

  @override
  String get walletBalance => 'வாலட் பேலன்ஸ்';

  @override
  String get addAmountInWallet => 'பணப்பையில் தொகையைச் சேர்க்கவும்';

  @override
  String get myTransaction => 'எனது பரிவர்த்தனை';

  @override
  String get addMoneyToWallet => 'உங்கள் பணப்பையில் பணம் சேர்க்கவும்';

  @override
  String get enterAmount => 'தொகையை உள்ளிடவும்';

  @override
  String get enterAmountExample => 'எடுத்துக்காட்டு: 500 உள்ளிடவும்';

  @override
  String get add => 'சேர்க்கவும்';

  @override
  String get walletTip =>
      'குறிப்பு: உங்கள் பணப்பை உடனடியாக தொடர்பு விவரங்களை காண பயன்படுத்தலாம்.';

  @override
  String get getVerifiedPashu => 'உங்கள் பசுவை சரிபார்க்கவும்';

  @override
  String get withdrawBalance => 'பேலன்ஸை எடுக்கவும்';

  @override
  String get signIn => 'உள்நுழைய';

  @override
  String get enterPhoneNumberToContinue =>
      'தொடர உங்கள் கைபேசி எண்ணை உள்ளிடவும்';

  @override
  String get phoneNumber => 'தொலைபேசி எண்';

  @override
  String get enterPhoneNumber => 'கைபேசி எண்ணை உள்ளிடவும்';

  @override
  String get sendOTP => 'ஓடிபி அனுப்பவும்';

  @override
  String get or => 'அல்லது';

  @override
  String get dontHaveAccount => 'கணக்கு இல்லையா? இப்போதே பதிவு செய்யவும்';

  @override
  String get phoneNumberRequired => 'கைபேசி எண் தேவை';

  @override
  String get enterValidPhoneNumber =>
      'சரியான 10 இலக்க இந்திய கைபேசி எண்ணை உள்ளிடவும்';

  @override
  String otpSentTo(Object phoneNumber) {
    return 'ஓடிபி +91 $phoneNumber க்கு அனுப்பப்பட்டது';
  }

  @override
  String get register => 'பதிவு செய்க';

  @override
  String get login => 'உள்நுழைவு';

  @override
  String get registerNow => 'இப்போதே பதிவு செய்யவும்';

  @override
  String get enterYourName => 'உங்கள் பெயரை உள்ளிடவும்';

  @override
  String get enterReferralCode => 'பரிந்துரை குறியீட்டை உள்ளிடவும் (விருப்பம்)';

  @override
  String get getOTP => 'ஓடிபி பெறுக';

  @override
  String get alreadyHaveAccount => 'ஏற்கனவே கணக்கு உள்ளதா? உள்நுழையவும்';

  @override
  String get optional => 'விருப்பம்';

  @override
  String get nameIsRequired => 'பெயர் தேவை';

  @override
  String get nameMinLength => 'பெயர் குறைந்தது 2 எழுத்துகள் இருக்க வேண்டும்';

  @override
  String get failedToSendOTP =>
      'ஓடிபி அனுப்ப முடியவில்லை. மீண்டும் முயற்சிக்கவும்.';

  @override
  String get enterOTP => 'ஓடிபி உள்ளிடவும்';

  @override
  String otpSentMessage(Object phoneNumber) {
    return 'நாங்கள் +91 $phoneNumber க்கு 6 இலக்க ஓடிபி அனுப்பியுள்ளோம்';
  }

  @override
  String get enterComplete6DigitOTP =>
      'தயவு செய்து முழுமையான 6 இலக்க ஓடிபி உள்ளிடவும்';

  @override
  String get successfulLogin => 'வெற்றிகரமான உள்நுழைவு';

  @override
  String get didntReceiveOTP => 'ஓடிபி கிடைக்கவில்லையா?';

  @override
  String resendIn(Object seconds) {
    return '$seconds விநாடிகளில் மீண்டும் அனுப்பவும்';
  }

  @override
  String get resendOTP => 'ஓடிபி மீண்டும் அனுப்பவும்';

  @override
  String get resending => 'மீண்டும் அனுப்புகிறது...';

  @override
  String otpResentTo(Object phoneNumber) {
    return 'ஓடிபி +91 $phoneNumber க்கு மீண்டும் அனுப்பப்பட்டது';
  }

  @override
  String get failedToResendOTP =>
      'ஓடிபி மீண்டும் அனுப்ப முடியவில்லை. மீண்டும் முயற்சிக்கவும்.';

  @override
  String get homeScreen => 'முகப்பு';

  @override
  String get welcomeToHomeScreen => 'முகப்பு திரைக்கு வரவேற்கிறோம்!';

  @override
  String get newBadge => 'புதியது';

  @override
  String get logoutConfirmation =>
      'நீங்கள் உங்கள் கணக்கிலிருந்து வெளியேற விரும்புகிறீர்களா?';

  @override
  String get cancel => 'ரத்து செய்';

  @override
  String get failedToLoadProfile => 'சுயவிவரத்தை ஏற்ற முடியவில்லை';

  @override
  String get uploadPashuImageOne => 'உங்கள் பசு படம் ஒன்றை பதிவேற்றவும்';

  @override
  String get selectPictureOne => 'படம் ஒன்று தேர்ந்தெடுக்கவும்';

  @override
  String get uploadPashuImageTwo => 'உங்கள் பசு படம் இரண்டை பதிவேற்றவும்';

  @override
  String get selectPictureTwo => 'படம் இரண்டு தேர்ந்தெடுக்கவும்';

  @override
  String get paymentCompletedSuccessfully =>
      'பணம் செலுத்துதல் வெற்றிகரமாக முடிந்தது!';

  @override
  String get paymentVerificationFailed =>
      'பணம் செலுத்துதல் சரிபார்த்தல் தோல்வியடைந்தது. தயவுசெய்து மீண்டும் முயற்சிக்கவும்.';

  @override
  String get errorVerifyingPayment => 'கட்டணத்தை சரிபார்க்கும் போது பிழை';

  @override
  String get insuranceApplication => 'காப்பீடு விண்ணப்பம்';

  @override
  String get responseReceived => 'பதில் பெறப்பட்டது!';

  @override
  String get insuranceThankYouMessage =>
      'உங்கள் பசு காப்பீடு விண்ணப்பத்தை சமர்ப்பித்ததற்கு நன்றி. மேலும் விவரங்களுக்கு எங்கள் குழு விரைவில் உங்களை தொடர்புகொள்வார்கள்.';

  @override
  String get selectLanguage => 'மொழியை தேர்ந்தெடுக்கவும்';

  @override
  String get ok => 'சரி';

  @override
  String get appTitle => 'பசு குடும்பம்';

  @override
  String get languageShort => 'हि/E/ತ';

  @override
  String get wishlist => 'விஷ்லிஸ்ட்';

  @override
  String get loanFormTitle => 'பசு கடன் படிவம்';

  @override
  String get loanApplicationHeader => 'பசு கடன் விண்ணப்பம்';

  @override
  String get loanApplicationSubheader =>
      'உங்கள் கால்நடை விவசாய தேவைகளுக்கு நிதி உதவி பெறுங்கள்';

  @override
  String get loanApplicationDetails => 'கடன் விண்ணப்ப விவரங்கள்';

  @override
  String get applicantInformation => 'விண்ணப்பதாரர் தகவல்';

  @override
  String get applicantName => 'விண்ணப்பதாரர் பெயர்';

  @override
  String get applicantNameRequired => 'விண்ணப்பதாரர் பெயர் தேவை';

  @override
  String get applicantAddress => 'விண்ணப்பதாரர் முகவரி';

  @override
  String get applicantAddressRequired => 'விண்ணப்பதாரர் முகவரி தேவை';

  @override
  String get contactNumber => 'தொடர்பு எண்';

  @override
  String get contactNumberRequired => 'தொடர்பு எண் தேவை';

  @override
  String get contactNumberInvalid => 'சரியான தொடர்பு எண்ணை உள்ளிடவும்';

  @override
  String get emailAddress => 'மின்னஞ்சல் முகவரி';

  @override
  String get emailAddressRequired => 'மின்னஞ்சல் முகவரி தேவை';

  @override
  String get emailAddressInvalid => 'சரியான மின்னஞ்சல் முகவரியை உள்ளிடவும்';

  @override
  String get loanInformation => 'கடன் தகவல்';

  @override
  String get loanAmount => 'கடன் தொகை (₹)';

  @override
  String get loanAmountRequired => 'கடன் தொகை தேவை';

  @override
  String get loanAmountInvalid => 'சரியான கடன் தொகையை உள்ளிடவும்';

  @override
  String get repaymentPeriod => 'திருப்பிச் செலுத்தும் காலம்';

  @override
  String get repaymentPeriodRequired => 'திருப்பிச் செலுத்தும் காலம் தேவை';

  @override
  String get incomeSource => 'வருமான மூலம்';

  @override
  String get incomeSourceRequired => 'வருமான மூலம் தேவை';

  @override
  String get purposeOfLoan => 'கடனின் நோக்கம்';

  @override
  String get purposeOfLoanRequired => 'கடனின் நோக்கம் தேவை';

  @override
  String get additionalInformation => 'கூடுதல் தகவல்';

  @override
  String get additionalRemarks => 'கூடுதல் குறிப்புகள்';

  @override
  String get additionalRemarksRequired => 'கூடுதல் குறிப்புகள் தேவை';

  @override
  String get submittingForm => 'படிவம் சமர்ப்பிக்கப்படுகிறது...';

  @override
  String get submitForm => 'படிவத்தை சமர்ப்பிக்கவும்';

  @override
  String get loanTermsNote =>
      'இந்த படிவத்தை சமர்ப்பிப்பதன் மூலம், நீங்கள் எங்கள் கடன் விதிமுறைகள் மற்றும் நிபந்தனைகளை ஒப்புக்கொள்கிறீர்கள். எங்கள் குழு உங்கள் விண்ணப்பத்தை மதிப்பாய்ந்து 3-5 வணிக நாட்களில் கடன் ஒப்புதல் நிலையைத் தொடர்புகொள்கிறது.';

  @override
  String get allFieldsRequired => 'அனைத்து புலங்கள் தேவை';

  @override
  String get animalInformation => 'விலங்கு தகவல்';

  @override
  String get animalAgeInvalid => 'சரியான விலங்கு வயதை உள்ளிடவும்';

  @override
  String get animalWeightInvalid => 'சரியான விலங்கு எடையை உள்ளிடவும்';

  @override
  String get allowLocationAccess => 'இடத்தை அணுக அனுமதிக்கவும்';

  @override
  String get locationDescription =>
      'உங்கள் பகுதியில் அருகிலுள்ள கால்நடைகள், நிகழ்வுகள் மற்றும் தனிப்பயன் உள்ளடக்கங்களை காண உங்கள் இடம் தேவை.';

  @override
  String get locationPrivacyNote =>
      'உங்கள் இடத் தரவு பாதுகாப்பாக உள்ளது மற்றும் உங்கள் அனுபவத்தை மேம்படுத்த மட்டுமே பயன்படுத்தப்படுகிறது.';

  @override
  String get liveRaces => 'நேரடி போட்டிகள்';

  @override
  String get viewLive => 'நேரடி பார்க்கவும்';

  @override
  String get animalInsurance => 'கால்நடை காப்பீடு';

  @override
  String get insuranceFormTitle => 'கால்நடை காப்பீடு படிவம்';

  @override
  String get insuranceApplicationHeader => 'கால்நடை காப்பீடு விண்ணப்பம்';

  @override
  String get insuranceApplicationSubheader =>
      'உங்கள் கால்நடை காப்பீடு தேவைகளுக்கு நிதி உதவி பெறுங்கள்';

  @override
  String get insuranceApplicationDetails => 'காப்பீடு விண்ணப்ப விவரங்கள்';

  @override
  String get ownerInformation => 'உரிமையாளர் தகவல்';

  @override
  String get ownerName => 'உரிமையாளர் பெயர்';

  @override
  String get ownerNameRequired => 'உரிமையாளர் பெயர் தேவை';

  @override
  String get ownerAddress => 'உரிமையாளர் முகவரி';

  @override
  String get ownerAddressRequired => 'உரிமையாளர் முகவரி தேவை';

  @override
  String get animalType => 'விலங்கு வகை';

  @override
  String get animalTypeRequired => 'விலங்கு வகை தேவை';

  @override
  String get animalBreed => 'விலங்கு இனம்';

  @override
  String get animalBreedRequired => 'விலங்கு இனம் தேவை';

  @override
  String get animalAge => 'விலங்கு வயது';

  @override
  String get animalAgeRequired => 'விலங்கு வயது தேவை';

  @override
  String get animalColor => 'விலங்கு நிறம்';

  @override
  String get animalColorRequired => 'விலங்கு நிறம் தேவை';

  @override
  String get animalWeight => 'விலங்கு எடை';

  @override
  String get animalWeightRequired => 'விலங்கு எடை தேவை';

  @override
  String get healthStatus => 'ஆரோக்கிய நிலை';

  @override
  String get healthStatusRequired => 'ஆரோக்கிய நிலை தேவை';

  @override
  String get insuranceTermsNote =>
      'இந்த படிவத்தை சமர்ப்பிப்பதன் மூலம், நீங்கள் எங்கள் காப்பீடு விதிமுறைகள் மற்றும் நிபந்தனைகளை ஒப்புக்கொள்கிறீர்கள். எங்கள் குழு உங்கள் விண்ணப்பத்தை மதிப்பாய்ந்து 3-5 வணிக நாட்களில் காப்பீடு ஒப்புதல் நிலையைத் தொடர்புகொள்கிறது.';

  @override
  String get liveRaceTitle => 'லைவ் ரேஸ்';

  @override
  String get liveRaceHeader => 'லைவ் ரேஸ்';

  @override
  String get chooseRaceCategory => 'உங்கள் ரேஸ் வகையை தேர்ந்தெடுக்கவும்';

  @override
  String get raceExperienceSubheader =>
      'பாரம்பரிய மிருக ஓட்டத்தின் பரபரப்பை அனுபவிக்கவும்';

  @override
  String get raceCategoryFallback => 'ரேஸ் வகை';

  @override
  String get raceCategoryDetailFallback =>
      'சுவாரஸ்யமான ரேஸில் சேரவும், பாரம்பரிய மிருக ஓட்டத்தின் பரபரப்பை அனுபவிக்கவும்';

  @override
  String get liveNow => 'இப்போது நேரலை';

  @override
  String get tapToJoin => 'சேர டேப் செய்யவும்';

  @override
  String get liveBadge => 'லைவ்';

  @override
  String get failedToLoadCategories => 'வகைகளை ஏற்ற முடியவில்லை';

  @override
  String get somethingWentWrong => 'ஏதோ தவறு நடந்தது';

  @override
  String get retry => 'மீண்டும் முயற்சிக்கவும்';

  @override
  String get noLiveRacesAvailable => 'லைவ் ரேஸ்கள் இல்லை';

  @override
  String get checkBackLater =>
      'சுவாரஸ்யமான லைவ் ரேசிங் நிகழ்வுகளுக்காக பின்னர் சரிபார்க்கவும்';

  @override
  String get raceCategory => 'பந்தய வகை';

  @override
  String get traditionalRacingExperience => 'பாரம்பரிய பந்தய அனுபவம்';

  @override
  String get raceInformation => 'பந്தய தகவல்';

  @override
  String get category => 'வகை';

  @override
  String get status => 'நிலை';

  @override
  String get participants => 'பங்கேற்பாளர்கள்';

  @override
  String get multipleEntries => 'பல பதிவுகள்';

  @override
  String get duration => 'கால அளவு';

  @override
  String get ongoing => 'நடைபெற்று வரும்';

  @override
  String get prize => 'பரிசு';

  @override
  String get trophiesAndRecognition => 'கோப்பைகள் மற்றும் அங்கீகாரம்';

  @override
  String get raceIsLiveNow => 'பந்தயம் இப்போது நேரலையில்!';

  @override
  String get watchExcitingCompetition => 'உற்சாகமான போட்டியைப் பார்க்கவும்';

  @override
  String get aboutThisRace => 'இந்த பந்தயம் பற்றி';

  @override
  String get defaultRaceDescription =>
      'இந்த உற்சாகமான நேரலை நிகழ்வில் பாரம்பரிய விலங்கு பந்தயத்தின் சிலிர்ப்பை அனுபவிக்கவும். மனிதர்களுக்கும் விலங்குகளுக்கும் இடையிலான பிணைப்பை வெளிப்படுத்தும் இந்த காலத்தால் மதிக்கப்படும் பாரம்பரியத்தில் திறமையான பங்கேற்பாளர்கள் போட்டியிடுவதைப் பாருங்கள்.';

  @override
  String get liveStream => 'நேரலை ஒளிபரப்பு';

  @override
  String get liveStreamComingSoon => 'நேரலை ஒளிபரப்பு விரைவில் வருகிறது';

  @override
  String get youtubeLinksAvailable =>
      'ஸ்ட்ரீமிங் தொடங்கும்போது YouTube இணைப்புகள் கிடைக்கும்';

  @override
  String get getNotifiedWhenStreaming =>
      'இந்த பந்தய வகைக்கு நேரலை ஒளிபரப்பு தொடங்கும்போது அறிவிப்பு பெறுங்கள்';

  @override
  String get liveRace => 'நேரலை பந்தயம்';

  @override
  String get na => 'கிடைக்கவில்லை';

  @override
  String get regionalChampionship => 'பிராந்திய சாம்பியன்ஷிப்';

  @override
  String get districtFinals => 'மாவட்ட இறுதிப்போட்டி';

  @override
  String get stateCompetition => 'மாநில போட்டி';

  @override
  String get tomorrowTenAM => 'நாளை காலை 10:00 மணிக்கு';

  @override
  String get nextWeek => 'அடுத்த வாரம்';

  @override
  String get sellPashu => 'பசு விற்கவும்';

  @override
  String get youCanProceedWithListing => 'நீங்கள் பட்டியலிடலைத் தொடரலாம்';

  @override
  String get minimumRequiredToList =>
      'உங்கள் விலங்கைப் பட்டியலிட குறைந்தபட்சம் ₹15 தேவை';

  @override
  String get animalTypes => 'விலங்கு வகைகள்';

  @override
  String get selectAnimalType => 'விலங்கு வகையைத் தேர்ந்தெடுக்கவும்';

  @override
  String get animalCategory => 'விலங்கு வகை';

  @override
  String get pleaseSelectAnimalTypeFirst =>
      'தயவுசெய்து முதலில் விலங்கு வகையைத் தேர்ந்தெடுக்கவும்';

  @override
  String get selectAnimalCategory => 'விலங்கு வகையைத் தேர்ந்தெடுக்கவும்';

  @override
  String get nameOfTheAnimal => 'விலங்கின் பெயர்';

  @override
  String get enterAnimalAge => 'விலங்கின் வயதை உள்ளிடவும்';

  @override
  String get selectGenderOfAnimal => 'விலங்கின் பாலினத்தைத் தேர்ந்தெடுக்கவும்';

  @override
  String get price => 'விலை';

  @override
  String get negotiable => 'பேரம்';

  @override
  String get isPriceNegotiable => 'விலை பேரம் போடலாமா?';

  @override
  String get yourPhoneNumber => 'உங்கள் தொலைபேசி எண்';

  @override
  String get enterYourPhoneNumber => 'உங்கள் தொலைபேசி எண்ணை உள்ளிடவும்';

  @override
  String get animalDescription => 'விலங்கு விளக்கம்';

  @override
  String get enterAnimalDescription => 'விலங்கு விளக்கத்தை உள்ளிடவும்';

  @override
  String get getAddressForPashu => 'பசுவுக்கான முகவரியைப் பெறவும்';

  @override
  String get submitAndPay => 'சமர்ப்பித்து ₹15 செலுத்தவும்';

  @override
  String get insufficientBalance =>
      'போதிய பேலன்ஸ் இல்லை. தயவுசெய்து நிதி சேர்க்கவும்।';

  @override
  String get submitting => 'சமர்ப்பிக்கிறோம்...';

  @override
  String get locationServicesDisabled => 'இருப்பிட சேவைகள் முடக்கப்பட்டுள்ளன';

  @override
  String get locationPermissionPermanentlyDenied =>
      'இருப்பிட அனுமதி நிரந்தரமாக மறுக்கப்பட்டது';

  @override
  String get locationPermissionDenied => 'இருப்பிட அனுமதி மறுக்கப்பட்டது';

  @override
  String get unableToDetermineAddress => 'முகவரியைத் தீர்மானிக்க முடியவில்லை';

  @override
  String get error => 'பிழை';

  @override
  String get missingRequiredFields => 'தேவையான புலங்கள் விடுபட்டுள்ளன';

  @override
  String get pleaseEnterValidPhoneNumber =>
      'தயவுசெய்து சரியான தொலைபேசி எண்ணை உள்ளிடவும்';

  @override
  String get pleaseEnterValidAge => 'தயவுசெய்து சரியான வயதை உள்ளிடவும்';

  @override
  String get pleaseEnterValidPrice => 'தயவுசெய்து சரியான விலையை உள்ளிடவும்';

  @override
  String get pashuListedSuccessfully => 'பசு வெற்றிகரமாகப் பட்டியலிடப்பட்டது!';

  @override
  String get errorOccurred => 'ஒரு பிழை ஏற்பட்டது';

  @override
  String get selectCategory => 'வகையைத் தேர்ந்தெடுக்கவும்';

  @override
  String get selectGender => 'பாலினத்தைத் தேர்ந்தெடுக்கவும்';

  @override
  String get male => 'ஆண்';

  @override
  String get female => 'பெண்';

  @override
  String get user => 'பயனர்';

  @override
  String get other => 'மற்றவை';

  @override
  String get unknown => 'தெரியாது';

  @override
  String get traditionalSportsAnimal => 'பாரம்பரிய விளையாட்டு விலங்கு';

  @override
  String get livestockAnimal => 'கால்நடை விலங்கு';

  @override
  String get petAnimal => 'செல்லப் பிராணி';

  @override
  String get farmHouseAnimal => 'பண்ணை வீட்டு விலங்கு';

  @override
  String get bull => 'காளை';

  @override
  String get camel => 'ஒட்டகம்';

  @override
  String get bird => 'பறவை';

  @override
  String get pigeon => 'புறா';

  @override
  String get cock => 'சேவல்';

  @override
  String get dog => 'நாய்';

  @override
  String get goat => 'ஆடு';

  @override
  String get horse => 'குதிரை';

  @override
  String get buffalo => 'எருமை';

  @override
  String get sheep => 'செம்மரியாடு';

  @override
  String get pigs => 'பன்றிகள்';

  @override
  String get cat => 'பூனை';

  @override
  String get fishes => 'மீன்கள்';

  @override
  String get smallMammals => 'சிறிய பாலூட்டிகள்';

  @override
  String get searchAnimalsBreeds => 'விலங்குகள், இனங்களைத் தேடுங்கள்...';

  @override
  String get unknownAnimal => 'தெரியாத விலங்கு';

  @override
  String get breed => 'இனம்';

  @override
  String get owner => 'உரிமையாளர்';

  @override
  String get callMe => 'எனக்கு அழைப்பு செய்யுங்கள்';

  @override
  String get buyNow => 'இப்போது வாங்குங்கள்';

  @override
  String get addedToWishlist => 'விஷ்லிஸ்ட்டில் சேர்க்கப்பட்டது';

  @override
  String get animal => 'விலங்கு';

  @override
  String get failedToAddToWishlist => 'விஷ்லிஸ்ட்டில் சேர்க்கத் தவறிவிட்டது';

  @override
  String get noAnimalsFound => 'விலங்குகள் எதுவும் கிடைக்கவில்லை';

  @override
  String get trySelectingDifferentCategory =>
      'வேறு வகையைத் தேர்ந்தெடுக்க முயற்சிக்கவும்';

  @override
  String get checkBackLaterForNewListings =>
      'புதிய பட்டியல்களுக்கு பின்னர் சரிபார்க்கவும்';

  @override
  String get purchaseRequestSent => 'வாங்குவதற்கான கோரிக்கை அனுப்பப்பட்டது';

  @override
  String get all => 'அனைத்தும்';

  @override
  String get cow => 'பசு';

  @override
  String get cats => 'பூனைகள்';

  @override
  String get animalDetails => 'விலங்கு விவரங்கள்';

  @override
  String get photos => 'புகைப்படங்கள்';

  @override
  String get type => 'வகை';

  @override
  String get age => 'வயது';

  @override
  String get gender => 'பாலினம்';

  @override
  String get years => 'ஆண்டுகள்';

  @override
  String get pricingInformation => 'விலை தகவல்';

  @override
  String get fixedPrice => 'நிர்ணய விலை';

  @override
  String get ownerAndLocation => 'உரிமையாளர் மற்றும் இடம்';

  @override
  String get location => 'இடம்';

  @override
  String get distance => 'தூரம்';

  @override
  String get notSpecified => 'குறிப்பிடப்படவில்லை';

  @override
  String get meters => 'மீட்டர்';

  @override
  String get km => 'கிமீ';

  @override
  String get description => 'விளக்கம்';

  @override
  String get contactSeller => 'விற்பனையாளரை தொடர்பு கொள்ளுங்கள்';

  @override
  String get unlockContactDetails =>
      'விற்பனையாளருடன் இணைக்க ₹2க்கு தொடர்பு விவரங்களை திறக்கவும்';

  @override
  String get unlocking => 'திறக்கிறது...';

  @override
  String get unlockContact => 'தொடர்பை திறக்கவும் (₹2)';

  @override
  String get contactOptions => 'தொடர்பு விருப்பங்கள்';

  @override
  String get call => 'அழைப்பு';

  @override
  String get whatsApp => 'வாட்ஸ்அப்';

  @override
  String get contact => 'தொடர்பு';

  @override
  String get notAvailable => 'கிடைக்கவில்லை';

  @override
  String get userNotLoggedIn => 'பயனர் உள்நுழையவில்லை';

  @override
  String get userDataNotFound => 'பயனர் தரவு கிடைக்கவில்லை';

  @override
  String get contactAlreadyUnlocked =>
      'இந்த தொடர்பு ஏற்கனவே திறக்கப்பட்டுள்ளது।';

  @override
  String get contactUnlockedSuccessfully =>
      'தொடர்பு வெற்றிகரமாக திறக்கப்பட்டது!';

  @override
  String get couldNotLaunchPhoneApp => 'ஃபோன் ஆப்பைத் திறக்க முடியவில்லை';

  @override
  String get phoneNumberNotAvailable => 'ஃபோன் எண் கிடைக்கவில்லை';

  @override
  String get couldNotOpenWhatsApp => 'வாட்ஸ்அப்பை திறக்க முடியவில்லை';

  @override
  String whatsAppMessageTemplate(Object animalName) {
    return 'வணக்கம், பசு பரிவாரில் பட்டியலிடப்பட்ட உங்கள் $animalNameல் எனக்கு ஆர்வம் உள்ளது।';
  }

  @override
  String get locationNotAvailable => 'இருப்பிடம் கிடைக்கவில்லை';

  @override
  String get remove => 'அகற்றவும்';

  @override
  String get removedFromWishlist => 'விஷ்லிஸ்ட்டில் இருந்து அகற்றப்பட்டது';

  @override
  String get failedToRemove => 'அகற்றுவதில் தோல்வி';

  @override
  String get animalDetailsComingSoon => 'விலங்கு விவரங்கள் விரைவில் வருகின்றன';

  @override
  String get fullAnimalDetailsModal =>
      'முழு விலங்கு விவரங்கள் மாடல் இங்கே செயல்படுத்தப்படும்';

  @override
  String get noWishlistAnimalsFound =>
      'விஷ்லிஸ்ட் விலங்குகள் எதுவும் கிடைக்கவில்லை';

  @override
  String get tryAddingAnimalsToWishlist =>
      'உங்கள் விஷ்லிஸ்ட்டில் சில விலங்குகளைச் சேர்க்க முயற்சிக்கவும்!';

  @override
  String get investmentProject => 'முதலீட்டு திட்டம்';

  @override
  String get upcomingProjects => 'வரவிருக்கும் திட்டங்கள்';

  @override
  String get liveProjects => 'நேரலை திட்டங்கள்';

  @override
  String get completedProjects => 'முடிக்கப்பட்ட திட்டங்கள்';

  @override
  String get mvpForAquacultureInvestment => 'நீர்வளர்ப்பு முதலீட்டிற்கான MVP';

  @override
  String get longTerm => 'நீண்ட கால';

  @override
  String get amount => 'தொகை';

  @override
  String get startDate => 'தொடக்க தேதி';

  @override
  String get sixToEightMonths => '6 முதல் 8 மாதங்கள்';

  @override
  String get lotsBooked => 'லாட்கள் பதிவு செய்யப்பட்டுள்ளன';

  @override
  String get noProjectsAvailable => 'திட்டங்கள் எதுவும் கிடைக்கவில்லை।';

  @override
  String get firstAugust2025 => '1 ஆகஸ்ட் 2025';

  @override
  String get addAmountAndGetPlans => 'தொகையைச் சேர்த்து திட்டங்களைப் பெறுங்கள்';

  @override
  String get getVerifiedYourPashu => 'உங்கள் பசுவை சரிபார்க்கவும்';

  @override
  String get termsAndPrivacy => 'நியமங்கள் மற்றும் தனியுரிமை';

  @override
  String get newA => 'புதிய';

  @override
  String get areYouSureLogout =>
      'நீங்கள் உங்கள் கணக்கிலிருந்து வெளியேற விரும்புகிறீர்களா?';

  @override
  String get noProfileFound => 'சுயவிவரம் கிடைக்கவில்லை';

  @override
  String get profileInformationNotAvailable => 'சுயவிவர தகவல் கிடைக்கவில்லை';

  @override
  String get subscriptionPlans => 'சந்தா திட்டங்கள்';

  @override
  String get chooseYourPlan => 'உங்கள் திட்டத்தைத் தேர்ந்தெடுக்கவும்';

  @override
  String get unlockPremiumFeatures =>
      'பிரீமியம் அம்சங்களை அன்லாக் செய்து எங்கள் சந்தா திட்டங்களுடன் உங்கள் கால்நடை வணிகத்தை வளர்க்கவும்';

  @override
  String get diamondPlan => 'டயமண்ட் திட்டம்';

  @override
  String get goldPlan => 'தங்க திட்டம்';

  @override
  String get silverPlan => 'வெள்ளி திட்டம்';

  @override
  String get year => 'ஆண்டு';

  @override
  String get months3 => '3 மாதங்கள்';

  @override
  String get month => 'மாதம்';

  @override
  String get choosePlan => 'திட்டத்தைத் தேர்ந்தெடுக்கவும்';

  @override
  String get unlimitedPashuProfileContact => 'வரம்பற்ற பசு சுயவிவர தொடர்பு';

  @override
  String get unlimitedFreePashuListings => 'வரம்பற்ற இலவச பசு பட்டியல்கள்';

  @override
  String get priorityCustomerSupport => 'முன்னுரிமை வாடிக்கையாளர் ஆதரவு';

  @override
  String get advancedAnalytics => 'மேம்பட்ட பகுப்பாய்வு';

  @override
  String get premiumBadge => 'பிரீமியம் பேட்ஜ்';

  @override
  String get freePashuListings10 => '10 இலவச பசு பட்டியல்கள்';

  @override
  String get standardCustomerSupport => 'நிலையான வாடிக்கையாளர் ஆதரவு';

  @override
  String get basicAnalytics => 'அடிப்படை பகுப்பாய்வு';

  @override
  String get freePashuListings2 => '2 இலவச பசு பட்டியல்கள்';

  @override
  String get emailSupport => 'மின்னஞ்சல் ஆதரவு';

  @override
  String get addMoneyToYourWallet => 'உங்கள் வாலட்டில் பணம் சேர்க்கவும்';

  @override
  String get addFundsToWallet =>
      'உங்கள் வாலட்டில் நிதி சேர்த்து, சந்தாக்களுக்கு எளிதாக பணம் செலுத்துங்கள். உங்கள் வாலட் எங்கள் அனைத்து சேவைகளிலும் பயன்படுத்தப்படும்.';

  @override
  String get enterAmountEg500 => 'தொகையை உள்ளிடவும் (எ.கா. 500)';

  @override
  String addAmount(String amount) {
    return '₹$amount சேர்க்கவும்';
  }

  @override
  String get tipWalletContact =>
      'உதவிக்குறிப்பு: தொடர்பு விவரங்களை உடனடியாக பார்க்க உங்கள் வாலட்டைப் பயன்படுத்தலாம்.';

  @override
  String subscribeToPlan(String planName) {
    return 'Subscribe to $planName';
  }

  @override
  String chargedForSubscription(String price, String period) {
    return 'இந்த $period சந்தாவுக்கு உங்களிடம் ₹$price வசூலிக்கப்படும்.';
  }

  @override
  String get confirmSubscription => 'சந்தாவை உறுதிப்படுத்தவும்';

  @override
  String get subscriptionSuccessful => 'சந்தா வெற்றிகரமாக!';

  @override
  String subscriptionSuccessMessage(String planName) {
    return 'நீங்கள் வெற்றிகரமாக $planNameக்கு சந்தா செய்துள்ளீர்கள். அனைத்து பிரீமியம் அம்சங்களையும் அனுபவிக்கவும்!';
  }

  @override
  String get continueA => 'தொடரவும்';

  @override
  String get subscriptionHelp => 'சந்தா உதவி';

  @override
  String get helpContent =>
      '• டயமண்ட் திட்டம்: ₹365/ஆண்டு\n• தங்க திட்டம்: ₹140/3 மாதங்கள்\n• வெள்ளி திட்டம்: ₹49/மாதம்\n• உங்கள் சுயவிவரத்திலிருந்து எப்போது வேண்டுமானாலும் ரத்து செய்யவும்\n• அனைத்து அம்சங்களும் உடனடியாக அன்லாக் ஆகும்\n• 24/7 வாடிக்கையாளர் ஆதரவு சேர்க்கப்பட்டுள்ளது';

  @override
  String get gotIt => 'புரிந்தது';

  @override
  String get pleaseEnterValidAmount => 'தயவுசெய்து சரியான தொகையை உள்ளிடவும்';

  @override
  String get couldNotInitiatePayment => 'பணம் செலுத்துதலை தொடங்க முடியவில்லை';

  @override
  String get somethingWentWrongPayment =>
      'பணம் செலுத்துதலில் ஏதோ தவறு நடந்தது.';

  @override
  String get paymentCancelled =>
      'பணம் செலுத்துதல் ரத்து செய்யப்பட்டது அல்லது சரியான நேரத்தில் முடிக்கப்படவில்லை.';

  @override
  String get paymentFailed => 'பணம் செலுத்துதல் தோல்வியடைந்தது';

  @override
  String get externalWalletSelected => 'வெளிப்புற வாலட் தேர்ந்தெடுக்கப்பட்டது';

  @override
  String get getInTouch => 'தொடர்பில் இருங்கள்';

  @override
  String get contactUsDescription =>
      'நாங்கள் உதவ இங்கே இருக்கிறோம்! எந்த நேரத்திலும் எங்களை அணுகுங்கள், முடிந்தவரை விரைவில் நாங்கள் உங்களிடம் திரும்புவோம்.';

  @override
  String get contactInformation => 'தொடர்பு தகவல்';

  @override
  String get officeAddress => 'அலுவலக முகவரி';

  @override
  String get pashuParivarHeadquarters =>
      'பசு பரிவார் தலைமையகம்\nபோபால், மத்திய பிரதேசம்\nஇந்தியா';

  @override
  String get sendUsAMessage => 'எங்களுக்கு செய்தி அனுப்புங்கள்';

  @override
  String get fullName => 'முழுப் பெயர்';

  @override
  String get enterYourFullName => 'உங்கள் முழு பெயரை உள்ளிடவும்';

  @override
  String get enterYourEmailAddress => 'உங்கள் மின்னஞ்சல் முகவரியை உள்ளிடவும்';

  @override
  String get message => 'செய்தி';

  @override
  String get tellUsHowWeCanHelp =>
      'நாங்கள் உங்களுக்கு எவ்வாறு உதவ முடியும் என்று சொல்லுங்கள்...';

  @override
  String get sendingMessage => 'செய்தி அனுப்புகிறது...';

  @override
  String get sendMessage => 'செய்தி அனுப்பு';

  @override
  String get responseTimeNote =>
      'நாங்கள் பொதுவாக வணிக நாட்களில் 24 மணி நேரத்திற்குள் பதிலளிக்கிறோம்.';

  @override
  String get followUs => 'எங்களைப் பின்தொடருங்கள்';

  @override
  String get stayUpdatedWithNews =>
      'எங்கள் சமீபத்திய செய்திகள் மற்றும் புதுப்பிப்புகளுடன் புதுப்பித்த நிலையில் இருங்கள்';

  @override
  String get facebook => 'பேஸ்புக்';

  @override
  String get instagram => 'இன்ஸ்டாகிராம்';

  @override
  String get twitter => 'ட்விட்டர்';

  @override
  String get youtube => 'யூட்யூப்';

  @override
  String get copiedToClipboard => 'கிளிப்போர்டுக்கு நகலெடுக்கப்பட்டது!';

  @override
  String get messageSentSuccessfully => 'செய்தி வெற்றிகரமாக அனுப்பப்பட்டது!';

  @override
  String get thankYouForContacting =>
      'எங்களைத் தொடர்பு கொண்டதற்கு நன்றி. நாங்கள் 24 மணி நேரத்திற்குள் உங்களிடம் திரும்புவோம்.';

  @override
  String get nameMustBeAtLeast2Characters =>
      'பெயர் குறைந்தது 2 எழுத்துகள் இருக்க வேண்டும்';

  @override
  String get emailIsRequired => 'மின்னஞ்சல் தேவை';

  @override
  String get pleaseEnterValidEmail =>
      'தயவுசெய்து செல்லுபடியாகும் மின்னஞ்சல் முகவரியை உள்ளிடவும்';

  @override
  String get messageIsRequired => 'செய்தி தேவை';

  @override
  String get messageMustBeAtLeast10Characters =>
      'செய்தி குறைந்தது 10 எழுத்துகள் இருக்க வேண்டும்';

  @override
  String get invest => 'விவசாய-கால்நடை வளர்ப்பில் முதலீடு செய்யுங்கள்';

  @override
  String get total => 'மொத்தம்';

  @override
  String get active => 'செயலில்';

  @override
  String get pending => 'நிலுவையில்';

  @override
  String get edit => 'திருத்து';

  @override
  String get delete => 'நீக்கு';

  @override
  String get pendingStatus => 'நிலுவையில்';

  @override
  String get failedToLoadListings => 'பட்டியல்களை ஏற்ற முடியவில்லை';

  @override
  String get noListedAnimals => 'பட்டியலிடப்பட்ட விலங்குகள் இல்லை';

  @override
  String get noListedAnimalsDescription =>
      'நீங்கள் இன்னும் எந்த விலங்குகளையும் பட்டியலிடவில்லை. உங்கள் முதல் பட்டியலைச் சேர்ப்பதன் மூலம் தொடங்குங்கள்!';

  @override
  String get addNewListing => 'புதிய பட்டியல் சேர்க்கவும்';

  @override
  String get deleteListing => 'பட்டியலை நீக்கவும்';

  @override
  String deleteConfirmation(String animalName) {
    return 'நீங்கள் நிச்சயமாக \"$animalName\"ஐ நீக்க விரும்புகிறீர்களா? இந்த செயலை மாற்ற முடியாது.';
  }

  @override
  String deleteSuccessMessage(String animalName) {
    return '$animalName வெற்றிகரமாக நீக்கப்பட்டது';
  }

  @override
  String get withdrawFromWallet => 'வாலட்டில் இருந்து பணம் எடுக்கவும்';

  @override
  String get availableBalance => 'கிடைக்கும் இருப்பு';

  @override
  String get withdrawalEligible => 'பணம் எடுக்க தகுதி';

  @override
  String get withdrawalRequirements => 'பணம் எடுக்கும் தேவைகள்';

  @override
  String youHaveSpentAndCanWithdraw(String counter) {
    return 'நீங்கள் ₹$counter செலவு செய்துள்ளீர்கள், பணம் எடுக்கலாம்';
  }

  @override
  String spendMoreToEnableWithdrawal(String amount, String counter) {
    return 'பணம் எடுக்க ₹$amount மேலும் செலவு செய்யுங்கள் (தற்போது: ₹$counter)';
  }

  @override
  String get withdrawalDetails => 'பணம் எடுக்கும் விவரங்கள்';

  @override
  String get enterAmountEg => 'தொகையை உள்ளிடவும் எ.கா. 500';

  @override
  String get enterUpiIdEg => 'UPI ID ஐ உள்ளிடவும் (எ.கா. example@upi)';

  @override
  String get enterUpiIdEgPlaceholder => 'UPI ID ஐ உள்ளிடவும் எ.கா. example@upi';

  @override
  String get processing => 'செயலாக்கம்...';

  @override
  String withdrawAmount(String amount) {
    return '₹$amount எடுக்கவும்';
  }

  @override
  String get withdrawalRequirementsLabel => 'பணம் எடுக்கும் தேவைகள்:';

  @override
  String get minimumSpendingRequired => '• குறைந்தபட்சம் ₹50 செலவு தேவை';

  @override
  String get walletBalanceRequired => '• வாலட் இருப்பு ≥ ₹100 இருக்க வேண்டும்';

  @override
  String currentSpending(String counter, String status) {
    return '• தற்போதைய செலவு: ₹$counter ($status)';
  }

  @override
  String walletBalanceStatus(String balance, String status) {
    return '• வாலட் இருப்பு: ₹$balance ($status)';
  }

  @override
  String get verified => '✓';

  @override
  String needMoreAmount(String amount) {
    return '₹$amount மேலும் தேவை';
  }

  @override
  String get tipWithdrawProcessingTime =>
      'குறிப்பு: பணம் எடுப்பது உங்கள் UPI கணக்கில் 24-48 மணி நேரத்தில் செயலாக்கப்படும்.';

  @override
  String get withdrawalRequestSubmitted =>
      'பணம் எடுக்கும் கோரிக்கை சமர்ப்பிக்கப்பட்டது!';

  @override
  String withdrawalRequestSuccessMessage(String amount) {
    return '₹$amount க்கான உங்கள் பணம் எடுக்கும் கோரிக்கை வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது. 24-48 மணி நேரத்தில் உங்கள் UPI கணக்கில் தொகை கிடைக்கும்.';
  }

  @override
  String get failedToLoadData => 'தரவை ஏற்ற முடியவில்லை';

  @override
  String get amountCannotBeEmpty => 'தொகை காலியாக இருக்க முடியாது';

  @override
  String amountCannotExceedBalance(String balance) {
    return 'தொகை வாலட் இருப்பை மீற முடியாது (₹$balance)';
  }

  @override
  String get minimumWalletBalanceRequired =>
      'குறைந்தபட்சம் ₹100 வாலட் இருப்பு தேவை';

  @override
  String get upiIdCannotBeEmpty => 'UPI ID காலியாக இருக்க முடியாது';

  @override
  String get pleaseEnterValidUpiId => 'தயவுசெய்து சரியான UPI ID ஐ உள்ளிடவும்';

  @override
  String get transactionHistory => 'பரிவர்த்தனை வரலாறு';

  @override
  String get noTransactions => 'பரிவர்த்தனைகள் இல்லை';

  @override
  String get transactionSummary => 'பரிவர்த்தனை சுருக்கம்';

  @override
  String get totalCredit => 'மொத்த கிரெடிட்';

  @override
  String get totalDebit => 'மொத்த டெபிட்';

  @override
  String get successful => 'வெற்றிகரமான';

  @override
  String get today => 'இன்று';

  @override
  String get yesterday => 'நேற்று';

  @override
  String daysAgo(String days) {
    return '$days நாட்களுக்கு முன்';
  }

  @override
  String get paymentId => 'பேமெண்ட் ID';

  @override
  String get fullDate => 'முழு தேதி';

  @override
  String get utrNumber => 'UTR எண்';

  @override
  String get failedToLoadTransactions => 'பரிவர்த்தனைகளை ஏற்ற முடியவில்லை';

  @override
  String get noTransactionsFound => 'பரிவர்த்தனைகள் கிடைக்கவில்லை';

  @override
  String get transactionHistoryDescription =>
      'உங்கள் முதல் பரிவர்த்தனையை செய்த பின் உங்கள் பரிவர்த்தனை வரலாறு இங்கே தோன்றும்';

  @override
  String get goBack => 'திரும்பிச் செல்';

  @override
  String get success => 'வெற்றி';

  @override
  String get failed => 'தோல்வி';

  @override
  String get credit => 'கிரெடிட்';

  @override
  String get debit => 'டெபிட்';

  @override
  String get profileDetails => 'சுயவிவர விவரங்கள்';

  @override
  String get address => 'முகவரி';

  @override
  String get notProvided => 'வழங்கப்படவில்லை';

  @override
  String get profileDetailsSectionHeader => 'சுயவிவர விவரங்கள்';

  @override
  String get editProfileInformation => 'சுயவிவரத் தகவலைத் திருத்து';

  @override
  String get nameCannotBeEmpty => 'பெயர் காலியாக இருக்க முடியாது';

  @override
  String get nameMinimumCharacters =>
      'பெயர் குறைந்தது 2 எழுத்துகள் இருக்க வேண்டும்';

  @override
  String get addressCannotBeEmpty => 'முகவரி காலியாக இருக்க முடியாது';

  @override
  String get pleaseEnterCompleteAddress =>
      'தயவுசெய்து முழுமையான முகவரியை உள்ளிடவும்';

  @override
  String get phoneAndReferralNotChangeable =>
      'குறிப்பு: தொலைபேசி எண் மற்றும் பரிந்துரை குறியீட்டை மாற்ற முடியாது. பெயர், மின்னஞ்சல் மற்றும் முகவரியை மட்டும் புதுப்பிக்கலாம்.';

  @override
  String get updatingProfile => 'சுயவிவரம் புதுப்பிக்கப்படுகிறது...';

  @override
  String get updateProfile => 'சுயவிவரத்தை புதுப்பிக்கவும்';

  @override
  String get profileUpdatedSuccessfully =>
      'சுயவிவரம் வெற்றிகரமாக புதுப்பிக்கப்பட்டது!';

  @override
  String get profileUpdateSuccessMessage =>
      'உங்கள் சுயவிவரத் தகவல் வெற்றிகரமாக புதுப்பிக்கப்பட்டது.';

  @override
  String get updateFailed => 'புதுப்பித்தல் தோல்வியடைந்தது';

  @override
  String get inviteEarnRewards => 'அழைத்து வெகுமதிகள் பெறுங்கள்';

  @override
  String get shareReferralDescription =>
      'உங்கள் பரிந்துரை குறியீட்டை நண்பர்கள் மற்றும் குடும்பத்தினருடன் பகிர்ந்து, அவர்கள் பசு பரிவாரில் சேரும்போது பிரத்யேக வெகுமதிகளைப் பெறுங்கள்';

  @override
  String get yourReferralCode => 'உங்கள் பரிந்துரை குறியீடு';

  @override
  String get shareWithFriends => 'நண்பர்களுடன் பகிருங்கள்';

  @override
  String get shareLink => 'இணைப்பைப் பகிருங்கள்';

  @override
  String get copyLink => 'இணைப்பை நகலெடுக்கவும்';

  @override
  String get moreOptions => 'மேலும் விருப்பங்கள்';

  @override
  String get referralBenefits => 'பரிந்துரை நன்மைகள்';

  @override
  String get earnRewards => 'வெகுமதிகள் பெறுங்கள்';

  @override
  String get earnRewardsDescription =>
      'உங்கள் நண்பர்கள் உங்கள் குறியீட்டைப் பயன்படுத்தி சேரும்போது பிரத்யேக வெகுமதிகளைப் பெறுங்கள்';

  @override
  String get helpFriends => 'நண்பர்களுக்கு உதவுங்கள்';

  @override
  String get helpFriendsDescription =>
      'உங்கள் நண்பர்களும் பதிவு செய்யும்போது சிறப்பு போனஸ் பெறுவார்கள்';

  @override
  String get unlimitedSharing => 'வரம்பற்ற பகிர்வு';

  @override
  String get unlimitedSharingDescription =>
      'உங்கள் குறியீட்டை எத்தனை முறை வேண்டுமானாலும் யாருடனும் பகிர்ந்து கொள்ளுங்கள்';

  @override
  String get trackProgress => 'முன்னேற்றத்தைக் கண்காணிக்கவும்';

  @override
  String get trackProgressDescription =>
      'உங்கள் சுயவிவரத்தில் உங்கள் பரிந்துரை வெற்றி மற்றும் வெகுமதிகளைக் கண்காணிக்கவும்';

  @override
  String get howItWorks => 'இது எவ்வாறு செயல்படுகிறது';

  @override
  String get shareYourCode => 'உங்கள் குறியீட்டைப் பகிருங்கள்';

  @override
  String get shareYourCodeDescription =>
      'உங்கள் பரிந்துரை குறியீடு அல்லது இணைப்பை நண்பர்கள் மற்றும் குடும்பத்தினருக்கு அனுப்புங்கள்';

  @override
  String get friendSignsUp => 'நண்பர் பதிவு செய்கிறார்';

  @override
  String get friendSignsUpDescription =>
      'அவர்கள் உங்கள் பரிந்துரை குறியீட்டைப் பயன்படுத்தி கணக்கை உருவாக்குகிறார்கள்';

  @override
  String get bothGetRewards => 'இருவரும் வெகுமதிகள் பெறுங்கள்';

  @override
  String get bothGetRewardsDescription =>
      'நீங்களும் உங்கள் நண்பரும் பிரத்யேக போனஸ்களைப் பெறுவீர்கள்';

  @override
  String get linkCopiedToClipboard =>
      'இணைப்பு கிளிப்போர்டுக்கு நகலெடுக்கப்பட்டது!';

  @override
  String get codeCopiedToClipboard =>
      'குறியீடு கிளிப்போர்டுக்கு நகலெடுக்கப்பட்டது!';

  @override
  String get referralHelp => 'பரிந்துரை உதவி';

  @override
  String get referralHelpContent =>
      '• உங்கள் தனிப்பட்ட பரிந்துரை குறியீட்டை நண்பர்களுடன் பகிருங்கள்\n• நீங்களும் உங்கள் நண்பரும் இருவரும் வெகுமதிகள் பெறுவீர்கள்\n• எத்தனை நண்பர்களை பரிந்துரைக்கலாம் என்பதற்கு வரம்பு இல்லை\n• உங்கள் சுயவிவரத்தில் உங்கள் பரிந்துரைகளைக் கண்காணிக்கவும்\n• வெகுமதிகள் தானாகவே வரவு வைக்கப்படும்';

  @override
  String shareMessage(String referralCode, String referralUrl) {
    return '🐄 பசு பரிவாரில் என்னுடன் சேருங்கள் - இந்தியாவின் நம்பகமான கால்நடை சந்தை! 🐄\n\nதரமான விலங்குகளைக் கண்டறியுங்கள், சரிபார்க்கப்பட்ட விற்பனையாளர்களுடன் இணைந்து, பிரீமியம் அம்சங்களுடன் உங்கள் கால்நடை வணிகத்தை வளர்க்கவும்.\n\n✨ எனது பரிந்துரை குறியீட்டைப் பயன்படுத்துங்கள்: $referralCode\n🎁 எங்கள் இருவருக்கும் பிரத்யேக வெகுமதிகளைப் பெறுங்கள்!\n\nஇப்போதே பதிவிறக்கவும்: $referralUrl\n\n#பசுபரிவார் #கால்நடை #விவசாயம் #விலங்குவணிகம்';
  }

  @override
  String get termsOfService => 'சேவை நியமங்கள்';

  @override
  String get privacyPolicy => 'தனியுரிமை கொள்கை';

  @override
  String get lastUpdated => 'கடைசியாக புதுப்பிக்கப்பட்டது: ஜூலை 27, 2025';

  @override
  String get acceptanceOfTerms => 'நியமங்களின் ஏற்றுக்கொள்ளல்';

  @override
  String get acceptanceOfTermsContent =>
      'பசு பரிவாரை அணுகி பயன்படுத்துவதன் மூலம், இந்த ஒப்பந்தத்தின் நியமங்கள் மற்றும் விதிகளுக்கு கட்டுப்பட்டு இருக்க ஒப்புக்கொள்கிறீர்கள்.';

  @override
  String get useLicense => 'பயன்பாட்டு உரிமம்';

  @override
  String get useLicenseContent =>
      'தனிப்பட்ட, வணிகமற்ற தற்காலிக பார்வைக்காக மட்டும் ஒரு சாதனத்திற்கு பசு பரிவாரின் ஒரு நகலை தற்காலிகமாக பதிவிறக்க அனுமதி வழங்கப்படுகிறது.';

  @override
  String get userResponsibilities => 'பயனர் பொறுப்புகள்';

  @override
  String get userResponsibilitiesContent =>
      '• பட்டியல்களை உருவாக்கும் போது துல்லியமான தகவல்களை வழங்கவும்\n• மற்ற பயனர்களை மரியாதைக்குரியவர்களாக கருதி தொழில்முறை நடத்தையை பராமரிக்கவும்\n• பொருந்தும் அனைத்து சட்டங்கள் மற்றும் விதிமுறைகளுக்கு இணங்கவும்\n• மோசடி நடவடிக்கைகளுக்கு இயங்குதளத்தை தவறாக பயன்படுத்த வேண்டாம்';

  @override
  String get platformServices => 'இயங்குதள சேவைகள்';

  @override
  String get platformServicesContent =>
      'பசு பரிவார் கால்நடை வர்த்தகத்திற்கு ஒரு இயங்குதளத்தை வழங்குகிறது, வாங்குபவர்களையும் விற்பனையாளர்களையும் இணைக்கிறது. நாங்கள் பரிவர்த்தனைகளை எளிதாக்குகிறோம் ஆனால் வாங்குதல்/விற்பனை செயல்முறையில் நேரடியாக ஈடுபடவில்லை.';

  @override
  String get accountSecurity => 'கணக்கு பாதுகாப்பு';

  @override
  String get accountSecurityContent =>
      'பயனர்கள் தங்கள் கணக்கு தகவல் மற்றும் கடவுச்சொல்லின் ரகசியத்தை பராமரிக்க பொறுப்பாவர்கள். எந்தவொரு அங்கீகரிக்கப்படாத பயன்பாட்டையும் உடனடியாக எங்களுக்கு தெரிவிக்கவும்.';

  @override
  String get paymentTerms => 'கொடுப்பனவு நியமங்கள்';

  @override
  String get paymentTermsContent =>
      'பிரீமியம் சேவைகளுக்கான அனைத்து கொடுப்பனவுகளும் பாதுகாப்பாக செயலாக்கப்படுகின்றன. சந்தா கட்டணங்கள் வேறுவிதமாக குறிப்பிடப்படாத வரை திரும்பப் பெற முடியாதவை.';

  @override
  String get contentGuidelines => 'உள்ளடக்க வழிகாட்டுதல்கள்';

  @override
  String get contentGuidelinesContent =>
      'பதிவேற்றப்படும் அனைத்து உள்ளடக்கமும் பொருத்தமானதாகவும், துல்லியமானதாகவும் இருக்க வேண்டும் மற்றும் எங்கள் சமுதாய வழிகாட்டுதல்களுக்கு இணங்க வேண்டும். பொருத்தமற்ற உள்ளடக்கத்தை அகற்ற எங்களுக்கு உரிமை உள்ளது.';

  @override
  String get limitationOfLiability => 'பொறுப்பின் வரம்பு';

  @override
  String get limitationOfLiabilityContent =>
      'சேவையின் உங்கள் பயன்பாட்டின் விளைவாக ஏற்படும் எந்தவொரு மறைமுக, தற்செயல், சிறப்பு, விளைவான அல்லது தண்டனையான சேதங்களுக்கு பசு பரிவார் பொறுப்பாகாது.';

  @override
  String get modifications => 'மாற்றங்கள்';

  @override
  String get modificationsContent =>
      'எந்த நேரத்திலும் இந்த நியமங்களை மாற்றியமைக்க எங்களுக்கு உரிமை உள்ளது. குறிப்பிடத்தக்க மாற்றங்கள் குறித்து பயனர்களுக்கு அறிவிக்கப்படும்.';

  @override
  String get contactInformationContent =>
      'இந்த சேவை நியமங்கள் குறித்த கேள்விகளுக்கு, தயவுசெய்து எங்களை support@pashuparivar.com இல் தொடர்பு கொள்ளுங்கள்';

  @override
  String get informationWeCollect => 'நாங்கள் சேகரிக்கும் தகவல்';

  @override
  String get informationWeCollectContent =>
      '• தனிப்பட்ட தகவல்: பெயர், தொலைபேசி எண், மின்னஞ்சல் முகவரி\n• சுயவிவர தகவல்: முகவரி, விருப்பத்தேர்வுகள், பயன்பாட்டு தரவு\n• சாதன தகவல்: IP முகவரி, உலாவி வகை, இயக்க முறைமை\n• பயன்பாட்டு தரவு: பயன்பாட்டு தொடர்புகள், பயன்படுத்தப்பட்ட அம்சங்கள், அமர்வு கால அளவு';

  @override
  String get howWeUseYourInformation =>
      'உங்கள் தகவலை நாங்கள் எப்படி பயன்படுத்துகிறோம்';

  @override
  String get howWeUseYourInformationContent =>
      'சேகரிக்கப்பட்ட தகவலை நாங்கள் பயன்படுத்துகிறோம்:\n• எங்கள் சேவைகளை வழங்க மற்றும் பராமரிக்க\n• பரிவர்த்தனைகளை செயலாக்க மற்றும் அறிவிப்புகளை அனுப்ப\n• பயனர் அனுபவம் மற்றும் பயன்பாட்டு செயல்பாட்டை மேம்படுத்த\n• புதுப்பிப்புகள் மற்றும் சலுகைகள் குறித்து உங்களுடன் தொடர்பு கொள்ள';

  @override
  String get informationSharing => 'தகவல் பகிர்வு';

  @override
  String get informationSharingContent =>
      'நாங்கள் உங்கள் தகவலை பகிரலாம்:\n• மற்ற பயனர்களுடன் (பட்டியல்களில் சுயவிவர தகவல்)\n• எங்கள் செயல்பாடுகளுக்கு உதவும் சேவை வழங்குநர்களுடன்\n• சட்டத்தின் மூலம் தேவைப்படும் போது அல்லது எங்கள் உரிமைகளை பாதுகாக்க\n• குறிப்பிட்ட நோக்கங்களுக்காக உங்கள் ஒப்புதலுடன்';

  @override
  String get dataSecurity => 'தரவு பாதுகாப்பு';

  @override
  String get dataSecurityContent =>
      'அங்கீகரிக்கப்படாத அணுகல், மாற்றம், வெளிப்படுத்தல் அல்லது அழிவுக்கு எதிராக உங்கள் தனிப்பட்ட தகவலை பாதுகாக்க நாங்கள் பொருத்தமான பாதுகாப்பு நடவடிக்கைகளை அமல்படுத்துகிறோம்.';

  @override
  String get dataRetention => 'தரவு வைத்திருத்தல்';

  @override
  String get dataRetentionContent =>
      'இந்த கொள்கையில் குறிப்பிடப்பட்ட நோக்கங்களுக்கு அவசியமான காலம் அல்லது சட்டத்தின் படி தேவைப்படும் காலம் வரை மட்டுமே உங்கள் தனிப்பட்ட தகவலை நாங்கள் வைத்திருக்கிறோம்.';

  @override
  String get yourRights => 'உங்கள் உரிமைகள்';

  @override
  String get yourRightsContent =>
      'உங்களுக்கு உரிமை உள்ளது:\n• உங்கள் தனிப்பட்ட தகவலை அணுக\n• தவறான தகவலை சரிசெய்ய\n• உங்கள் கணக்கு மற்றும் தரவை நீக்க\n• சந்தைப்படுத்தல் தொடர்புகளில் இருந்து விலக';

  @override
  String get cookiesAndTracking => 'குக்கீகள் மற்றும் கண்காணிப்பு';

  @override
  String get cookiesAndTrackingContent =>
      'உங்கள் அனுபவத்தை மேம்படுத்த, பயன்பாட்டு முறைகளை பகுப்பாய்வு செய்ய மற்றும் தனிப்பயனாக்கப்பட்ட உள்ளடக்கத்தை வழங்க நாங்கள் குக்கீகள் மற்றும் ஒத்த தொழில்நுட்பங்களை பயன்படுத்துகிறோம்.';

  @override
  String get thirdPartyServices => 'மூன்றாம் தரப்பு சேவைகள்';

  @override
  String get thirdPartyServicesContent =>
      'எங்கள் பயன்பாட்டில் மூன்றாம் தரப்பு சேவைகளுக்கான இணைப்புகள் இருக்கலாம். அவர்களின் தனியுரிமை நடைமுறைகளுக்கு நாங்கள் பொறுப்பல்ல.';

  @override
  String get childrensPrivacy => 'குழந்தைகளின் தனியுரிமை';

  @override
  String get childrensPrivacyContent =>
      'எங்கள் சேவை 13 வயதுக்குட்பட்ட குழந்தைகளுக்காக உத்தேசிக்கப்படவில்லை. 13 வயதுக்குட்பட்ட குழந்தைகளிடமிருந்து தனிப்பட்ட தகவல்களை நாங்கள் அறிந்தே சேகரிப்பதில்லை.';

  @override
  String get changesToThisPolicy => 'இந்த கொள்கையில் மாற்றங்கள்';

  @override
  String get changesToThisPolicyContent =>
      'நாங்கள் இந்த தனியுரிமை கொள்கையை அவ்வப்போது புதுப்பிக்கலாம். இந்த பக்கத்தில் புதிய கொள்கையை இடுகையிடுவதன் மூலம் எந்த மாற்றங்களையும் உங்களுக்கு அறிவிப்போம்.';

  @override
  String get privacyContactContent =>
      'இந்த தனியுரிமை கொள்கை குறித்து உங்களுக்கு கேள்விகள் இருந்தால், தயவுசெய்து எங்களை தொடர்பு கொள்ளுங்கள்:\nமின்னஞ்சல்: privacy@pashuparivar.com\nதொலைபேசி: +91-XXXXXXXXXX';
}
