// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Hindi (`hi`).
class AppLocalizationsHi extends AppLocalizations {
  AppLocalizationsHi([String locale = 'hi']) : super(locale);

  @override
  String get welcome => 'पशु परिवार में आपका स्वागत है';

  @override
  String get locationPermissionTitle => 'स्थान की अनुमति';

  @override
  String get locationPermissionMessage =>
      'ऐप को आपके स्थान तक पहुँच की आवश्यकता है।';

  @override
  String get permissionDenied => 'अनुमति अस्वीकृत';

  @override
  String get permissionRetryMessage =>
      'स्थान की अनुमति आवश्यक है। क्या आप फिर से प्रयास करना चाहेंगे?';

  @override
  String get yes => 'हाँ';

  @override
  String get no => 'नहीं';

  @override
  String get hi => 'नमस्ते';

  @override
  String get newAnimal => 'नया पशु';

  @override
  String get newBuyers => 'नए खरीदार';

  @override
  String get buyAnimal => 'पशु खरीदें';

  @override
  String get sellAnimal => 'पशु बेचें';

  @override
  String get otherServices => 'अन्य सेवाएं';

  @override
  String get knowMore => 'और जानें';

  @override
  String get clicklive => 'लाइव देखें';

  @override
  String get insurance => 'बीमा';

  @override
  String get health => 'स्वास्थ्य';

  @override
  String get liverace => 'लाइव रेस';

  @override
  String get feed => 'चारा';

  @override
  String get getLocation => 'स्थान प्राप्त करें';

  @override
  String get getLocationMessage => 'अपने पशु के लिए स्थान प्राप्त करें 📍';

  @override
  String get comingSoon => 'जल्द आ रहा है';

  @override
  String get firstUsers => 'पहले 10,000 उपयोगकर्ताओं को मिलेगा';

  @override
  String get referralBonusOnly => 'रेफरल बोनस – केवल';

  @override
  String slotsLeft(Object slot) {
    return 'स्लॉट बचे हैं!';
  }

  @override
  String get applyNow => 'अभी आवेदन करें';

  @override
  String get pashuLoan => 'पशु ऋण';

  @override
  String get pashuInsurance => 'पशु बीमा';

  @override
  String get investInFarming => 'खेती में निवेश करें';

  @override
  String get growWealth => 'प्रकृति के साथ अपनी संपत्ति बढ़ाएं';

  @override
  String get startInvesting => 'निवेश शुरू करें';

  @override
  String get editProfile => 'प्रोफ़ाइल संपादित करें';

  @override
  String get animalHistory => 'पशु सूची इतिहास';

  @override
  String get referralCode => 'रेफरल कोड';

  @override
  String get logout => 'लॉगआउट';

  @override
  String get yourListedPashu => 'आपके सूचीबद्ध पशु';

  @override
  String get termsPrivacy => 'नियम और गोपनीयता';

  @override
  String get contactUs => 'हमसे संपर्क करें';

  @override
  String get account => 'खाता';

  @override
  String get soldOutPashuHistory => 'बेचे गए पशु का इतिहास';

  @override
  String get walletBalance => 'वॉलेट बैलेंस';

  @override
  String get addAmountInWallet => 'बटुए में राशि जोड़ें';

  @override
  String get myTransaction => 'मेरा लेनदेन';

  @override
  String get addMoneyToWallet => 'अपने बटुए में पैसा जोड़ें';

  @override
  String get enterAmount => 'राशि दर्ज करें';

  @override
  String get enterAmountExample => 'उदाहरण: 500 दर्ज करें';

  @override
  String get add => 'जोड़ें';

  @override
  String get walletTip =>
      'टिप: आपका बटुआ संपर्क विवरण तुरंत देखने के लिए उपयोग किया जा सकता है।';

  @override
  String get getVerifiedPashu => 'अपने पशु को सत्यापित करें';

  @override
  String get withdrawBalance => 'बैलेंस निकालें';

  @override
  String get signIn => 'साइन इन';

  @override
  String get enterPhoneNumberToContinue =>
      'जारी रखने के लिए अपना फोन नंबर दर्ज करें';

  @override
  String get phoneNumber => 'फ़ोन नंबर';

  @override
  String get enterPhoneNumber => 'फोन नंबर दर्ज करें';

  @override
  String get sendOTP => 'ओटीपी भेजें';

  @override
  String get or => 'या';

  @override
  String get dontHaveAccount => 'खाता नहीं है? अभी रजिस्टर करें';

  @override
  String get phoneNumberRequired => 'फोन नंबर आवश्यक है';

  @override
  String get enterValidPhoneNumber =>
      'वैध 10 अंकों का भारतीय फोन नंबर दर्ज करें';

  @override
  String otpSentTo(Object phoneNumber) {
    return 'ओटीपी +91 $phoneNumber पर भेजा गया';
  }

  @override
  String get register => 'रजिस्टर';

  @override
  String get login => 'लॉगिन';

  @override
  String get registerNow => 'अभी रजिस्टर करें';

  @override
  String get enterYourName => 'अपना नाम दर्ज करें';

  @override
  String get enterReferralCode => 'रेफरल कोड दर्ज करें (वैकल्पिक)';

  @override
  String get getOTP => 'ओटीपी प्राप्त करें';

  @override
  String get alreadyHaveAccount => 'पहले से खाता है? साइन इन करें';

  @override
  String get optional => 'वैकल्पिक';

  @override
  String get nameIsRequired => 'नाम आवश्यक है';

  @override
  String get nameMinLength => 'नाम कम से कम 2 अक्षर का होना चाहिए';

  @override
  String get failedToSendOTP =>
      'ओटीपी भेजने में विफल। कृपया फिर से प्रयास करें।';

  @override
  String get enterOTP => 'ओटीपी दर्ज करें';

  @override
  String otpSentMessage(Object phoneNumber) {
    return 'हमने +91 $phoneNumber पर 6 अंकों का ओटीपी भेजा है';
  }

  @override
  String get enterComplete6DigitOTP => 'कृपया पूरा 6 अंकों का ओटीपी दर्ज करें';

  @override
  String get successfulLogin => 'सफल लॉगिन';

  @override
  String get didntReceiveOTP => 'ओटीपी नहीं मिला?';

  @override
  String resendIn(Object seconds) {
    return '$seconds सेकंड में पुनः भेजें';
  }

  @override
  String get resendOTP => 'ओटीपी पुनः भेजें';

  @override
  String get resending => 'पुनः भेजा जा रहा है...';

  @override
  String otpResentTo(Object phoneNumber) {
    return 'ओटीपी +91 $phoneNumber पर पुनः भेजा गया';
  }

  @override
  String get failedToResendOTP =>
      'ओटीपी पुनः भेजने में विफल। कृपया फिर से प्रयास करें।';

  @override
  String get homeScreen => 'होम';

  @override
  String get welcomeToHomeScreen => 'होम स्क्रीन में आपका स्वागत है!';

  @override
  String get newBadge => 'नया';

  @override
  String get logoutConfirmation =>
      'क्या आप वाकई अपने खाते से लॉगआउट करना चाहते हैं?';

  @override
  String get cancel => 'रद्द करें';

  @override
  String get failedToLoadProfile => 'प्रोफाइल लोड करने में विफल';

  @override
  String get uploadPashuImageOne => 'अपना पशु चित्र एक अपलोड करें';

  @override
  String get selectPictureOne => 'चित्र एक चुनें';

  @override
  String get uploadPashuImageTwo => 'अपना पशु चित्र दो अपलोड करें';

  @override
  String get selectPictureTwo => 'चित्र दो चुनें';

  @override
  String get paymentCompletedSuccessfully => 'भुगतान सफलतापूर्वक पूरा हुआ!';

  @override
  String get paymentVerificationFailed =>
      'भुगतान सत्यापन विफल। कृपया पुनः प्रयास करें।';

  @override
  String get errorVerifyingPayment => 'भुगतान सत्यापित करने में त्रुटि';

  @override
  String get insuranceApplication => 'बीमा आवेदन';

  @override
  String get responseReceived => 'प्रतिक्रिया प्राप्त हुई!';

  @override
  String get insuranceThankYouMessage =>
      'पशु बीमा आवेदन जमा करने के लिए धन्यवाद। हमारी टीम जल्द ही आगे की जानकारी के साथ आपसे संपर्क करेगी।';

  @override
  String get selectLanguage => 'भाषा चुनें';

  @override
  String get ok => 'ठीक है';

  @override
  String get appTitle => 'पशु परिवार';

  @override
  String get languageShort => 'हि/E/ತ';

  @override
  String get wishlist => 'विश लिस्ट';

  @override
  String get loanFormTitle => 'पशु ऋण फॉर्म';

  @override
  String get loanApplicationHeader => 'पशु ऋण आवेदन';

  @override
  String get loanApplicationSubheader =>
      'अपने पशुपालन की जरूरतों के लिए वित्तीय सहायता प्राप्त करें';

  @override
  String get loanApplicationDetails => 'ऋण आवेदन विवरण';

  @override
  String get applicantInformation => 'आवेदक जानकारी';

  @override
  String get applicantName => 'आवेदक का नाम';

  @override
  String get applicantNameRequired => 'आवेदक का नाम आवश्यक है';

  @override
  String get applicantAddress => 'आवेदक का पता';

  @override
  String get applicantAddressRequired => 'आवेदक का पता आवश्यक है';

  @override
  String get contactNumber => 'संपर्क नंबर';

  @override
  String get contactNumberRequired => 'संपर्क नंबर आवश्यक है';

  @override
  String get contactNumberInvalid => 'कृपया मान्य संपर्क नंबर दर्ज करें';

  @override
  String get emailAddress => 'ईमेल पता';

  @override
  String get emailAddressRequired => 'ईमेल पता आवश्यक है';

  @override
  String get emailAddressInvalid => 'कृपया मान्य ईमेल पता दर्ज करें';

  @override
  String get loanInformation => 'ऋण जानकारी';

  @override
  String get loanAmount => 'ऋण राशि (₹)';

  @override
  String get loanAmountRequired => 'ऋण राशि आवश्यक है';

  @override
  String get loanAmountInvalid => 'कृपया मान्य ऋण राशि दर्ज करें';

  @override
  String get repaymentPeriod => 'भुगतान अवधि';

  @override
  String get repaymentPeriodRequired => 'भुगतान अवधि आवश्यक है';

  @override
  String get incomeSource => 'आय का स्रोत';

  @override
  String get incomeSourceRequired => 'आय का स्रोत आवश्यक है';

  @override
  String get purposeOfLoan => 'ऋण का उद्देश्य';

  @override
  String get purposeOfLoanRequired => 'ऋण का उद्देश्य आवश्यक है';

  @override
  String get additionalInformation => 'अतिरिक्त जानकारी';

  @override
  String get additionalRemarks => 'अतिरिक्त टिप्पणी';

  @override
  String get additionalRemarksRequired => 'अतिरिक्त टिप्पणी आवश्यक है';

  @override
  String get submittingForm => 'फॉर्म सबमिट हो रहा है...';

  @override
  String get submitForm => 'फॉर्म सबमिट करें';

  @override
  String get loanTermsNote =>
      'इस फॉर्म को सबमिट करके, आप हमारे ऋण नियमों और शर्तों से सहमत होते हैं। हमारी टीम आपके आवेदन की समीक्षा करेगी और 3-5 कार्य दिवसों में ऋण स्वीकृति की स्थिति के साथ आपसे संपर्क करेगी।';

  @override
  String get allFieldsRequired => 'सभी फ़ील्ड आवश्यक हैं';

  @override
  String get animalInformation => 'पशु जानकारी';

  @override
  String get animalAgeInvalid => 'कृपया मान्य पशु आयु दर्ज करें';

  @override
  String get animalWeightInvalid => 'कृपया मान्य पशु वजन दर्ज करें';

  @override
  String get allowLocationAccess => 'स्थान एक्सेस की अनुमति दें';

  @override
  String get locationDescription =>
      'हम आपके क्षेत्र के पास के पशु, कार्यक्रम और व्यक्तिगत सामग्री दिखाने के लिए आपके स्थान की आवश्यकता है।';

  @override
  String get locationPrivacyNote =>
      'आपका स्थान डेटा सुरक्षित है और केवल आपके अनुभव को बेहतर बनाने के लिए उपयोग किया जाता है।';

  @override
  String get liveRaces => 'लाइव रेस';

  @override
  String get viewLive => 'लाइव देखें';

  @override
  String get animalInsurance => 'पशु बीमा';

  @override
  String get insuranceFormTitle => 'पशु बीमा फॉर्म';

  @override
  String get insuranceApplicationHeader => 'पशु बीमा आवेदन';

  @override
  String get insuranceApplicationSubheader =>
      'अपने पशु बीमा की जरूरतों के लिए वित्तीय सहायता प्राप्त करें';

  @override
  String get insuranceApplicationDetails => 'बीमा आवेदन विवरण';

  @override
  String get ownerInformation => 'मालिक की जानकारी';

  @override
  String get ownerName => 'मालिक का नाम';

  @override
  String get ownerNameRequired => 'मालिक का नाम आवश्यक है';

  @override
  String get ownerAddress => 'मालिक का पता';

  @override
  String get ownerAddressRequired => 'मालिक का पता आवश्यक है';

  @override
  String get animalType => 'पशु प्रकार';

  @override
  String get animalTypeRequired => 'पशु प्रकार आवश्यक है';

  @override
  String get animalBreed => 'पशु नस्ल';

  @override
  String get animalBreedRequired => 'पशु नस्ल आवश्यक है';

  @override
  String get animalAge => 'पशु आयु';

  @override
  String get animalAgeRequired => 'पशु आयु आवश्यक है';

  @override
  String get animalColor => 'पशु रंग';

  @override
  String get animalColorRequired => 'पशु रंग आवश्यक है';

  @override
  String get animalWeight => 'पशु वजन';

  @override
  String get animalWeightRequired => 'पशु वजन आवश्यक है';

  @override
  String get healthStatus => 'स्वास्थ्य स्थिति';

  @override
  String get healthStatusRequired => 'स्वास्थ्य स्थिति आवश्यक है';

  @override
  String get insuranceTermsNote =>
      'इस फॉर्म को सबमिट करके, आप हमारे बीमा नियमों और शर्तों से सहमत होते हैं। हमारी टीम आपके आवेदन की समीक्षा करेगी और 3-5 कार्य दिवसों में बीमा स्वीकृति की स्थिति के साथ आपसे संपर्क करेगी।';

  @override
  String get liveRaceTitle => 'लाइव रेस';

  @override
  String get liveRaceHeader => 'लाइव रेस';

  @override
  String get chooseRaceCategory => 'अपनी रेस श्रेणी चुनें';

  @override
  String get raceExperienceSubheader =>
      'पारंपरिक पशु दौड़ का रोमांच अनुभव करें';

  @override
  String get raceCategoryFallback => 'रेस श्रेणी';

  @override
  String get raceCategoryDetailFallback =>
      'रोमांचक रेस में शामिल हों और पारंपरिक पशु दौड़ का रोमांच अनुभव करें';

  @override
  String get liveNow => 'अभी लाइव';

  @override
  String get tapToJoin => 'शामिल होने के लिए टैप करें';

  @override
  String get liveBadge => 'लाइव';

  @override
  String get failedToLoadCategories => 'श्रेणियाँ लोड करने में विफल';

  @override
  String get somethingWentWrong => 'कुछ गलत हुआ';

  @override
  String get retry => 'पुनः प्रयास करें';

  @override
  String get noLiveRacesAvailable => 'कोई लाइव रेस उपलब्ध नहीं';

  @override
  String get checkBackLater =>
      'रोमांचक लाइव रेसिंग इवेंट्स के लिए बाद में देखें';

  @override
  String get raceCategory => 'दौड़ श्रेणी';

  @override
  String get traditionalRacingExperience => 'पारंपरिक रेसिंग अनुभव';

  @override
  String get raceInformation => 'दौड़ की जानकारी';

  @override
  String get category => 'श्रेणी';

  @override
  String get status => 'स्थिति';

  @override
  String get participants => 'प्रतिभागी';

  @override
  String get multipleEntries => 'कई प्रविष्टियां';

  @override
  String get duration => 'अवधि';

  @override
  String get ongoing => 'चालू';

  @override
  String get prize => 'पुरस्कार';

  @override
  String get trophiesAndRecognition => 'ट्रॉफी और मान्यता';

  @override
  String get raceIsLiveNow => 'दौड़ अभी लाइव है!';

  @override
  String get watchExcitingCompetition => 'रोमांचक प्रतियोगिता को देखें';

  @override
  String get aboutThisRace => 'इस दौड़ के बारे में';

  @override
  String get defaultRaceDescription =>
      'इस रोमांचक लाइव इवेंट में पारंपरिक पशु दौड़ का रोमांच अनुभव करें। कुशल प्रतिभागियों को इस समय-सम्मानित परंपरा में प्रतिस्पर्धा करते देखें जो मनुष्यों और जानवरों के बीच के बंधन को दर्शाती है।';

  @override
  String get liveStream => 'लाइव स्ट्रीम';

  @override
  String get liveStreamComingSoon => 'लाइव स्ट्रीम जल्द आ रहा है';

  @override
  String get youtubeLinksAvailable =>
      'स्ट्रीमिंग शुरू होने पर YouTube लिंक उपलब्ध होंगे';

  @override
  String get getNotifiedWhenStreaming =>
      'इस दौड़ श्रेणी के लिए लाइव स्ट्रीमिंग शुरू होने पर सूचना पाएं';

  @override
  String get liveRace => 'लाइव दौड़';

  @override
  String get na => 'उपलब्ध नहीं';

  @override
  String get regionalChampionship => 'क्षेत्रीय चैंपियनशिप';

  @override
  String get districtFinals => 'जिला फाइनल';

  @override
  String get stateCompetition => 'राज्य प्रतियोगिता';

  @override
  String get tomorrowTenAM => 'कल सुबह 10:00 बजे';

  @override
  String get nextWeek => 'अगले सप्ताह';

  @override
  String get sellPashu => 'पशु बेचें';

  @override
  String get youCanProceedWithListing => 'आप लिस्टिंग के साथ आगे बढ़ सकते हैं';

  @override
  String get minimumRequiredToList =>
      'अपने पशु को सूचीबद्ध करने के लिए न्यूनतम ₹15 आवश्यक';

  @override
  String get animalTypes => 'पशु प्रकार';

  @override
  String get selectAnimalType => 'पशु प्रकार चुनें';

  @override
  String get animalCategory => 'पशु श्रेणी';

  @override
  String get pleaseSelectAnimalTypeFirst => 'कृपया पहले पशु प्रकार चुनें';

  @override
  String get selectAnimalCategory => 'पशु श्रेणी चुनें';

  @override
  String get nameOfTheAnimal => 'पशु का नाम';

  @override
  String get enterAnimalAge => 'पशु की आयु दर्ज करें';

  @override
  String get selectGenderOfAnimal => 'पशु का लिंग चुनें';

  @override
  String get price => 'मूल्य';

  @override
  String get negotiable => 'बातचीत योग्य';

  @override
  String get isPriceNegotiable => 'क्या मूल्य बातचीत योग्य है?';

  @override
  String get yourPhoneNumber => 'आपका फोन नंबर';

  @override
  String get enterYourPhoneNumber => 'अपना फोन नंबर दर्ज करें';

  @override
  String get animalDescription => 'पशु विवरण';

  @override
  String get enterAnimalDescription => 'पशु विवरण दर्ज करें';

  @override
  String get getAddressForPashu => 'पशु के लिए पता प्राप्त करें';

  @override
  String get submitAndPay => 'जमा करें और ₹15 का भुगतान करें';

  @override
  String get insufficientBalance => 'अपर्याप्त शेष राशि। कृपया फंड जोड़ें।';

  @override
  String get submitting => 'जमा कर रहे हैं...';

  @override
  String get locationServicesDisabled => 'स्थान सेवाएं अक्षम हैं';

  @override
  String get locationPermissionPermanentlyDenied =>
      'स्थान अनुमति स्थायी रूप से अस्वीकृत';

  @override
  String get locationPermissionDenied => 'स्थान अनुमति अस्वीकृत';

  @override
  String get unableToDetermineAddress => 'पता निर्धारित करने में असमर्थ';

  @override
  String get error => 'त्रुटि';

  @override
  String get missingRequiredFields => 'आवश्यक फ़ील्ड गुम';

  @override
  String get pleaseEnterValidPhoneNumber => 'कृपया एक वैध फोन नंबर दर्ज करें';

  @override
  String get pleaseEnterValidAge => 'कृपया एक वैध आयु दर्ज करें';

  @override
  String get pleaseEnterValidPrice => 'कृपया एक वैध मूल्य दर्ज करें';

  @override
  String get pashuListedSuccessfully => 'पशु सफलतापूर्वक सूचीबद्ध!';

  @override
  String get errorOccurred => 'एक त्रुटि हुई';

  @override
  String get selectCategory => 'श्रेणी चुनें';

  @override
  String get selectGender => 'लिंग चुनें';

  @override
  String get male => 'नर';

  @override
  String get female => 'मादा';

  @override
  String get user => 'उपयोगकर्ता';

  @override
  String get other => 'अन्य';

  @override
  String get unknown => 'अज्ञात';

  @override
  String get traditionalSportsAnimal => 'पारंपरिक खेल पशु';

  @override
  String get livestockAnimal => 'पशुधन पशु';

  @override
  String get petAnimal => 'पालतू पशु';

  @override
  String get farmHouseAnimal => 'फार्म हाउस पशु';

  @override
  String get bull => 'बैल';

  @override
  String get camel => 'ऊंट';

  @override
  String get bird => 'पक्षी';

  @override
  String get pigeon => 'कबूतर';

  @override
  String get cock => 'मुर्गा';

  @override
  String get dog => 'कुत्ता';

  @override
  String get goat => 'बकरी';

  @override
  String get horse => 'घोड़ा';

  @override
  String get buffalo => 'भैंस';

  @override
  String get sheep => 'भेड़';

  @override
  String get pigs => 'सूअर';

  @override
  String get cat => 'बिल्ली';

  @override
  String get fishes => 'मछली';

  @override
  String get smallMammals => 'छोटे स्तनधारी';

  @override
  String get searchAnimalsBreeds => 'जानवर, नस्लें खोजें...';

  @override
  String get unknownAnimal => 'अज्ञात जानवर';

  @override
  String get breed => 'नस्ल';

  @override
  String get owner => 'मालिक';

  @override
  String get callMe => 'मुझे कॉल करें';

  @override
  String get buyNow => 'अभी खरीदें';

  @override
  String get addedToWishlist => 'विशलिस्ट में जोड़ा गया';

  @override
  String get animal => 'जानवर';

  @override
  String get failedToAddToWishlist => 'विशलिस्ट में जोड़ने में विफल';

  @override
  String get noAnimalsFound => 'कोई जानवर नहीं मिला';

  @override
  String get trySelectingDifferentCategory =>
      'अलग श्रेणी का चयन करने का प्रयास करें';

  @override
  String get checkBackLaterForNewListings =>
      'नई लिस्टिंग के लिए बाद में जांचें';

  @override
  String get purchaseRequestSent => 'खरीदारी का अनुरोध भेजा गया';

  @override
  String get all => 'सभी';

  @override
  String get cow => 'गाय';

  @override
  String get cats => 'बिल्ली';

  @override
  String get animalDetails => 'पशु विवरण';

  @override
  String get photos => 'फोटो';

  @override
  String get type => 'प्रकार';

  @override
  String get age => 'उम्र';

  @override
  String get gender => 'लिंग';

  @override
  String get years => 'साल';

  @override
  String get pricingInformation => 'मूल्य निर्धारण जानकारी';

  @override
  String get fixedPrice => 'निश्चित मूल्य';

  @override
  String get ownerAndLocation => 'मालिक और स्थान';

  @override
  String get location => 'स्थान';

  @override
  String get distance => 'दूरी';

  @override
  String get notSpecified => 'निर्दिष्ट नहीं';

  @override
  String get meters => 'मीटर';

  @override
  String get km => 'किमी';

  @override
  String get description => 'विवरण';

  @override
  String get contactSeller => 'विक्रेता से संपर्क करें';

  @override
  String get unlockContactDetails =>
      'विक्रेता से जुड़ने के लिए ₹2 में संपर्क विवरण अनलॉक करें';

  @override
  String get unlocking => 'अनलॉक कर रहे हैं...';

  @override
  String get unlockContact => 'संपर्क अनलॉक करें (₹2)';

  @override
  String get contactOptions => 'संपर्क विकल्प';

  @override
  String get call => 'कॉल';

  @override
  String get whatsApp => 'व्हाट्सएप';

  @override
  String get contact => 'संपर्क';

  @override
  String get notAvailable => 'उपलब्ध नहीं है';

  @override
  String get userNotLoggedIn => 'उपयोगकर्ता लॉग इन नहीं है';

  @override
  String get userDataNotFound => 'उपयोगकर्ता डेटा नहीं मिला';

  @override
  String get contactAlreadyUnlocked => 'यह संपर्क पहले से ही अनलॉक है।';

  @override
  String get contactUnlockedSuccessfully => 'संपर्क सफलतापूर्वक अनलॉक हुआ!';

  @override
  String get couldNotLaunchPhoneApp => 'फोन ऐप लॉन्च नहीं कर सका';

  @override
  String get phoneNumberNotAvailable => 'फोन नंबर उपलब्ध नहीं';

  @override
  String get couldNotOpenWhatsApp => 'व्हाट्सऐप नहीं खोल सका';

  @override
  String whatsAppMessageTemplate(Object animalName) {
    return 'नमस्ते, मुझे पशु परिवार पर सूचीबद्ध आपके $animalName में रुचि है।';
  }

  @override
  String get locationNotAvailable => 'स्थान उपलब्ध नहीं';

  @override
  String get remove => 'हटाएं';

  @override
  String get removedFromWishlist => 'विश लिस्ट से हटा दिया गया';

  @override
  String get failedToRemove => 'हटाने में विफल';

  @override
  String get animalDetailsComingSoon => 'पशु विवरण जल्द आ रहा है';

  @override
  String get fullAnimalDetailsModal =>
      'पूर्ण पशु विवरण मॉडल यहाँ लागू किया जाएगा';

  @override
  String get noWishlistAnimalsFound => 'कोई विश लिस्ट जानवर नहीं मिले';

  @override
  String get tryAddingAnimalsToWishlist =>
      'अपनी विश लिस्ट में कुछ जानवर जोड़ने का प्रयास करें!';

  @override
  String get investmentProject => 'निवेश परियोजना';

  @override
  String get upcomingProjects => 'आगामी परियोजनाएं';

  @override
  String get liveProjects => 'लाइव परियोजनाएं';

  @override
  String get completedProjects => 'पूर्ण परियोजनाएं';

  @override
  String get mvpForAquacultureInvestment => 'जलीय कृषि निवेश के लिए एमवीपी';

  @override
  String get longTerm => 'दीर्घकालिक';

  @override
  String get amount => 'राशि';

  @override
  String get startDate => 'प्रारंभ तिथि';

  @override
  String get sixToEightMonths => '6 से 8 महीने';

  @override
  String get lotsBooked => 'लॉट बुक किए गए';

  @override
  String get noProjectsAvailable => 'कोई परियोजना उपलब्ध नहीं।';

  @override
  String get firstAugust2025 => '1 अगस्त 2025';

  @override
  String get addAmountAndGetPlans => 'राशि जोड़ें और योजनाएं प्राप्त करें';

  @override
  String get getVerifiedYourPashu => 'अपने पशु को सत्यापित कराएं';

  @override
  String get termsAndPrivacy => 'नियम और गोपनीयता';

  @override
  String get newA => 'नया';

  @override
  String get areYouSureLogout =>
      'क्या आप वाकई अपने खाते से लॉगआउट करना चाहते हैं?';

  @override
  String get noProfileFound => 'कोई प्रोफाइल नहीं मिला';

  @override
  String get profileInformationNotAvailable =>
      'प्रोफाइल जानकारी उपलब्ध नहीं है';

  @override
  String get subscriptionPlans => 'सब्सक्रिप्शन प्लान';

  @override
  String get chooseYourPlan => 'अपना प्लान चुनें';

  @override
  String get unlockPremiumFeatures =>
      'प्रीमियम सुविधाओं को अनलॉक करें और हमारे सब्सक्रिप्शन प्लान के साथ अपने पशुधन व्यवसाय को बढ़ाएं';

  @override
  String get diamondPlan => 'डायमंड प्लान';

  @override
  String get goldPlan => 'गोल्ड प्लान';

  @override
  String get silverPlan => 'सिल्वर प्लान';

  @override
  String get year => 'साल';

  @override
  String get months3 => '3 महीने';

  @override
  String get month => 'महीना';

  @override
  String get choosePlan => 'प्लान चुनें';

  @override
  String get unlimitedPashuProfileContact => 'असीमित पशु प्रोफाइल संपर्क';

  @override
  String get unlimitedFreePashuListings => 'असीमित मुफ्त पशु लिस्टिंग';

  @override
  String get priorityCustomerSupport => 'प्राथमिकता ग्राहक सहायता';

  @override
  String get advancedAnalytics => 'उन्नत विश्लेषण';

  @override
  String get premiumBadge => 'प्रीमियम बैज';

  @override
  String get freePashuListings10 => '10 मुफ्त पशु लिस्टिंग';

  @override
  String get standardCustomerSupport => 'मानक ग्राहक सहायता';

  @override
  String get basicAnalytics => 'बुनियादी विश्लेषण';

  @override
  String get freePashuListings2 => '2 मुफ्त पशु लिस्टिंग';

  @override
  String get emailSupport => 'ईमेल सहायता';

  @override
  String get addMoneyToYourWallet => 'अपने वॉलेट में पैसे जोड़ें';

  @override
  String get addFundsToWallet =>
      'अपने वॉलेट में फंड जोड़ें और सब्सक्रिप्शन के लिए आसानी से भुगतान करें। आपका वॉलेट हमारी सभी सेवाओं में उपयोग किया जा सकता है।';

  @override
  String get enterAmountEg500 => 'राशि दर्ज करें (जैसे 500)';

  @override
  String addAmount(String amount) {
    return '₹$amount जोड़ें';
  }

  @override
  String get tipWalletContact =>
      'सुझाव: आपका वॉलेट तुरंत संपर्क विवरण देखने के लिए इस्तेमाल किया जा सकता है।';

  @override
  String subscribeToPlan(String planName) {
    return 'Subscribe to $planName';
  }

  @override
  String chargedForSubscription(String price, String period) {
    return 'इस $period सब्सक्रिप्शन के लिए आपसे ₹$price चार्ज किया जाएगा।';
  }

  @override
  String get confirmSubscription => 'सब्सक्रिप्शन की पुष्टि करें';

  @override
  String get subscriptionSuccessful => 'सब्सक्रिप्शन सफल!';

  @override
  String subscriptionSuccessMessage(String planName) {
    return 'आपने सफलतापूर्वक $planName की सदस्यता ली है। सभी प्रीमियम सुविधाओं का आनंद लें!';
  }

  @override
  String get continueA => 'जारी रखें';

  @override
  String get subscriptionHelp => 'सब्सक्रिप्शन सहायता';

  @override
  String get helpContent =>
      '• डायमंड प्लान: ₹365/साल\n• गोल्ड प्लान: ₹140/3 महीने\n• सिल्वर प्लान: ₹49/महीना\n• अपनी प्रोफाइल से कभी भी रद्द करें\n• सभी सुविधाएं तुरंत अनलॉक हो जाती हैं\n• 24/7 ग्राहक सहायता शामिल';

  @override
  String get gotIt => 'समझ गया';

  @override
  String get pleaseEnterValidAmount => 'कृपया एक वैध राशि दर्ज करें';

  @override
  String get couldNotInitiatePayment => 'भुगतान शुरू नहीं कर सका';

  @override
  String get somethingWentWrongPayment => 'भुगतान में कुछ गलत हुआ।';

  @override
  String get paymentCancelled =>
      'भुगतान रद्द कर दिया गया या समय पर पूरा नहीं हुआ।';

  @override
  String get paymentFailed => 'भुगतान विफल';

  @override
  String get externalWalletSelected => 'बाहरी वॉलेट चुना गया';

  @override
  String get getInTouch => 'संपर्क में रहें';

  @override
  String get contactUsDescription =>
      'हम यहाँ मदद के लिए हैं! किसी भी समय हमसे संपर्क करें और हम जल्द से जल्द आपसे संपर्क करेंगे।';

  @override
  String get contactInformation => 'संपर्क जानकारी';

  @override
  String get officeAddress => 'कार्यालय का पता';

  @override
  String get pashuParivarHeadquarters =>
      'पशु परिवार मुख्यालय\nभोपाल, मध्य प्रदेश\nभारत';

  @override
  String get sendUsAMessage => 'हमें संदेश भेजें';

  @override
  String get fullName => 'पूरा नाम';

  @override
  String get enterYourFullName => 'अपना पूरा नाम दर्ज करें';

  @override
  String get enterYourEmailAddress => 'अपना ईमेल पता दर्ज करें';

  @override
  String get message => 'संदेश';

  @override
  String get tellUsHowWeCanHelp => 'बताएं कि हम आपकी कैसे मदद कर सकते हैं...';

  @override
  String get sendingMessage => 'संदेश भेज रहे हैं...';

  @override
  String get sendMessage => 'संदेश भेजें';

  @override
  String get responseTimeNote =>
      'हम आमतौर पर व्यावसायिक दिनों में 24 घंटों के भीतर जवाब देते हैं।';

  @override
  String get followUs => 'हमें फॉलो करें';

  @override
  String get stayUpdatedWithNews =>
      'हमारी नवीनतम समाचार और अपडेट के साथ अपडेट रहें';

  @override
  String get facebook => 'फेसबुक';

  @override
  String get instagram => 'इंस्टाग्राम';

  @override
  String get twitter => 'ट्विटर';

  @override
  String get youtube => 'यूट्यूब';

  @override
  String get copiedToClipboard => 'क्लिपबोर्ड पर कॉपी किया गया!';

  @override
  String get messageSentSuccessfully => 'संदेश सफलतापूर्वक भेजा गया!';

  @override
  String get thankYouForContacting =>
      'हमसे संपर्क करने के लिए धन्यवाद। हम 24 घंटों के भीतर आपसे संपर्क करेंगे।';

  @override
  String get nameMustBeAtLeast2Characters =>
      'नाम कम से कम 2 अक्षर का होना चाहिए';

  @override
  String get emailIsRequired => 'ईमेल आवश्यक है';

  @override
  String get pleaseEnterValidEmail => 'कृपया मान्य ईमेल पता दर्ज करें';

  @override
  String get messageIsRequired => 'संदेश आवश्यक है';

  @override
  String get messageMustBeAtLeast10Characters =>
      'संदेश कम से कम 10 अक्षर का होना चाहिए';

  @override
  String get invest => 'निवेश करें कृषि-पशुपालन में';

  @override
  String get total => 'कुल';

  @override
  String get active => 'सक्रिय';

  @override
  String get pending => 'लंबित';

  @override
  String get edit => 'संपादित करें';

  @override
  String get delete => 'हटाएं';

  @override
  String get pendingStatus => 'लंबित';

  @override
  String get failedToLoadListings => 'लिस्टिंग लोड करने में विफल';

  @override
  String get noListedAnimals => 'कोई सूचीबद्ध जानवर नहीं';

  @override
  String get noListedAnimalsDescription =>
      'आपने अभी तक कोई जानवर सूचीबद्ध नहीं किया है। अपनी पहली लिस्टिंग जोड़कर शुरुआत करें!';

  @override
  String get addNewListing => 'नई लिस्टिंग जोड़ें';

  @override
  String get deleteListing => 'लिस्टिंग हटाएं';

  @override
  String deleteConfirmation(String animalName) {
    return 'क्या आप वाकई \"$animalName\" को हटाना चाहते हैं? यह क्रिया पूर्ववत नहीं की जा सकती।';
  }

  @override
  String deleteSuccessMessage(String animalName) {
    return '$animalName सफलतापूर्वक हटा दिया गया';
  }

  @override
  String get withdrawFromWallet => 'वॉलेट से निकालें';

  @override
  String get availableBalance => 'उपलब्ध शेष राशि';

  @override
  String get withdrawalEligible => 'निकासी योग्य';

  @override
  String get withdrawalRequirements => 'निकासी आवश्यकताएं';

  @override
  String youHaveSpentAndCanWithdraw(String counter) {
    return 'आपने ₹$counter खर्च किया है और धन निकाल सकते हैं';
  }

  @override
  String spendMoreToEnableWithdrawal(String amount, String counter) {
    return 'निकासी सक्षम करने के लिए ₹$amount और खर्च करें (वर्तमान: ₹$counter)';
  }

  @override
  String get withdrawalDetails => 'निकासी विवरण';

  @override
  String get enterAmountEg => 'राशि दर्ज करें जैसे 500';

  @override
  String get enterUpiIdEg => 'UPI ID दर्ज करें (जैसे example@upi)';

  @override
  String get enterUpiIdEgPlaceholder => 'UPI ID दर्ज करें जैसे example@upi';

  @override
  String get processing => 'प्रसंस्करण...';

  @override
  String withdrawAmount(String amount) {
    return '₹$amount निकालें';
  }

  @override
  String get withdrawalRequirementsLabel => 'निकासी आवश्यकताएं:';

  @override
  String get minimumSpendingRequired => '• न्यूनतम ₹50 का खर्च आवश्यक';

  @override
  String get walletBalanceRequired => '• वॉलेट बैलेंस ≥ ₹100 होना चाहिए';

  @override
  String currentSpending(String counter, String status) {
    return '• वर्तमान खर्च: ₹$counter ($status)';
  }

  @override
  String walletBalanceStatus(String balance, String status) {
    return '• वॉलेट बैलेंस: ₹$balance ($status)';
  }

  @override
  String get verified => '✓';

  @override
  String needMoreAmount(String amount) {
    return '₹$amount और चाहिए';
  }

  @override
  String get tipWithdrawProcessingTime =>
      'सुझाव: निकासी 24-48 घंटों में आपके UPI खाते में प्रोसेस हो जाती है।';

  @override
  String get withdrawalRequestSubmitted => 'निकासी अनुरोध जमा किया गया!';

  @override
  String withdrawalRequestSuccessMessage(String amount) {
    return '₹$amount की आपकी निकासी का अनुरोध सफलतापूर्वक जमा किया गया है। आपको 24-48 घंटों में अपने UPI खाते में राशि मिल जाएगी।';
  }

  @override
  String get failedToLoadData => 'डेटा लोड करने में विफल';

  @override
  String get amountCannotBeEmpty => 'राशि खाली नहीं हो सकती';

  @override
  String amountCannotExceedBalance(String balance) {
    return 'राशि वॉलेट बैलेंस से अधिक नहीं हो सकती (₹$balance)';
  }

  @override
  String get minimumWalletBalanceRequired =>
      'न्यूनतम ₹100 का वॉलेट बैलेंस आवश्यक';

  @override
  String get upiIdCannotBeEmpty => 'UPI ID खाली नहीं हो सकती';

  @override
  String get pleaseEnterValidUpiId => 'कृपया एक वैध UPI ID दर्ज करें';

  @override
  String get transactionHistory => 'लेनदेन इतिहास';

  @override
  String get noTransactions => 'कोई लेनदेन नहीं';

  @override
  String get transactionSummary => 'लेनदेन सारांश';

  @override
  String get totalCredit => 'कुल क्रेडिट';

  @override
  String get totalDebit => 'कुल डेबिट';

  @override
  String get successful => 'सफल';

  @override
  String get today => 'आज';

  @override
  String get yesterday => 'कल';

  @override
  String daysAgo(String days) {
    return '$days दिन पहले';
  }

  @override
  String get paymentId => 'भुगतान ID';

  @override
  String get fullDate => 'पूरी तारीख';

  @override
  String get utrNumber => 'UTR नंबर';

  @override
  String get failedToLoadTransactions => 'लेनदेन लोड करने में विफल';

  @override
  String get noTransactionsFound => 'कोई लेनदेन नहीं मिला';

  @override
  String get transactionHistoryDescription =>
      'आपका पहला लेनदेन करने के बाद आपका लेनदेन इतिहास यहाँ दिखाई देगा';

  @override
  String get goBack => 'वापस जाएं';

  @override
  String get success => 'सफल';

  @override
  String get failed => 'असफल';

  @override
  String get credit => 'क्रेडिट';

  @override
  String get debit => 'डेबिट';

  @override
  String get profileDetails => 'प्रोफ़ाइल विवरण';

  @override
  String get address => 'पता';

  @override
  String get notProvided => 'प्रदान नहीं किया गया';

  @override
  String get profileDetailsSectionHeader => 'प्रोफ़ाइल विवरण';

  @override
  String get editProfileInformation => 'प्रोफ़ाइल जानकारी संपादित करें';

  @override
  String get nameCannotBeEmpty => 'नाम खाली नहीं हो सकता';

  @override
  String get nameMinimumCharacters => 'नाम कम से कम 2 अक्षर का होना चाहिए';

  @override
  String get addressCannotBeEmpty => 'पता खाली नहीं हो सकता';

  @override
  String get pleaseEnterCompleteAddress => 'कृपया पूरा पता दर्ज करें';

  @override
  String get phoneAndReferralNotChangeable =>
      'नोट: फ़ोन नंबर और रेफ़रल कोड बदले नहीं जा सकते। केवल नाम, ईमेल और पता अपडेट किया जा सकता है।';

  @override
  String get updatingProfile => 'प्रोफ़ाइल अपडेट की जा रही है...';

  @override
  String get updateProfile => 'प्रोफ़ाइल अपडेट करें';

  @override
  String get profileUpdatedSuccessfully => 'प्रोफ़ाइल सफलतापूर्वक अपडेट हो गई!';

  @override
  String get profileUpdateSuccessMessage =>
      'आपकी प्रोफ़ाइल जानकारी सफलतापूर्वक अपडेट कर दी गई है।';

  @override
  String get updateFailed => 'अपडेट विफल';

  @override
  String get inviteEarnRewards => 'आमंत्रित करें और पुरस्कार पाएं';

  @override
  String get shareReferralDescription =>
      'अपना रेफरल कोड दोस्तों और परिवार के साथ साझा करें और जब वे पशु परिवार में शामिल हों तो विशेष पुरस्कार पाएं';

  @override
  String get yourReferralCode => 'आपका रेफरल कोड';

  @override
  String get shareWithFriends => 'दोस्तों के साथ साझा करें';

  @override
  String get shareLink => 'लिंक साझा करें';

  @override
  String get copyLink => 'लिंक कॉपी करें';

  @override
  String get moreOptions => 'अधिक विकल्प';

  @override
  String get referralBenefits => 'रेफरल लाभ';

  @override
  String get earnRewards => 'पुरस्कार पाएं';

  @override
  String get earnRewardsDescription =>
      'जब आपके दोस्त आपका कोड उपयोग करके शामिल हों तो विशेष पुरस्कार पाएं';

  @override
  String get helpFriends => 'दोस्तों की मदद करें';

  @override
  String get helpFriendsDescription =>
      'आपके दोस्तों को भी साइन अप करने पर विशेष बोनस मिलता है';

  @override
  String get unlimitedSharing => 'असीमित साझाकरण';

  @override
  String get unlimitedSharingDescription =>
      'अपना कोड जितनी बार चाहें किसी के साथ भी साझा करें';

  @override
  String get trackProgress => 'प्रगति ट्रैक करें';

  @override
  String get trackProgressDescription =>
      'अपनी प्रोफाइल में अपनी रेफरल सफलता और पुरस्कारों की निगरानी करें';

  @override
  String get howItWorks => 'यह कैसे काम करता है';

  @override
  String get shareYourCode => 'अपना कोड साझा करें';

  @override
  String get shareYourCodeDescription =>
      'अपना रेफरल कोड या लिंक दोस्तों और परिवार को भेजें';

  @override
  String get friendSignsUp => 'दोस्त साइन अप करता है';

  @override
  String get friendSignsUpDescription =>
      'वे आपके रेफरल कोड का उपयोग करके खाता बनाते हैं';

  @override
  String get bothGetRewards => 'दोनों को पुरस्कार मिलते हैं';

  @override
  String get bothGetRewardsDescription =>
      'आपको और आपके दोस्त को विशेष बोनस मिलते हैं';

  @override
  String get linkCopiedToClipboard => 'लिंक क्लिपबोर्ड पर कॉपी किया गया!';

  @override
  String get codeCopiedToClipboard => 'कोड क्लिपबोर्ड पर कॉपी किया गया!';

  @override
  String get referralHelp => 'रेफरल सहायता';

  @override
  String get referralHelpContent =>
      '• अपना अनूठा रेफरल कोड दोस्तों के साथ साझा करें\n• आपको और आपके दोस्त दोनों को पुरस्कार मिलते हैं\n• आप कितने भी दोस्तों को रेफर कर सकते हैं\n• अपनी प्रोफाइल में अपने रेफरल ट्रैक करें\n• पुरस्कार अपने आप क्रेडिट हो जाते हैं';

  @override
  String shareMessage(String referralCode, String referralUrl) {
    return '🐄 पशु परिवार में मेरे साथ जुड़ें - भारत का भरोसेमंद पशुधन बाज़ार! 🐄\n\nगुणवत्तापूर्ण जानवर खोजें, सत्यापित विक्रेताओं से जुड़ें, और प्रीमियम सुविधाओं के साथ अपना पशुधन व्यवसाय बढ़ाएं।\n\n✨ मेरा रेफरल कोड उपयोग करें: $referralCode\n🎁 हम दोनों के लिए विशेष पुरस्कार पाएं!\n\nअभी डाउनलोड करें: $referralUrl\n\n#पशुपरिवार #पशुधन #खेती #पशुव्यापार';
  }

  @override
  String get termsOfService => 'सेवा की शर्तें';

  @override
  String get privacyPolicy => 'गोपनीयता नीति';

  @override
  String get lastUpdated => 'अंतिम अपडेट: 27 जुलाई, 2025';

  @override
  String get acceptanceOfTerms => 'नियमों की स्वीकृति';

  @override
  String get acceptanceOfTermsContent =>
      'पशु परिवार का उपयोग करके, आप इस समझौते के नियमों और प्रावधानों से बाध्य होने के लिए सहमत हैं।';

  @override
  String get useLicense => 'उपयोग लाइसेंस';

  @override
  String get useLicenseContent =>
      'व्यक्तिगत, गैर-व्यावसायिक अस्थायी देखने के लिए प्रति डिवाइस पशु परिवार की एक प्रति अस्थायी रूप से डाउनलोड करने की अनुमति दी गई है।';

  @override
  String get userResponsibilities => 'उपयोगकर्ता की जिम्मेदारियां';

  @override
  String get userResponsibilitiesContent =>
      '• लिस्टिंग बनाते समय सटीक जानकारी प्रदान करें\n• अन्य उपयोगकर्ताओं का सम्मान करें और पेशेवर आचरण बनाए रखें\n• सभी लागू कानूनों और नियमों का पालन करें\n• धोखाधड़ी की गतिविधियों के लिए प्लेटफॉर्म का दुरुपयोग न करें';

  @override
  String get platformServices => 'प्लेटफॉर्म सेवाएं';

  @override
  String get platformServicesContent =>
      'पशु परिवार पशुधन व्यापार के लिए एक प्लेटफॉर्म प्रदान करता है, खरीदारों और विक्रेताओं को जोड़ता है। हम लेनदेन की सुविधा प्रदान करते हैं लेकिन खरीद/बिक्री प्रक्रिया में प्रत्यक्ष रूप से शामिल नहीं हैं।';

  @override
  String get accountSecurity => 'खाता सुरक्षा';

  @override
  String get accountSecurityContent =>
      'उपयोगकर्ता अपनी खाता जानकारी और पासवर्ड की गोपनीयता बनाए रखने के लिए जिम्मेदार हैं। किसी भी अनधिकृत उपयोग की तुरंत सूचना दें।';

  @override
  String get paymentTerms => 'भुगतान की शर्तें';

  @override
  String get paymentTermsContent =>
      'प्रीमियम सेवाओं के लिए सभी भुगतान सुरक्षित रूप से संसाधित किए जाते हैं। सदस्यता शुल्क वापसी योग्य नहीं हैं जब तक कि अन्यथा निर्दिष्ट न हो।';

  @override
  String get contentGuidelines => 'सामग्री दिशानिर्देश';

  @override
  String get contentGuidelinesContent =>
      'अपलोड की गई सभी सामग्री उपयुक्त, सटीक होनी चाहिए और हमारे समुदायिक दिशानिर्देशों का पालन करना चाहिए। हम अनुपयुक्त सामग्री को हटाने का अधिकार सुरक्षित रखते हैं।';

  @override
  String get limitationOfLiability => 'दायित्व की सीमा';

  @override
  String get limitationOfLiabilityContent =>
      'पशु परिवार सेवा के आपके उपयोग से होने वाले किसी भी अप्रत्यक्ष, आकस्मिक, विशेष, परिणामी, या दंडात्मक नुकसान के लिए उत्तरदायी नहीं होगा।';

  @override
  String get modifications => 'संशोधन';

  @override
  String get modificationsContent =>
      'हम किसी भी समय इन शर्तों को संशोधित करने का अधिकार सुरक्षित रखते हैं। महत्वपूर्ण परिवर्तनों की सूचना उपयोगकर्ताओं को दी जाएगी।';

  @override
  String get contactInformationContent =>
      'इन सेवा की शर्तों के बारे में प्रश्नों के लिए, कृपया हमसे support@pashuparivar.com पर संपर्क करें';

  @override
  String get informationWeCollect => 'हम जो जानकारी एकत्र करते हैं';

  @override
  String get informationWeCollectContent =>
      '• व्यक्तिगत जानकारी: नाम, फोन नंबर, ईमेल पता\n• प्रोफ़ाइल जानकारी: पता, प्राथमिकताएं, उपयोग डेटा\n• डिवाइस जानकारी: IP पता, ब्राउज़र प्रकार, ऑपरेटिंग सिस्टम\n• उपयोग डेटा: ऐप इंटरैक्शन, उपयोग की गई सुविधाएं, सत्र अवधि';

  @override
  String get howWeUseYourInformation =>
      'हम आपकी जानकारी का उपयोग कैसे करते हैं';

  @override
  String get howWeUseYourInformationContent =>
      'हम एकत्रित जानकारी का उपयोग करते हैं:\n• अपनी सेवाएं प्रदान करने और बनाए रखने के लिए\n• लेनदेन प्रक्रिया और सूचनाएं भेजने के लिए\n• उपयोगकर्ता अनुभव और ऐप कार्यक्षमता में सुधार के लिए\n• अपडेट और ऑफ़र के बारे में आपसे संवाद के लिए';

  @override
  String get informationSharing => 'जानकारी साझाकरण';

  @override
  String get informationSharingContent =>
      'हम आपकी जानकारी साझा कर सकते हैं:\n• अन्य उपयोगकर्ताओं के साथ (लिस्टिंग में प्रोफ़ाइल जानकारी)\n• सेवा प्रदाताओं के साथ जो हमारे संचालन में सहायता करते हैं\n• जब कानून द्वारा आवश्यक हो या अपने अधिकारों की सुरक्षा के लिए\n• विशिष्ट उद्देश्यों के लिए आपकी सहमति के साथ';

  @override
  String get dataSecurity => 'डेटा सुरक्षा';

  @override
  String get dataSecurityContent =>
      'हम अनधिकृत पहुंच, परिवर्तन, प्रकटीकरण, या विनाश के खिलाफ आपकी व्यक्तिगत जानकारी की सुरक्षा के लिए उपयुक्त सुरक्षा उपाय लागू करते हैं।';

  @override
  String get dataRetention => 'डेटा प्रतिधारण';

  @override
  String get dataRetentionContent =>
      'हम आपकी व्यक्तिगत जानकारी को केवल इस नीति में उल्लिखित उद्देश्यों के लिए आवश्यक समय तक या कानून द्वारा आवश्यक समय तक रखते हैं।';

  @override
  String get yourRights => 'आपके अधिकार';

  @override
  String get yourRightsContent =>
      'आपको अधिकार है:\n• अपनी व्यक्तिगत जानकारी तक पहुंचने का\n• गलत जानकारी को सुधारने का\n• अपना खाता और डेटा हटाने का\n• मार्केटिंग संचार से बाहर निकलने का';

  @override
  String get cookiesAndTracking => 'कुकीज़ और ट्रैकिंग';

  @override
  String get cookiesAndTrackingContent =>
      'हम आपके अनुभव को बेहतर बनाने, उपयोग पैटर्न का विश्लेषण करने और व्यक्तिगत सामग्री प्रदान करने के लिए कुकीज़ और समान तकनीकों का उपयोग करते हैं।';

  @override
  String get thirdPartyServices => 'तृतीय-पक्ष सेवाएं';

  @override
  String get thirdPartyServicesContent =>
      'हमारे ऐप में तृतीय-पक्ष सेवाओं के लिंक हो सकते हैं। हम उनकी गोपनीयता प्रथाओं के लिए जिम्मेदार नहीं हैं।';

  @override
  String get childrensPrivacy => 'बच्चों की गोपनीयता';

  @override
  String get childrensPrivacyContent =>
      'हमारी सेवा 13 वर्ष से कम उम्र के बच्चों के लिए नहीं है। हम जानबूझकर 13 वर्ष से कम उम्र के बच्चों से व्यक्तिगत जानकारी एकत्र नहीं करते।';

  @override
  String get changesToThisPolicy => 'इस नीति में परिवर्तन';

  @override
  String get changesToThisPolicyContent =>
      'हम समय-समय पर इस गोपनीयता नीति को अपडेट कर सकते हैं। हम इस पृष्ठ पर नई नीति पोस्ट करके आपको किसी भी बदलाव की सूचना देंगे।';

  @override
  String get privacyContactContent =>
      'यदि इस गोपनीयता नीति के बारे में आपके प्रश्न हैं, तो कृपया हमसे संपर्क करें:\nईमेल: privacy@pashuparivar.com\nफोन: +91-XXXXXXXXXX';
}
